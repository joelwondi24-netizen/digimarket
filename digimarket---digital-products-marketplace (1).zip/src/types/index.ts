export type ProductCategory =
  | 'eBooks'
  | 'Images'
  | 'Music'
  | 'Videos'
  | 'Graphics'
  | 'Templates'
  | 'Documents'
  | 'Presentations'
  | 'Fonts'
  | 'Icons'
  | 'Wallpapers'
  | 'Presets'
  | 'Audio'
  | 'Courses'
  | 'Software'
  | '3D Assets'
  | 'Business Resources'
  | 'Educational Materials';

export type LicenseType = 'personal' | 'commercial' | 'extended';

export type ProductStatus = 'draft' | 'pending' | 'published' | 'rejected' | 'archived';

export interface ProductReview {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  rating: number; // 1-5
  comment: string;
  date: string;
  verifiedPurchase: boolean;
  status: 'approved' | 'pending' | 'rejected';
}

export interface EbookMetadata {
  pageCount?: number;
  isbn?: string;
  sampleChapterTitle?: string;
  sampleChapterText?: string;
  tableOfContents?: string[];
  readingFormat?: string; // PDF, EPUB, MOBI
}

export interface AudioMetadata {
  trackDuration?: string; // e.g. "03:45"
  bpm?: number;
  musicalKey?: string; // e.g. "D Minor"
  sampleRate?: string; // e.g. "24-bit / 96kHz Lossless"
  stemsIncluded?: boolean;
  instrumentsUsed?: string[];
}

export interface VideoMetadata {
  resolution?: string; // e.g. "4K UHD (3840x2160)"
  frameRate?: string; // e.g. "24 fps"
  duration?: string; // e.g. "02:15"
  softwareCompatibility?: string[]; // Premiere Pro, DaVinci Resolve, Final Cut
  codecs?: string; // ProRes 422, H.264
}

export interface ImageMetadata {
  dimensions?: string; // e.g. "8192 x 5464 px"
  megapixels?: number; // e.g. 45
  colorSpace?: string; // e.g. "Adobe RGB (1998)" / "sRGB"
  dpi?: number; // e.g. 300 DPI
  rawIncluded?: boolean;
}

export interface TemplateMetadata {
  supportedSoftware?: string[]; // Figma, Sketch, Illustrator, Photoshop, Blender
  layerCount?: number;
  responsiveBreakpoints?: boolean;
}

export interface Product {
  id: string;
  title: string;
  slug: string;
  tagline: string;
  description: string;
  sellerId: string;
  sellerName: string;
  sellerAvatar: string;
  sellerRating: number;
  sellerVerified: boolean;
  category: ProductCategory;
  subcategory: string;
  price: number;
  originalPrice?: number;
  discountPercentage?: number;
  rating: number;
  reviewCount: number;
  salesCount: number;
  downloadCount: number;
  fileFormat: string; // e.g. "PDF + EPUB", "WAV + MP3", "ZIP (AI, SVG)", "BLEND + OBJ"
  fileSize: string; // e.g. "45.2 MB"
  downloadUrl?: string; // Private asset token reference
  thumbnail: string;
  previewImages: string[];
  audioPreviewUrl?: string;
  videoPreviewUrl?: string;
  sampleContent?: string; // For eBooks or text previews
  tags: string[];
  features: string[];
  whatsIncluded: string[];
  systemRequirements?: string;
  license: LicenseType;
  status: ProductStatus;
  isFeatured?: boolean;
  isBestseller?: boolean;
  isNew?: boolean;
  createdAt: string;
  updatedAt: string;
  
  // Specific category metadata
  ebookMeta?: EbookMetadata;
  audioMeta?: AudioMetadata;
  videoMeta?: VideoMetadata;
  imageMeta?: ImageMetadata;
  templateMeta?: TemplateMetadata;
}

export interface CartItem {
  product: Product;
  license: LicenseType;
  price: number;
}

export interface Coupon {
  code: string;
  discountPercent?: number;
  discountAmount?: number;
  minPurchase?: number;
  expiresAt: string;
  description: string;
  isActive: boolean;
}

export interface DownloadToken {
  id: string;
  orderId: string;
  orderNumber: string;
  productId: string;
  productTitle: string;
  fileFormat: string;
  fileSize: string;
  token: string;
  createdAt: string;
  expiresAt: string;
  maxDownloads: number;
  downloadsRemaining: number;
  downloadHistory: { timestamp: string; ip: string; userAgent?: string }[];
  isRevoked: boolean;
  paymentVerificationStatus: 'verified' | 'pending' | 'flagged';
  verificationHash: string;
  paymentGateway: 'stripe' | 'paypal' | 'apple_pay';
}

export interface OrderItem {
  productId: string;
  productTitle: string;
  productThumbnail: string;
  category: ProductCategory;
  sellerId: string;
  sellerName: string;
  license: LicenseType;
  price: number;
  fileFormat: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  items: OrderItem[];
  subtotal: number;
  discountAmount: number;
  couponCode?: string;
  platformFee: number;
  total: number;
  paymentMethod: 'stripe' | 'paypal' | 'apple_pay';
  paymentStatus: 'paid' | 'pending' | 'refunded' | 'failed';
  paymentVerificationDetails?: {
    verified: boolean;
    authCode: string;
    verifiedAt: string;
    transactionHash: string;
    securityStandard: string;
  };
  downloadTokens: DownloadToken[];
  createdAt: string;
  refundReason?: string;
}

export interface Seller {
  id: string;
  userId: string;
  name: string;
  storeName: string;
  storeSlug: string;
  bio: string;
  avatar: string;
  banner?: string;
  country: string;
  rating: number;
  salesCount: number;
  followersCount: number;
  grossRevenue: number;
  netEarnings: number; // 80% standard
  pendingPayouts: number;
  payoutMethod: 'stripe_connect' | 'paypal' | 'bank_wire';
  payoutAccount: string;
  isApproved: boolean;
  joinedDate: string;
}

export interface AdminPermissions {
  canUploadProducts: boolean;
  canApproveProducts: boolean;
  canIssueRefundsAndRevokeTokens: boolean;
  canManageCommission: boolean;
  canRegisterAdmins: boolean;
  canViewSecurityAuditLogs: boolean;
}

export interface AdminStaff {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: 'super_admin' | 'product_manager' | 'financial_officer' | 'moderator' | 'content_editor';
  securityLevel: 1 | 2 | 3 | 4 | 5;
  status: 'active' | 'suspended';
  joinedDate: string;
  lastLogin?: string;
  permissions: AdminPermissions;
  securityPassphraseHint?: string;
}

export interface AdminAuditLog {
  id: string;
  adminId: string;
  adminName: string;
  action: string;
  details: string;
  targetId?: string;
  timestamp: string;
  ipAddress: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: 'customer' | 'seller' | 'admin';
  adminStaffId?: string;
  sellerId?: string;
  joinedDate: string;
  wishlist: string[]; // product IDs
}

export type ActivePage =
  | 'home'
  | 'marketplace'
  | 'product-details'
  | 'cart'
  | 'checkout'
  | 'order-success'
  | 'downloads'
  | 'account'
  | 'seller-dashboard'
  | 'seller-storefront'
  | 'admin'
  | 'verify-download'
  | 'about'
  | 'contact'
  | 'faq'
  | 'legal';
