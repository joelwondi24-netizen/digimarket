import React, { useState } from 'react';
import { X, Sparkles, ArrowRight, ShieldCheck } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AnnouncementBar: React.FC = () => {
  const [visible, setVisible] = useState(true);
  const { navigate } = useApp();

  if (!visible) return null;

  return (
    <aside
      aria-label="Announcement"
      className="bg-neutral-900 text-neutral-100 dark:bg-neutral-950 dark:text-neutral-200 text-xs py-2 px-4 border-b border-neutral-800"
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div className="flex-1 flex items-center justify-center gap-2 text-center overflow-hidden">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0 hidden sm:inline-block" />
          <span className="truncate">
            <strong className="font-semibold text-white">Instant Verified Delivery:</strong> Get 256-bit encrypted downloads immediately after payment clearance. Use{' '}
            <span className="font-mono bg-neutral-800 dark:bg-neutral-900 text-amber-300 px-1.5 py-0.5 rounded text-[11px]">
              WELCOME10
            </span>{' '}
            for 10% off.
          </span>
          <button
            onClick={() => navigate('verify-download')}
            className="hidden md:inline-flex items-center gap-1 text-amber-400 hover:text-amber-300 font-medium ml-2 transition-colors cursor-pointer"
          >
            Verify a purchase <ArrowRight className="w-3 h-3" />
          </button>
        </div>
        <button
          onClick={() => setVisible(false)}
          className="text-neutral-400 hover:text-white p-0.5 shrink-0 transition-colors cursor-pointer"
          aria-label="Close announcement"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </aside>
  );
};
