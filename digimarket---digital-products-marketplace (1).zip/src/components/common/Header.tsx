import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Search,
  ShoppingBag,
  Heart,
  Moon,
  Sun,
  User as UserIcon,
  ChevronDown,
  Layers,
  Sparkles,
  ShieldCheck,
  LogOut,
  Upload,
  UserPlus,
  KeyRound,
} from 'lucide-react';
import { ProductCategory } from '../../types';

export const Header: React.FC = () => {
  const {
    navigate,
    cart,
    wishlist,
    darkMode,
    toggleDarkMode,
    currentUser,
    adminStaffList,
    currentAdminStaff,
    switchAdminStaff,
    loginAs,
    logout,
    setIsCartOpen,
    setIsBecomeSellerModalOpen,
    setIsUploadModalOpen,
    setIsAdminUploadModalOpen,
    setIsAdminRegisterModalOpen,
    searchQuery,
    setSearchQuery,
    products,
  } = useApp();

  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isCategoryMenuOpen, setIsCategoryMenuOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);

  // Filtered suggestions for live search
  const suggestions = searchQuery.trim()
    ? products
        .filter(
          (p) =>
            p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
            p.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()))
        )
        .slice(0, 5)
    : [];

  // Close menus on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setIsSearchOpen(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setIsSearchOpen(false);
      navigate('marketplace');
    }
  };

  const categories: ProductCategory[] = [
    'eBooks',
    'Music',
    'Images',
    'Videos',
    'Templates',
    'Graphics',
    'Fonts',
    '3D Assets',
    'Presets',
    'Software',
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-neutral-900/95 backdrop-blur-md border-b border-neutral-200/80 dark:border-neutral-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark (Top Bar Contract Compliant) */}
        <div className="flex items-center gap-6">
          <button
            onClick={() => navigate('home')}
            className="text-xl sm:text-2xl font-bold tracking-tight font-display text-neutral-950 dark:text-white hover:opacity-90 transition-opacity cursor-pointer whitespace-nowrap"
          >
            DigiMarket
          </button>
        </div>

        {/* Zone 2: 4-6 text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-neutral-600 dark:text-neutral-300">
          <button
            onClick={() => navigate('marketplace')}
            className="hover:text-neutral-950 dark:hover:text-white transition-colors cursor-pointer"
          >
            Marketplace
          </button>

          {/* Categories dropdown */}
          <div className="relative" onMouseLeave={() => setIsCategoryMenuOpen(false)}>
            <button
              onMouseEnter={() => setIsCategoryMenuOpen(true)}
              onClick={() => setIsCategoryMenuOpen((prev) => !prev)}
              className="flex items-center gap-1 hover:text-neutral-950 dark:hover:text-white transition-colors cursor-pointer"
            >
              Categories <ChevronDown className="w-3.5 h-3.5 opacity-60" />
            </button>
            {isCategoryMenuOpen && (
              <div
                className="absolute top-full left-0 mt-1 w-56 p-2 bg-white dark:bg-neutral-900 rounded-xl shadow-xl border border-neutral-200 dark:border-neutral-800 grid grid-cols-1 gap-0.5 animate-in fade-in zoom-in-95 duration-100"
                onMouseEnter={() => setIsCategoryMenuOpen(true)}
              >
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => {
                      setIsCategoryMenuOpen(false);
                      navigate('marketplace', { category: cat });
                    }}
                    className="text-left px-3 py-2 text-xs rounded-lg text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
                  >
                    {cat}
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={() => navigate('verify-download')}
            className="hover:text-neutral-950 dark:hover:text-white transition-colors cursor-pointer flex items-center gap-1"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Verify & Download</span>
          </button>

          <button
            onClick={() => navigate('about')}
            className="hover:text-neutral-950 dark:hover:text-white transition-colors cursor-pointer"
          >
            About
          </button>

          <button
            onClick={() => navigate('faq')}
            className="hover:text-neutral-950 dark:hover:text-white transition-colors cursor-pointer"
          >
            FAQ
          </button>

          <button
            onClick={() => {
              if (currentUser?.role === 'seller') {
                navigate('seller-dashboard');
              } else {
                setIsBecomeSellerModalOpen(true);
              }
            }}
            className="hover:text-neutral-950 dark:hover:text-white transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Sell Assets</span>
          </button>
        </nav>

        {/* Zone 3: Actions & Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Live Search Bar */}
          <div ref={searchRef} className="relative">
            <form onSubmit={handleSearchSubmit} className="relative">
              <input
                type="text"
                value={searchQuery}
                onFocus={() => setIsSearchOpen(true)}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setIsSearchOpen(true);
                }}
                placeholder="Search eBooks, music, 3D..."
                className="w-32 sm:w-48 md:w-56 pl-8 pr-3 py-1.5 text-xs bg-neutral-100 dark:bg-neutral-800 text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 rounded-lg border border-transparent focus:border-neutral-300 dark:focus:border-neutral-700 focus:outline-none focus:ring-1 focus:ring-neutral-400 transition-all"
              />
              <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </form>

            {/* Live Search Suggestions Dropdown */}
            {isSearchOpen && suggestions.length > 0 && (
              <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-neutral-900 rounded-xl shadow-2xl border border-neutral-200 dark:border-neutral-800 p-2 z-50">
                <div className="px-2 py-1 text-[10px] uppercase font-semibold text-neutral-400 tracking-wider">
                  Products & Assets
                </div>
                {suggestions.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setIsSearchOpen(false);
                      navigate('product-details', { productId: item.id });
                    }}
                    className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-left transition-colors cursor-pointer"
                  >
                    <img
                      src={item.thumbnail}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      className="w-9 h-9 object-cover rounded-md bg-neutral-200 shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-neutral-900 dark:text-white truncate">
                        {item.title}
                      </p>
                      <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                        {item.category} · ${item.price.toFixed(2)}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Theme Toggle */}
          <button
            onClick={toggleDarkMode}
            className="p-2 text-neutral-600 dark:text-neutral-300 hover:text-neutral-950 dark:hover:text-white rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
            aria-label="Toggle dark mode"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Wishlist Button */}
          <button
            onClick={() => navigate('account')}
            className="p-2 relative text-neutral-600 dark:text-neutral-300 hover:text-neutral-950 dark:hover:text-white rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
            aria-label="Wishlist"
          >
            <Heart className="w-4 h-4" />
            {wishlist.length > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500" />
            )}
          </button>

          {/* Shopping Cart Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:hover:bg-neutral-100 dark:text-neutral-900 rounded-lg shadow-sm transition-colors cursor-pointer whitespace-nowrap"
            aria-label="View Cart"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Cart</span>
            {cart.length > 0 && (
              <span className="ml-0.5 px-1.5 py-0.2 rounded-full bg-amber-500 text-neutral-950 font-bold text-[10px]">
                {cart.length}
              </span>
            )}
          </button>

          {/* User Account / Role Switcher Menu */}
          <div ref={userMenuRef} className="relative">
            <button
              onClick={() => setIsUserMenuOpen((prev) => !prev)}
              className="flex items-center gap-1 p-1 rounded-full border border-neutral-200 dark:border-neutral-700 hover:border-neutral-400 transition-colors cursor-pointer"
              aria-label="User Account Menu"
            >
              {currentUser?.avatar ? (
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  referrerPolicy="no-referrer"
                  className="w-7 h-7 rounded-full object-cover"
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-neutral-200 dark:bg-neutral-700 flex items-center justify-center">
                  <UserIcon className="w-4 h-4 text-neutral-600 dark:text-neutral-300" />
                </div>
              )}
            </button>

            {isUserMenuOpen && (
              <div className="absolute right-0 mt-2 w-72 p-2 bg-white dark:bg-neutral-900 rounded-2xl shadow-2xl border border-neutral-200 dark:border-neutral-800 z-50 animate-in fade-in zoom-in-95 duration-100">
                <div className="px-3 py-2 border-b border-neutral-100 dark:border-neutral-800 mb-1">
                  <p className="text-xs font-semibold text-neutral-900 dark:text-white truncate">
                    {currentUser?.name || 'Guest User'}
                  </p>
                  <p className="text-[11px] text-neutral-500 truncate">
                    {currentUser?.email || 'Browse digital downloads'}
                  </p>
                  <div className="mt-1 text-[10px] text-neutral-400 flex items-center justify-between">
                    <span>
                      Role:{' '}
                      <strong className="text-neutral-700 dark:text-neutral-300 uppercase">
                        {currentUser?.role || 'Guest'}
                      </strong>
                    </span>
                    {currentUser?.role === 'admin' && (
                      <span className="text-blue-600 dark:text-blue-400 font-medium">
                        Level {currentAdminStaff?.securityLevel || 5}
                      </span>
                    )}
                  </div>
                </div>

                {/* Role Switcher */}
                <div className="px-3 py-1.5 text-[10px] uppercase font-semibold text-neutral-400 tracking-wider">
                  Active Persona Mode
                </div>
                <div className="grid grid-cols-3 gap-1 px-1 mb-2">
                  <button
                    onClick={() => {
                      loginAs('customer');
                      setIsUserMenuOpen(false);
                    }}
                    className={`px-2 py-1 text-[11px] font-medium rounded-md text-center transition-colors cursor-pointer ${
                      currentUser?.role === 'customer'
                        ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 font-bold'
                        : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200'
                    }`}
                  >
                    Buyer
                  </button>
                  <button
                    onClick={() => {
                      loginAs('seller');
                      setIsUserMenuOpen(false);
                    }}
                    className={`px-2 py-1 text-[11px] font-medium rounded-md text-center transition-colors cursor-pointer ${
                      currentUser?.role === 'seller'
                        ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 font-bold'
                        : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200'
                    }`}
                  >
                    Seller
                  </button>
                  <button
                    onClick={() => {
                      loginAs('admin');
                      setIsUserMenuOpen(false);
                    }}
                    className={`px-2 py-1 text-[11px] font-medium rounded-md text-center transition-colors cursor-pointer ${
                      currentUser?.role === 'admin'
                        ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 font-bold'
                        : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200'
                    }`}
                  >
                    Admin
                  </button>
                </div>

                {/* If user is admin, allow switching staff profile */}
                {currentUser?.role === 'admin' && (
                  <div className="px-2 py-1.5 mb-2 bg-neutral-50 dark:bg-neutral-800/50 rounded-xl">
                    <span className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider block mb-1">
                      Admin Staff Identity
                    </span>
                    <select
                      value={currentAdminStaff?.id || ''}
                      onChange={(e) => switchAdminStaff(e.target.value)}
                      className="w-full text-xs p-1.5 bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-white"
                    >
                      {adminStaffList.map((st) => (
                        <option key={st.id} value={st.id}>
                          {st.name} ({st.role.replace('_', ' ')})
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="pt-1 border-t border-neutral-100 dark:border-neutral-800 flex flex-col gap-0.5">
                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      navigate('account');
                    }}
                    className="w-full text-left px-3 py-1.5 text-xs rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 transition-colors flex items-center gap-2 cursor-pointer"
                  >
                    <Layers className="w-3.5 h-3.5" /> Customer Downloads & Purchases
                  </button>

                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      navigate('verify-download');
                    }}
                    className="w-full text-left px-3 py-1.5 text-xs rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 transition-colors flex items-center gap-2 cursor-pointer"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" /> Verify Payment & Download
                  </button>

                  {currentUser?.role === 'seller' && (
                    <>
                      <button
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          navigate('seller-dashboard');
                        }}
                        className="w-full text-left px-3 py-1.5 text-xs rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 transition-colors flex items-center gap-2 cursor-pointer"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Seller Studio & Analytics
                      </button>
                      <button
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          setIsUploadModalOpen(true);
                        }}
                        className="w-full text-left px-3 py-1.5 text-xs rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 transition-colors flex items-center gap-2 cursor-pointer"
                      >
                        <Upload className="w-3.5 h-3.5 text-emerald-500" /> Upload Creator Deliverable
                      </button>
                    </>
                  )}

                  {currentUser?.role === 'admin' && (
                    <>
                      <button
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          navigate('admin');
                        }}
                        className="w-full text-left px-3 py-1.5 text-xs rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 transition-colors flex items-center gap-2 cursor-pointer font-semibold text-blue-600 dark:text-blue-400"
                      >
                        <ShieldCheck className="w-3.5 h-3.5 text-blue-500" /> Administrator Console
                      </button>
                      <button
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          setIsAdminUploadModalOpen(true);
                        }}
                        className="w-full text-left px-3 py-1.5 text-xs rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 transition-colors flex items-center gap-2 cursor-pointer"
                      >
                        <Upload className="w-3.5 h-3.5 text-amber-500" /> Upload & Post Product (Admin)
                      </button>
                      <button
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          setIsAdminRegisterModalOpen(true);
                        }}
                        className="w-full text-left px-3 py-1.5 text-xs rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-700 dark:text-neutral-300 transition-colors flex items-center gap-2 cursor-pointer"
                      >
                        <UserPlus className="w-3.5 h-3.5 text-purple-500" /> Register New Administrator
                      </button>
                    </>
                  )}

                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                      logout();
                    }}
                    className="w-full text-left px-3 py-1.5 text-xs rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/30 text-rose-600 dark:text-rose-400 transition-colors flex items-center gap-2 cursor-pointer mt-1 border-t border-neutral-100 dark:border-neutral-800"
                  >
                    <LogOut className="w-3.5 h-3.5" /> Sign Out
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
