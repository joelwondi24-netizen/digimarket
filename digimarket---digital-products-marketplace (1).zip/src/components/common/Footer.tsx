import React from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowUpRight, ShieldCheck, Download, Zap, Globe, Lock, KeyRound } from 'lucide-react';
import { ProductCategory } from '../../types';

export const Footer: React.FC = () => {
  const { navigate, setIsBecomeSellerModalOpen } = useApp();

  const handleCategoryClick = (category: ProductCategory) => {
    navigate('marketplace', { category });
  };

  const socialLinks = [
    { name: 'X / Twitter', url: 'https://x.com' },
    { name: 'Instagram', url: 'https://instagram.com' },
    { name: 'YouTube', url: 'https://youtube.com' },
    { name: 'GitHub', url: 'https://github.com' },
    { name: 'Discord', url: 'https://discord.com' },
    { name: 'LinkedIn', url: 'https://linkedin.com' },
  ];

  return (
    <footer className="bg-neutral-900 text-neutral-300 dark:bg-black dark:text-neutral-400 pt-16 pb-12 border-t border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Trust Badges Bar */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pb-12 border-b border-neutral-800 text-neutral-200">
          <div className="flex items-start gap-3">
            <Download className="w-5 h-5 text-amber-400 mt-0.5 shrink-0" />
            <div>
              <h4 className="text-sm font-semibold text-white">Instant Verified Delivery</h4>
              <p className="text-xs text-neutral-400 mt-0.5">
                Generate secure cryptographic tokens and access high-resolution source packages immediately after payment clearance.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-400 mt-0.5 shrink-0" />
            <div>
              <h4 className="text-sm font-semibold text-white">Verified Commercial Licensing</h4>
              <p className="text-xs text-neutral-400 mt-0.5">
                Every digital product includes legally binding commercial rights with copyright protection assurances.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Zap className="w-5 h-5 text-blue-400 mt-0.5 shrink-0" />
            <div>
              <h4 className="text-sm font-semibold text-white">Direct Creator Payouts</h4>
              <p className="text-xs text-neutral-400 mt-0.5">
                80% net revenue goes directly to independent composers, authors, developers, and visual designers.
              </p>
            </div>
          </div>
        </div>

        {/* 5 Column Navigation Grid */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 py-12">
          {/* Brand info */}
          <div className="col-span-2 md:col-span-1">
            <button
              onClick={() => navigate('home')}
              className="text-xl font-bold font-display text-white tracking-tight cursor-pointer"
            >
              DigiMarket
            </button>
            <p className="text-xs text-neutral-400 mt-3 leading-relaxed">
              Discover. Purchase. Securely Download.
            </p>
            <p className="text-xs text-neutral-500 mt-2">
              The premier marketplace for verified digital assets, audio stems, 3D models, publications, and creative code.
            </p>
            <div className="mt-4 flex items-center gap-1.5 text-[11px] text-emerald-400">
              <Lock className="w-3.5 h-3.5" />
              <span>TLS 256-Bit Encrypted Vault</span>
            </div>
          </div>

          {/* Column 1: Marketplace */}
          <div>
            <h5 className="text-xs font-semibold uppercase tracking-wider text-white mb-4">
              Marketplace
            </h5>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => navigate('marketplace')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Browse All Assets
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleCategoryClick('eBooks')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  eBooks & Blueprints
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleCategoryClick('Music')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Music & Scores
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleCategoryClick('Videos')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Video & Motion
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleCategoryClick('3D Assets')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  3D Assets & Shaders
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleCategoryClick('Templates')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  UI Kits & Templates
                </button>
              </li>
            </ul>
          </div>

          {/* Column 2: Verification & Account */}
          <div>
            <h5 className="text-xs font-semibold uppercase tracking-wider text-white mb-4">
              Customer & Security
            </h5>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => navigate('verify-download')}
                  className="hover:text-white text-emerald-400 font-semibold transition-colors cursor-pointer flex items-center gap-1"
                >
                  <KeyRound className="w-3 h-3" />
                  <span>Verify & Download</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('account')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  My Downloads Dashboard
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('account')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Order Receipts & Keys
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('legal')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Commercial Rights Policy
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Sell & Studio */}
          <div>
            <h5 className="text-xs font-semibold uppercase tracking-wider text-white mb-4">
              Creator Studio
            </h5>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => setIsBecomeSellerModalOpen(true)}
                  className="hover:text-white transition-colors cursor-pointer text-amber-400 font-medium"
                >
                  Become a Creator
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('seller-dashboard')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Seller Dashboard
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('legal')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Seller Agreement (80/20)
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('faq')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Payout Schedules & Fees
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Admin & Governance */}
          <div>
            <h5 className="text-xs font-semibold uppercase tracking-wider text-white mb-4">
              Administration
            </h5>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => navigate('admin')}
                  className="hover:text-white transition-colors cursor-pointer text-blue-400 font-medium"
                >
                  Admin Operations Console
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('admin')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Products Post & Upload Hub
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('admin')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Admin Registration Panel
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigate('legal')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Security & DMCA Audits
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Social Links Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-8 border-t border-neutral-800 text-xs">
          <div className="flex items-center gap-4 flex-wrap">
            <span className="text-neutral-500 font-medium">Follow creators:</span>
            {socialLinks.map((item) => (
              <a
                key={item.name}
                href={item.url}
                target="_blank"
                rel="noreferrer noopener"
                className="text-neutral-400 hover:text-white flex items-center gap-0.5 transition-colors"
              >
                {item.name} <ArrowUpRight className="w-3 h-3 opacity-60" />
              </a>
            ))}
          </div>
          <div className="flex items-center gap-3 text-neutral-500">
            <Globe className="w-3.5 h-3.5" />
            <span>Worldwide Encrypted Fulfillment</span>
            <span>·</span>
            <span>© {new Date().getFullYear()} DigiMarket Inc.</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
