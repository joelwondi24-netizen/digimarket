import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShieldCheck,
  Search,
  Download,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  ArrowRight,
  RefreshCw,
  Lock,
} from 'lucide-react';
import { DownloadToken, Order } from '../../types';

export const VerifyDownloadPage: React.FC = () => {
  const {
    verifyOrderDownloadLookup,
    downloadProduct,
    downloadTokens,
    orders,
    navigate,
    showToast,
  } = useApp();

  const [orderNumber, setOrderNumber] = useState('');
  const [email, setEmail] = useState('');
  const [lookupResult, setLookupResult] = useState<{
    searched: boolean;
    success: boolean;
    message: string;
    tokens?: DownloadToken[];
    order?: Order;
  }>({
    searched: false,
    success: false,
    message: '',
  });

  const [isVerifying, setIsVerifying] = useState(false);

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderNumber.trim() || !email.trim()) return;

    setIsVerifying(true);

    setTimeout(() => {
      const res = verifyOrderDownloadLookup(orderNumber, email);
      setLookupResult({
        searched: true,
        success: res.success,
        message: res.message,
        tokens: res.tokens,
        order: res.order,
      });
      setIsVerifying(false);
      if (res.success) {
        showToast('success', 'Payment Verified', 'Digital download tokens authenticated.');
      } else {
        showToast('error', 'Lookup Failed', res.message);
      }
    }, 600);
  };

  // Demo auto-fill helper
  const handleQuickDemoFill = (ord: Order) => {
    setOrderNumber(ord.orderNumber);
    setEmail(ord.customerEmail);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
      {/* Title Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 text-xs font-semibold border border-emerald-200 dark:border-emerald-900/60 mb-3">
          <KeyRound className="w-3.5 h-3.5" />
          <span>Cryptographic License Authentication</span>
        </div>
        <h1 className="text-3xl font-bold font-display text-neutral-950 dark:text-white">
          Verify Payment & Secure Download
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 mt-2 leading-relaxed">
          Purchased a digital deliverable? Enter your order reference number and checkout email to verify your payment status and instantly download your files.
        </p>
      </div>

      {/* Verification Lookup Card */}
      <div className="bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 p-6 sm:p-8 shadow-sm mb-10">
        <form onSubmit={handleVerify} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Order Number or Token ID
              </label>
              <input
                type="text"
                required
                value={orderNumber}
                onChange={(e) => setOrderNumber(e.target.value.toUpperCase())}
                placeholder="e.g. DG-928410 or ord-..."
                className="w-full px-3 py-2.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-white font-mono uppercase focus:outline-none focus:ring-1 focus:ring-neutral-400"
              />
            </div>
            <div>
              <label className="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                Billing Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. buyer@example.com"
                className="w-full px-3 py-2.5 bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-neutral-400"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isVerifying || !orderNumber.trim() || !email.trim()}
            className="w-full py-3 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 rounded-xl text-xs font-bold transition-all shadow flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isVerifying ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Verifying Cryptographic Ledger...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Verify Payment & Retrieve Deliverables</span>
              </>
            )}
          </button>
        </form>

        {/* Demo Quick-Select if orders exist */}
        {orders.length > 0 && (
          <div className="mt-5 pt-4 border-t border-neutral-100 dark:border-neutral-800 text-xs">
            <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider block mb-2">
              Recent Orders in Session (Click to auto-test verification):
            </span>
            <div className="flex flex-wrap gap-2">
              {orders.slice(0, 3).map((o) => (
                <button
                  key={o.id}
                  type="button"
                  onClick={() => handleQuickDemoFill(o)}
                  className="px-2.5 py-1 rounded-lg bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 text-xs font-mono transition-colors cursor-pointer"
                >
                  {o.orderNumber} ({o.customerEmail.split('@')[0]})
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Verification Lookup Result Display */}
      {lookupResult.searched && (
        <div className="animate-in fade-in zoom-in-95 duration-200">
          {lookupResult.success && lookupResult.tokens && lookupResult.tokens.length > 0 ? (
            <div className="bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 p-6 sm:p-8 shadow-sm space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-neutral-100 dark:border-neutral-800">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-neutral-900 dark:text-white">
                      Payment Verification Cleared
                    </h3>
                    <p className="text-xs text-neutral-500">
                      Order <span className="font-mono font-bold text-neutral-800 dark:text-neutral-200">{lookupResult.order?.orderNumber}</span> · Paid via {lookupResult.order?.paymentMethod.toUpperCase()}
                    </p>
                  </div>
                </div>

                <div className="text-left sm:text-right text-xs">
                  <span className="font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded text-[11px]">
                    256-Bit TLS Authenticated
                  </span>
                  <div className="text-[11px] text-neutral-400 mt-1">
                    Cleared At: {lookupResult.order?.createdAt.split('T')[0]}
                  </div>
                </div>
              </div>

              {/* Tokens deliverable list */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                  Ready Deliverables ({lookupResult.tokens.length})
                </h4>

                {lookupResult.tokens.map((token) => (
                  <div
                    key={token.id}
                    className="p-4 rounded-2xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200/80 dark:border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div>
                      <h5 className="text-sm font-bold text-neutral-900 dark:text-white">
                        {token.productTitle}
                      </h5>
                      <div className="flex items-center gap-2 text-xs text-neutral-500 mt-1">
                        <span className="font-medium text-neutral-700 dark:text-neutral-300">{token.fileFormat}</span>
                        <span>·</span>
                        <span>{token.fileSize}</span>
                        <span>·</span>
                        <span className="text-emerald-600 dark:text-emerald-400 font-medium">
                          {token.downloadsRemaining} / {token.maxDownloads} downloads left
                        </span>
                      </div>
                      <div className="text-[10px] font-mono text-neutral-400 mt-1 truncate max-w-sm">
                        Token: {token.token}
                      </div>
                    </div>

                    <button
                      onClick={() => downloadProduct(token)}
                      className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 rounded-xl text-xs font-bold transition-all shadow flex items-center justify-center gap-2 cursor-pointer shrink-0"
                    >
                      <Download className="w-4 h-4" /> Download Files Now
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-8 text-center bg-rose-50 dark:bg-rose-950/20 rounded-2xl border border-rose-200 dark:border-rose-900/40 text-xs space-y-2">
              <AlertCircle className="w-8 h-8 text-rose-500 mx-auto" />
              <h4 className="font-bold text-rose-800 dark:text-rose-300 text-sm">
                Verification Unsuccessful
              </h4>
              <p className="text-rose-600 dark:text-rose-400 max-w-sm mx-auto">
                {lookupResult.message || 'We could not verify payment for that reference and email. Please confirm your order number or check your customer dashboard.'}
              </p>
              <button
                onClick={() => navigate('account')}
                className="mt-3 px-4 py-2 bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 rounded-xl font-semibold cursor-pointer"
              >
                Sign into Account Dashboard
              </button>
            </div>
          )}
        </div>
      )}

      {/* Security Assurance Features */}
      <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-neutral-600 dark:text-neutral-400">
        <div className="p-5 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
          <Lock className="w-5 h-5 text-amber-500 mb-2" />
          <h4 className="font-bold text-neutral-900 dark:text-white">Protected CDN Delivery</h4>
          <p className="mt-1 leading-relaxed">
            All download requests verify your active order token against our private vault mirror before transmitting binary files.
          </p>
        </div>
        <div className="p-5 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
          <FileCheck className="w-5 h-5 text-emerald-500 mb-2" />
          <h4 className="font-bold text-neutral-900 dark:text-white">Cryptographic Certificate</h4>
          <p className="mt-1 leading-relaxed">
            Each deliverable zip includes an authentic, signed DigiMarket intellectual property license document for commercial client proof.
          </p>
        </div>
        <div className="p-5 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
          <RefreshCw className="w-5 h-5 text-blue-500 mb-2" />
          <h4 className="font-bold text-neutral-900 dark:text-white">30-Day Link Guarantee</h4>
          <p className="mt-1 leading-relaxed">
            Should your local drive crash, verified purchasers can request an automated token refresh anytime within their customer account.
          </p>
        </div>
      </div>
    </div>
  );
};
