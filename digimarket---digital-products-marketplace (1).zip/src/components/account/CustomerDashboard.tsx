import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Download,
  ShoppingBag,
  Heart,
  FileText,
  User as UserIcon,
  LogOut,
  Layers,
  Star,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldCheck,
  Bell,
  Trash2,
  KeyRound,
  RefreshCw,
} from 'lucide-react';
import { ProductCard } from '../marketplace/ProductCard';

type Tab = 'downloads' | 'orders' | 'wishlist' | 'reviews' | 'profile';

export const CustomerDashboard: React.FC = () => {
  const {
    currentUser,
    downloadTokens,
    orders,
    wishlist,
    products,
    downloadProduct,
    reviews,
    logout,
    navigate,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<Tab>('downloads');

  const wishlistedProducts = products.filter((p) => wishlist.includes(p.id));
  const userReviews = reviews.filter((r) => r.userId === currentUser?.id);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
      {/* Header bar with user profile summary */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-8 border-b border-neutral-200/80 dark:border-neutral-800">
        <div className="flex items-center gap-4">
          {currentUser?.avatar ? (
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              referrerPolicy="no-referrer"
              className="w-14 h-14 rounded-full object-cover border-2 border-neutral-200 dark:border-neutral-700 shadow-sm"
            />
          ) : (
            <div className="w-14 h-14 rounded-full bg-neutral-200 dark:bg-neutral-800 flex items-center justify-center font-bold text-lg">
              {currentUser?.name?.[0] || 'U'}
            </div>
          )}
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-bold font-display text-neutral-950 dark:text-white">
                {currentUser?.name || 'Customer Account'}
              </h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                Verified Customer
              </span>
            </div>
            <p className="text-xs text-neutral-500 mt-0.5">
              {currentUser?.email} · Member since {currentUser?.joinedDate || '2025'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('verify-download')}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
          >
            <KeyRound className="w-3.5 h-3.5" /> Verify Order Number
          </button>
          <button
            onClick={() => {
              logout();
              navigate('home');
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-300 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" /> Sign Out
          </button>
        </div>
      </div>

      {/* Main Grid: Sidebar Tabs + Content */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pt-8">
        {/* Navigation Tabs (3 cols) */}
        <aside className="md:col-span-3 space-y-1">
          <button
            onClick={() => setActiveTab('downloads')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              activeTab === 'downloads'
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow-xs'
                : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
            }`}
          >
            <span className="flex items-center gap-2">
              <Download className="w-4 h-4 text-amber-500" /> My Downloads
            </span>
            <span className="tabular-nums opacity-75">{downloadTokens.length}</span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              activeTab === 'orders'
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow-xs'
                : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
            }`}
          >
            <span className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-blue-500" /> Order History & Receipts
            </span>
            <span className="tabular-nums opacity-75">{orders.length}</span>
          </button>

          <button
            onClick={() => setActiveTab('wishlist')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              activeTab === 'wishlist'
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow-xs'
                : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
            }`}
          >
            <span className="flex items-center gap-2">
              <Heart className="w-4 h-4 text-rose-500" /> Saved Wishlist
            </span>
            <span className="tabular-nums opacity-75">{wishlist.length}</span>
          </button>

          <button
            onClick={() => setActiveTab('reviews')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              activeTab === 'reviews'
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow-xs'
                : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
            }`}
          >
            <span className="flex items-center gap-2">
              <Star className="w-4 h-4 text-amber-400" /> My Reviews
            </span>
            <span className="tabular-nums opacity-75">{userReviews.length}</span>
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              activeTab === 'profile'
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow-xs'
                : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
            }`}
          >
            <span className="flex items-center gap-2">
              <UserIcon className="w-4 h-4" /> Profile & Security
            </span>
          </button>
        </aside>

        {/* Content Panel (9 cols) */}
        <main className="md:col-span-9">
          {/* TAB 1: DOWNLOADS */}
          {activeTab === 'downloads' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold text-neutral-900 dark:text-white">
                    Verified Digital Deliverables ({downloadTokens.length})
                  </h2>
                  <p className="text-xs text-neutral-500">
                    Cryptographic download tokens cleared by verified payment gateways.
                  </p>
                </div>
              </div>

              {downloadTokens.length === 0 ? (
                <div className="p-12 text-center bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200/80 dark:border-neutral-800">
                  <Download className="w-10 h-10 text-neutral-400 mx-auto mb-3" />
                  <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
                    No active digital downloads yet
                  </h3>
                  <p className="text-xs text-neutral-500 max-w-sm mx-auto mt-1 mb-6">
                    When you purchase eBooks, lossless audio stems, video packages, or 3D templates, your verified download tokens appear here immediately.
                  </p>
                  <button
                    onClick={() => navigate('marketplace')}
                    className="px-5 py-2.5 bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    Browse Digital Catalog
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {downloadTokens.map((token) => (
                    <div
                      key={token.id}
                      className="p-5 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
                            {token.productTitle}
                          </h3>
                          {token.isRevoked ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-100 text-rose-700">
                              Revoked
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                              Payment Verified
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-neutral-500">
                          <span className="font-medium text-neutral-800 dark:text-neutral-200">
                            {token.fileFormat}
                          </span>
                          <span>·</span>
                          <span>{token.fileSize}</span>
                          <span>·</span>
                          <span>Order: <strong className="font-mono text-neutral-700 dark:text-neutral-300">{token.orderNumber}</strong></span>
                        </div>
                        <div className="text-[11px] text-neutral-400 font-mono">
                          Remaining attempts: <strong className="text-neutral-700 dark:text-neutral-300">{token.downloadsRemaining} / {token.maxDownloads}</strong> · Valid until: {token.expiresAt.split('T')[0]}
                        </div>
                      </div>

                      <button
                        onClick={() => downloadProduct(token)}
                        disabled={token.isRevoked || token.downloadsRemaining <= 0}
                        className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 rounded-xl text-xs font-semibold shadow transition-colors flex items-center justify-center gap-2 disabled:opacity-40 shrink-0 cursor-pointer"
                      >
                        <Download className="w-4 h-4" /> Download Files Now
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: ORDERS */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              <h2 className="text-base font-bold text-neutral-900 dark:text-white">
                Purchase Order Receipts ({orders.length})
              </h2>

              {orders.length === 0 ? (
                <div className="p-12 text-center bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800">
                  <ShoppingBag className="w-8 h-8 text-neutral-400 mx-auto mb-3" />
                  <p className="text-xs text-neutral-500">No previous orders recorded in this session.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {orders.map((order) => (
                    <div
                      key={order.id}
                      className="p-5 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 space-y-4 shadow-xs"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800 gap-2 text-xs">
                        <div>
                          <span className="font-bold text-neutral-900 dark:text-white">
                            Order {order.orderNumber}
                          </span>
                          <span className="text-neutral-400 ml-2">
                            {order.createdAt.split('T')[0]}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2 py-0.5 rounded text-[11px] font-semibold uppercase ${
                              order.paymentStatus === 'paid'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {order.paymentStatus === 'paid' ? 'Payment Verified' : order.paymentStatus}
                          </span>
                          <span className="font-bold text-neutral-900 dark:text-white tabular-nums">
                            Total: ${order.total.toFixed(2)}
                          </span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="flex items-center justify-between text-xs">
                            <span className="text-neutral-800 dark:text-neutral-200 font-medium">
                              {item.productTitle} ({item.license} license)
                            </span>
                            <span className="font-mono tabular-nums text-neutral-600 dark:text-neutral-400">
                              ${item.price.toFixed(2)}
                            </span>
                          </div>
                        ))}
                      </div>

                      {order.paymentVerificationDetails && (
                        <div className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/50 text-[11px] font-mono text-neutral-500 space-y-0.5 border border-neutral-200/60 dark:border-neutral-700/50">
                          <div>Auth Code: {order.paymentVerificationDetails.authCode}</div>
                          <div>Digest: {order.paymentVerificationDetails.transactionHash}</div>
                          <div>Standard: {order.paymentVerificationDetails.securityStandard}</div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: WISHLIST */}
          {activeTab === 'wishlist' && (
            <div className="space-y-4">
              <h2 className="text-base font-bold text-neutral-900 dark:text-white">
                Saved Wishlist ({wishlistedProducts.length})
              </h2>
              {wishlistedProducts.length === 0 ? (
                <div className="p-12 text-center bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800">
                  <Heart className="w-8 h-8 text-neutral-400 mx-auto mb-3" />
                  <p className="text-xs text-neutral-500">Your wishlist is currently empty.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {wishlistedProducts.map((p) => (
                    <ProductCard key={p.id} product={p} />
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: REVIEWS */}
          {activeTab === 'reviews' && (
            <div className="space-y-4">
              <h2 className="text-base font-bold text-neutral-900 dark:text-white">
                Reviews You Have Submitted ({userReviews.length})
              </h2>
              {userReviews.length === 0 ? (
                <div className="p-12 text-center bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800">
                  <Star className="w-8 h-8 text-neutral-400 mx-auto mb-3" />
                  <p className="text-xs text-neutral-500">No reviews submitted yet.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {userReviews.map((rev) => (
                    <div
                      key={rev.id}
                      className="p-4 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200 dark:border-neutral-800 text-xs"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex text-amber-400">
                          {[...Array(rev.rating)].map((_, i) => (
                            <Star key={i} className="w-3.5 h-3.5 fill-current" />
                          ))}
                        </div>
                        <span className="text-neutral-400">{rev.date}</span>
                      </div>
                      <p className="text-neutral-700 dark:text-neutral-300">{rev.comment}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: PROFILE & SETTINGS */}
          {activeTab === 'profile' && (
            <div className="p-6 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 space-y-6">
              <h2 className="text-base font-bold text-neutral-900 dark:text-white">
                Account & Preferences
              </h2>
              <div className="space-y-4 max-w-md text-xs">
                <div>
                  <label className="block text-neutral-600 dark:text-neutral-400 font-medium mb-1">
                    Display Name
                  </label>
                  <input
                    type="text"
                    defaultValue={currentUser?.name || ''}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700"
                  />
                </div>
                <div>
                  <label className="block text-neutral-600 dark:text-neutral-400 font-medium mb-1">
                    Account Email
                  </label>
                  <input
                    type="email"
                    defaultValue={currentUser?.email || ''}
                    disabled
                    className="w-full p-2.5 bg-neutral-100 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 opacity-70"
                  />
                </div>
                <div>
                  <label className="block text-neutral-600 dark:text-neutral-400 font-medium mb-1">
                    Security Notification Preferences
                  </label>
                  <div className="space-y-2 pt-1 text-neutral-700 dark:text-neutral-300">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" defaultChecked className="accent-neutral-900" />
                      <span>Email me instantly when purchase download links are verified and issued</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" defaultChecked className="accent-neutral-900" />
                      <span>Notify me of creator updates and new revisions to purchased assets</span>
                    </label>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => showToast('success', 'Profile Updated')}
                  className="px-4 py-2 bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 rounded-xl font-semibold cursor-pointer"
                >
                  Save Preferences
                </button>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
