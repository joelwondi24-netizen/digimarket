import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Lock, Mail, User, ShieldCheck } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, setIsAuthModalOpen, loginAs, showToast } = useApp();
  const [isSignUp, setIsSignUp] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);

  if (!isAuthModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loginAs('customer');
    showToast('success', isSignUp ? 'Account Created' : 'Welcome Back!');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 rounded-3xl max-w-md w-full overflow-hidden border border-neutral-200 dark:border-neutral-800 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold font-display">
              {isSignUp ? 'Create DigiMarket Account' : 'Sign in to DigiMarket'}
            </h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Access your digital downloads & verified licenses
            </p>
          </div>
          <button
            onClick={() => setIsAuthModalOpen(false)}
            className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-4 text-xs">
          {/* Quick Demo Switcher */}
          <div className="p-3 bg-neutral-100 dark:bg-neutral-800 rounded-xl space-y-2">
            <span className="text-[10px] uppercase font-bold text-neutral-500 tracking-wider">
              Quick Role Switcher for Prototyping
            </span>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                type="button"
                onClick={() => loginAs('customer')}
                className="py-1.5 px-2 bg-white dark:bg-neutral-900 rounded-lg font-semibold shadow-xs hover:bg-neutral-200 dark:hover:bg-neutral-700 text-center cursor-pointer"
              >
                Buyer
              </button>
              <button
                type="button"
                onClick={() => loginAs('seller')}
                className="py-1.5 px-2 bg-white dark:bg-neutral-900 rounded-lg font-semibold shadow-xs hover:bg-neutral-200 dark:hover:bg-neutral-700 text-center cursor-pointer"
              >
                Creator
              </button>
              <button
                type="button"
                onClick={() => loginAs('admin')}
                className="py-1.5 px-2 bg-white dark:bg-neutral-900 rounded-lg font-semibold shadow-xs hover:bg-neutral-200 dark:hover:bg-neutral-700 text-center cursor-pointer text-blue-600 dark:text-blue-400 font-bold"
              >
                Admin
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3 pt-2">
            {isSignUp && (
              <div>
                <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                  Full Name
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Alex Rivera"
                    className="w-full pl-8 pr-3 py-2 bg-neutral-50 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 focus:outline-none"
                  />
                  <User className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                </div>
              </div>
            )}

            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Email Address
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="alex.rivera@example.com"
                  className="w-full pl-8 pr-3 py-2 bg-neutral-50 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 focus:outline-none"
                />
                <Mail className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Password
              </label>
              <div className="relative">
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-8 pr-3 py-2 bg-neutral-50 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 focus:outline-none"
                />
                <Lock className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] pt-1">
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="accent-neutral-900"
                />
                <span>Remember me</span>
              </label>
              {!isSignUp && (
                <button
                  type="button"
                  onClick={() => showToast('info', 'Password Reset', 'Password recovery instructions sent to your email.')}
                  className="text-neutral-500 hover:text-neutral-900 dark:hover:text-white underline cursor-pointer"
                >
                  Forgot password?
                </button>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 rounded-xl font-bold transition-all shadow mt-2 cursor-pointer"
            >
              {isSignUp ? 'Create Free Account' : 'Sign In'}
            </button>
          </form>

          {/* Toggle between Login and Signup */}
          <div className="text-center pt-2 text-neutral-500 text-[11px]">
            {isSignUp ? (
              <span>
                Already have an account?{' '}
                <button
                  onClick={() => setIsSignUp(false)}
                  className="font-semibold text-neutral-900 dark:text-white underline cursor-pointer"
                >
                  Sign in
                </button>
              </span>
            ) : (
              <span>
                Don't have an account yet?{' '}
                <button
                  onClick={() => setIsSignUp(true)}
                  className="font-semibold text-neutral-900 dark:text-white underline cursor-pointer"
                >
                  Create account
                </button>
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
