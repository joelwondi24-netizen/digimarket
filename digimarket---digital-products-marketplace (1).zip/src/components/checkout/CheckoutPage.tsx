import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  CreditCard,
  Lock,
  Download,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Layers,
  FileText,
  KeyRound,
  Check,
} from 'lucide-react';
import { Order } from '../../types';

export const CheckoutPage: React.FC = () => {
  const {
    cart,
    currentUser,
    completeCheckout,
    downloadProduct,
    navigate,
    applyCoupon,
    showToast,
  } = useApp();

  const [customerName, setCustomerName] = useState(currentUser?.name || 'Alex Rivera');
  const [customerEmail, setCustomerEmail] = useState(currentUser?.email || 'alex.rivera@example.com');
  const [paymentMethod, setPaymentMethod] = useState<'stripe' | 'paypal' | 'apple_pay'>('stripe');

  // Coupon state
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{
    code: string;
    discount: number;
    description: string;
  } | null>(null);

  // Card inputs (simulated)
  const [cardNumber, setCardNumber] = useState('•••• •••• •••• 4242');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvc, setCardCvc] = useState('888');

  // Processing & verification state
  const [isProcessing, setIsProcessing] = useState(false);
  const [verificationStep, setVerificationStep] = useState<string>('');
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  const subtotal = cart.reduce((acc, item) => acc + item.price, 0);
  const discountAmount = appliedCoupon ? appliedCoupon.discount : 0;
  const total = Math.max(0, subtotal - discountAmount);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode.trim()) return;
    const res = applyCoupon(couponCode, subtotal);
    if (res.success && res.coupon) {
      setAppliedCoupon({
        code: res.coupon.code,
        discount: res.discount,
        description: res.coupon.description,
      });
      showToast('success', 'Coupon Applied', res.coupon.description);
    } else {
      showToast('error', 'Invalid Coupon', res.message);
    }
  };

  const handleSubmitPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) {
      showToast('error', 'Cart is empty');
      return;
    }

    setIsProcessing(true);
    setVerificationStep('Authenticating 3D-Secure payment credentials...');

    setTimeout(() => {
      setVerificationStep('Verifying PCI-DSS bank clearance & transaction signature...');
      setTimeout(() => {
        setVerificationStep('Generating cryptographic download tokens & license certificate...');
        setTimeout(() => {
          const order = completeCheckout(
            customerName,
            customerEmail,
            paymentMethod,
            appliedCoupon
              ? {
                  code: appliedCoupon.code,
                  discountAmount: appliedCoupon.discount,
                  description: appliedCoupon.description,
                  expiresAt: '',
                  isActive: true,
                }
              : undefined
          );
          setCompletedOrder(order);
          setIsProcessing(false);
          setVerificationStep('');
        }, 600);
      }, 700);
    }, 600);
  };

  // SUCCESS STATE: Post-payment verified delivery screen
  if (completedOrder) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto mb-4 border border-emerald-300 dark:border-emerald-800 shadow-sm">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest bg-emerald-50 dark:bg-emerald-950/40 px-3 py-1 rounded-full border border-emerald-200 dark:border-emerald-800">
            Payment Cleared & Cryptographically Verified
          </span>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-neutral-950 dark:text-white mt-3">
            Your Digital Downloads Are Ready
          </h1>
          <p className="text-xs text-neutral-500 mt-2 max-w-lg mx-auto">
            Order Reference <span className="font-mono font-bold text-neutral-900 dark:text-neutral-100">{completedOrder.orderNumber}</span> · Authorization Digest: <span className="font-mono text-neutral-700 dark:text-neutral-300 text-[11px]">{completedOrder.paymentVerificationDetails?.transactionHash.substring(0, 18)}...</span>
          </p>
        </div>

        {/* Security Verification Certificate Banner */}
        <div className="p-4 rounded-2xl bg-neutral-900 text-white dark:bg-black border border-neutral-800 shadow-md mb-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-neutral-800 text-emerald-400 shrink-0">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-white">TLS 256-Bit Cryptographic Licensing Active</div>
              <div className="text-[11px] text-neutral-400">
                A verified receipt has also been dispatched to <strong className="text-white">{completedOrder.customerEmail}</strong>.
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 text-[11px] text-neutral-400">
            <Check className="w-3.5 h-3.5 text-emerald-400" />
            <span>5 Instant Downloads Allotted per File</span>
          </div>
        </div>

        {/* Deliverable Downloads Card Stack */}
        <div className="bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 p-6 sm:p-8 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-neutral-100 dark:border-neutral-800 pb-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              Verified Digital Deliverables ({completedOrder.downloadTokens.length})
            </h3>
            <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">
              30-Day Guaranteed Link Renewal
            </span>
          </div>

          <div className="space-y-3">
            {completedOrder.downloadTokens.map((token) => (
              <div
                key={token.id}
                className="p-5 rounded-2xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200/80 dark:border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-neutral-900 dark:text-white">
                      {token.productTitle}
                    </h4>
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                      Payment Verified
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-neutral-500">
                    <span className="font-medium text-neutral-700 dark:text-neutral-300">{token.fileFormat}</span>
                    <span>·</span>
                    <span>{token.fileSize}</span>
                    <span>·</span>
                    <span className="text-neutral-600 dark:text-neutral-400 font-mono text-[11px]">
                      {token.downloadsRemaining} / {token.maxDownloads} attempts available
                    </span>
                  </div>
                  <div className="text-[11px] font-mono text-neutral-400 truncate max-w-sm">
                    Token ID: {token.token}
                  </div>
                </div>

                <button
                  onClick={() => downloadProduct(token)}
                  className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 rounded-xl text-xs font-bold transition-all shadow flex items-center justify-center gap-2 cursor-pointer shrink-0"
                >
                  <Download className="w-4 h-4" /> Download Files Now
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Action navigation */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
          <button
            onClick={() => navigate('account')}
            className="px-5 py-2.5 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 text-neutral-900 dark:text-white rounded-xl text-xs font-semibold flex items-center gap-2 cursor-pointer"
          >
            <Layers className="w-4 h-4" /> View in Customer Account
          </button>
          <button
            onClick={() => navigate('marketplace')}
            className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 rounded-xl text-xs font-semibold flex items-center gap-2 cursor-pointer"
          >
            <span>Continue Marketplace Shopping</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  // CHECKOUT FORM
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold font-display text-neutral-950 dark:text-white">
          Secure Digital Checkout
        </h1>
        <p className="text-xs text-neutral-500 mt-1">
          Instant digital delivery with automated payment clearance verification.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
        {/* Left Column: Customer Info & Payment Method (7 cols) */}
        <div className="lg:col-span-7 space-y-8">
          <form onSubmit={handleSubmitPayment} id="checkout-form" className="space-y-6">
            {/* Section 1: Customer Contact Information */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
              <h2 className="text-sm font-bold text-neutral-900 dark:text-white mb-1">
                1. Customer & Delivery Information
              </h2>
              <p className="text-xs text-neutral-500 mb-4">
                Your download link and cryptographic licensing key will be delivered to this email.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-neutral-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-neutral-400"
                  />
                </div>
              </div>
            </div>

            {/* Section 2: Payment Provider Selection */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
              <div className="flex items-center justify-between mb-1">
                <h2 className="text-sm font-bold text-neutral-900 dark:text-white">
                  2. Payment Method
                </h2>
                <span className="text-[11px] text-neutral-400 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-emerald-500" /> 256-Bit SSL Encrypted
                </span>
              </div>
              <p className="text-xs text-neutral-500 mb-4">
                Choose your preferred payment gateway. Automated verification clearance enabled.
              </p>

              {/* Gateway Tabs */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('stripe')}
                  className={`p-3 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                    paymentMethod === 'stripe'
                      ? 'border-neutral-900 bg-neutral-900 text-white dark:border-white dark:bg-white dark:text-neutral-950 shadow-sm'
                      : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:border-neutral-400'
                  }`}
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Stripe / Card</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('paypal')}
                  className={`p-3 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                    paymentMethod === 'paypal'
                      ? 'border-neutral-900 bg-neutral-900 text-white dark:border-white dark:bg-white dark:text-neutral-950 shadow-sm'
                      : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:border-neutral-400'
                  }`}
                >
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>PayPal</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('apple_pay')}
                  className={`p-3 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                    paymentMethod === 'apple_pay'
                      ? 'border-neutral-900 bg-neutral-900 text-white dark:border-white dark:bg-white dark:text-neutral-950 shadow-sm'
                      : 'border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:border-neutral-400'
                  }`}
                >
                  <Lock className="w-4 h-4 text-blue-500" />
                  <span>Apple Pay</span>
                </button>
              </div>

              {/* Card Inputs */}
              {paymentMethod === 'stripe' && (
                <div className="space-y-3 pt-2">
                  <div>
                    <label className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                      Card Number
                    </label>
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      placeholder="4242 4242 4242 4242"
                      className="w-full px-3 py-2 text-xs bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-white font-mono focus:outline-none"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                        Expiry Date
                      </label>
                      <input
                        type="text"
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        placeholder="MM/YY"
                        className="w-full px-3 py-2 text-xs bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-white font-mono focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-neutral-700 dark:text-neutral-300 mb-1">
                        CVC Security Code
                      </label>
                      <input
                        type="text"
                        value={cardCvc}
                        onChange={(e) => setCardCvc(e.target.value)}
                        placeholder="CVC"
                        className="w-full px-3 py-2 text-xs bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-xl text-neutral-900 dark:text-white font-mono focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              {paymentMethod === 'paypal' && (
                <div className="p-4 bg-amber-50 dark:bg-amber-950/30 rounded-xl border border-amber-200 dark:border-amber-900/50 text-xs text-amber-800 dark:text-amber-300">
                  You will authenticate with PayPal sandbox. After clearance verification, your download tokens will generate instantly.
                </div>
              )}

              {paymentMethod === 'apple_pay' && (
                <div className="p-4 bg-neutral-100 dark:bg-neutral-800 rounded-xl text-xs text-neutral-700 dark:text-neutral-300">
                  Touch ID / Face ID simulation ready. Biometric cryptographic tokens issued upon verification.
                </div>
              )}
            </div>

            {/* Verification status feedback if running */}
            {isProcessing && verificationStep && (
              <div className="p-4 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 rounded-xl flex items-center gap-3 text-blue-800 dark:text-blue-300 text-xs animate-pulse">
                <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin shrink-0" />
                <span>{verificationStep}</span>
              </div>
            )}

            {/* Primary Submit Button */}
            <button
              type="submit"
              disabled={isProcessing || cart.length === 0}
              className="w-full py-4 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 rounded-2xl text-sm font-bold shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white dark:border-neutral-950 border-t-transparent rounded-full animate-spin" />
                  <span>Verifying Payment Clearance...</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Verify Payment & Download (${total.toFixed(2)})</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right Column: Order Summary (5 cols) */}
        <div className="lg:col-span-5 bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 shadow-sm space-y-6">
          <div>
            <h2 className="text-sm font-bold text-neutral-900 dark:text-white">
              Order Summary ({cart.length} digital items)
            </h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Verified digital download bundle
            </p>
          </div>

          {/* Cart items */}
          <div className="divide-y divide-neutral-100 dark:divide-neutral-800 max-h-72 overflow-y-auto pr-1">
            {cart.map((item) => (
              <div key={item.product.id} className="py-3 flex items-center gap-3">
                <img
                  src={item.product.thumbnail}
                  alt={item.product.title}
                  referrerPolicy="no-referrer"
                  className="w-12 h-12 rounded-lg object-cover bg-neutral-100 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-semibold text-neutral-900 dark:text-white truncate">
                    {item.product.title}
                  </h4>
                  <p className="text-[11px] text-neutral-500 capitalize">
                    {item.license} License · {item.product.fileFormat.split('+')[0]}
                  </p>
                </div>
                <div className="text-xs font-bold text-neutral-900 dark:text-white tabular-nums">
                  ${item.price.toFixed(2)}
                </div>
              </div>
            ))}
          </div>

          {/* Coupon Code section */}
          <form onSubmit={handleApplyCoupon} className="flex gap-2">
            <input
              type="text"
              value={couponCode}
              onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
              placeholder="Coupon (WELCOME10)"
              className="flex-1 px-3 py-1.5 text-xs bg-neutral-50 dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg text-neutral-900 dark:text-white font-mono uppercase"
            />
            <button
              type="submit"
              className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-xs font-semibold cursor-pointer"
            >
              Apply
            </button>
          </form>

          {appliedCoupon && (
            <div className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center justify-between bg-emerald-50 dark:bg-emerald-950/40 p-2 rounded-lg">
              <span>Code {appliedCoupon.code} (-${appliedCoupon.discount.toFixed(2)})</span>
              <button
                type="button"
                onClick={() => setAppliedCoupon(null)}
                className="text-neutral-400 hover:text-neutral-700 text-[11px] cursor-pointer"
              >
                Remove
              </button>
            </div>
          )}

          {/* Subtotal, discount & total breakdown */}
          <div className="space-y-2 text-xs text-neutral-600 dark:text-neutral-400 pt-4 border-t border-neutral-200 dark:border-neutral-800">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span className="font-semibold text-neutral-900 dark:text-white tabular-nums">
                ${subtotal.toFixed(2)}
              </span>
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between text-emerald-600 dark:text-emerald-400">
                <span>Discount</span>
                <span className="font-semibold tabular-nums">-${discountAmount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between text-neutral-500 text-[11px]">
              <span>Delivery Protocol</span>
              <span className="text-emerald-600 font-medium">Instant Verified Digital Token</span>
            </div>
            <div className="flex justify-between text-base font-bold text-neutral-900 dark:text-white pt-3 border-t border-neutral-200 dark:border-neutral-800">
              <span>Total Due</span>
              <span className="tabular-nums">${total.toFixed(2)}</span>
            </div>
          </div>

          <div className="p-3.5 bg-neutral-50 dark:bg-neutral-800/40 rounded-xl text-[11px] text-neutral-500 space-y-1.5">
            <div className="flex items-center gap-1.5 font-medium text-neutral-800 dark:text-neutral-200">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              <span>Verified Download Policy</span>
            </div>
            <p>
              Once your payment is verified, your cryptographic tokens remain active for 30 days and are permanently archived in your customer dashboard for lifetime license renewal.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
