import React, { useState } from 'react';
import { Product } from '../../types';
import { useApp } from '../../context/AppContext';
import { X, BookOpen, ChevronLeft, ChevronRight, ShoppingBag } from 'lucide-react';

interface EbookPreviewModalProps {
  product: Product;
  onClose: () => void;
}

export const EbookPreviewModal: React.FC<EbookPreviewModalProps> = ({ product, onClose }) => {
  const { addToCart } = useApp();
  const [currentPage, setCurrentPage] = useState(1);
  const totalSamplePages = 3;

  const samplePages = [
    {
      page: 1,
      title: 'Title & Copyright Page',
      subtitle: product.title,
      author: product.sellerName,
      body: `First Edition Published 2026\nCopyright © ${new Date().getFullYear()} ${product.sellerName}\nAll rights reserved under international copyright conventions.\n\nNotice: This is a protected excerpt preview. The complete deliverable package contains ${product.ebookMeta?.pageCount || 240} publication pages with high-resolution vector diagrams and interactive Notion hubs.\n\nISBN (Digital): ${product.ebookMeta?.isbn || '978-1-954829-01-2'}\nFormatted for: Apple Books, Kindle, PDF Readers`,
    },
    {
      page: 2,
      title: 'Table of Contents & Structure',
      subtitle: 'Overview of Core Modules',
      author: 'Editorial Board',
      body: product.ebookMeta?.tableOfContents?.join('\n') || `PART I: FOUNDATIONAL INVARIANTS\n1. Eliminating AI Slop: The Zero-Pill Aesthetic Rule .......... 14\n2. Spatial Math & Viewport Balance (Desktop & Mobile) ........ 38\n3. High-Throughput System Architecture & Micro-APIs ......... 72\n\nPART II: OPERATIONAL SCALE\n4. Unit Economics: CAC, Gross Margins & Payback Periods ..... 110\n5. Developer Velocity & Real-Time Sync Protocols ........... 154\n6. The 80/20 Creator Marketplace Distribution Model .......... 198\n\nAPPENDIX: Notion Operating Workspaces & Financial Sheets ..... 232`,
    },
    {
      page: 3,
      title: product.ebookMeta?.sampleChapterTitle || 'Chapter 1: The Foundational Invariant',
      subtitle: 'Designing with Intentional Restraint',
      author: product.sellerName,
      body: product.sampleContent || `Every exceptional digital product begins with a commitment to functional clarity. In an era overwhelmed by generic purple gradients and floating decorative cards, the winning software products are those built with typographic rigor and authentic domain utility.\n\n"Perfection is attained not when there is nothing more to add, but when there is nothing left to take away."\n\nWhen structuring your initial release, isolate the single core metric that proves value before asking for enterprise commitments. The subsequent chapters outline exact step-by-step telemetry, contract specs, and pricing strategies to execute this successfully.`,
    },
  ];

  const currentContent = samplePages[currentPage - 1];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden border border-neutral-200 dark:border-neutral-800 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center gap-2 text-xs text-neutral-600 dark:text-neutral-400">
            <BookOpen className="w-4 h-4 text-amber-500" />
            <span>Sample Reader · Page {currentPage} of {totalSamplePages} ({product.ebookMeta?.pageCount || 240} Full Pages)</span>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-neutral-700 dark:hover:text-white p-1 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Reader Body with Protected Watermark */}
        <div className="relative flex-1 p-6 md:p-10 overflow-y-auto bg-neutral-50 dark:bg-neutral-950 font-serif leading-relaxed select-none">
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center opacity-4 text-neutral-900 dark:text-white rotate-[-30deg] font-sans text-5xl font-black uppercase tracking-widest">
            DIGIMARKET PREVIEW
          </div>

          <div className="max-w-md mx-auto space-y-4">
            <div className="border-b border-neutral-200 dark:border-neutral-800 pb-4">
              <span className="text-[11px] font-sans uppercase font-bold tracking-widest text-neutral-400">
                {currentContent.title}
              </span>
              <h2 className="text-xl font-bold font-sans text-neutral-900 dark:text-white mt-1">
                {currentContent.subtitle}
              </h2>
              <p className="text-xs font-sans text-neutral-500 mt-1">
                {currentContent.author}
              </p>
            </div>
            <pre className="font-serif text-sm text-neutral-700 dark:text-neutral-300 whitespace-pre-wrap leading-relaxed">
              {currentContent.body}
            </pre>
          </div>
        </div>

        {/* Navigation & Controls */}
        <div className="p-4 bg-white dark:bg-neutral-900 border-t border-neutral-200 dark:border-neutral-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <button
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              className="p-2 border border-neutral-200 dark:border-neutral-700 rounded-lg text-neutral-600 dark:text-neutral-300 disabled:opacity-30 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs text-neutral-500 font-sans tabular-nums">
              Sample {currentPage}/{totalSamplePages}
            </span>
            <button
              disabled={currentPage >= totalSamplePages}
              onClick={() => setCurrentPage((p) => Math.min(totalSamplePages, p + 1))}
              className="p-2 border border-neutral-200 dark:border-neutral-700 rounded-lg text-neutral-600 dark:text-neutral-300 disabled:opacity-30 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <div className="text-[11px] text-neutral-400">Full Verified Deliverable</div>
              <div className="text-sm font-bold text-neutral-900 dark:text-white tabular-nums">
                ${product.price.toFixed(2)}
              </div>
            </div>
            <button
              onClick={() => {
                addToCart(product);
                onClose();
              }}
              className="flex items-center gap-2 px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 rounded-xl text-xs font-semibold shadow transition-colors cursor-pointer"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              Purchase Full eBook
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
