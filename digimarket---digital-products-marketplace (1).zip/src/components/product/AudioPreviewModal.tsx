import React, { useState, useEffect } from 'react';
import { Product } from '../../types';
import { useApp } from '../../context/AppContext';
import { X, Play, Pause, Volume2, ShoppingBag, Disc3, Music2 } from 'lucide-react';
import { previewSynth } from '../../utils/audioSynth';

interface AudioPreviewModalProps {
  product: Product;
  onClose: () => void;
}

export const AudioPreviewModal: React.FC<AudioPreviewModalProps> = ({ product, onClose }) => {
  const { addToCart } = useApp();
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(30);

  useEffect(() => {
    // Start playback when opened
    handlePlay();
    return () => {
      previewSynth.stop();
    };
  }, [product]);

  const handlePlay = () => {
    setIsPlaying(true);
    previewSynth.play((cur, dur) => {
      setCurrentTime(cur);
      setDuration(dur);
    });
  };

  const handlePause = () => {
    setIsPlaying(false);
    previewSynth.stop();
  };

  const togglePlayback = () => {
    if (isPlaying) {
      handlePause();
    } else {
      handlePlay();
    }
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainder = Math.floor(secs % 60);
    return `${mins}:${remainder < 10 ? '0' : ''}${remainder}`;
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-neutral-900 text-white rounded-2xl max-w-lg w-full overflow-hidden border border-neutral-800 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-neutral-800">
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <Volume2 className="w-4 h-4 text-amber-400" />
            <span>Lossless Audio Preview (30s Audio Stems Demo)</span>
          </div>
          <button
            onClick={() => {
              handlePause();
              onClose();
            }}
            className="text-neutral-400 hover:text-white p-1 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 flex flex-col items-center text-center">
          <div className="relative w-36 h-36 rounded-xl overflow-hidden shadow-lg mb-4 border border-neutral-700">
            <img
              src={product.thumbnail}
              alt={product.title}
              className={`w-full h-full object-cover transition-transform duration-700 ${isPlaying ? 'scale-105' : ''}`}
            />
            <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
              <Disc3
                className={`w-12 h-12 text-white/80 transition-transform ${
                  isPlaying ? 'animate-spin' : ''
                }`}
                style={{ animationDuration: '4s' }}
              />
            </div>
          </div>

          <h3 className="text-base font-semibold text-white max-w-xs">{product.title}</h3>
          <p className="text-xs text-neutral-400 mt-1">
            Composed by {product.sellerName} · {product.fileFormat}
          </p>

          {/* Technical Audio Metadata if available */}
          {product.audioMeta && (
            <div className="flex items-center gap-3 text-[11px] text-neutral-400 font-mono mt-2 bg-neutral-800/60 px-3 py-1 rounded-lg">
              <span>BPM: {product.audioMeta.bpm || '72'}</span>
              <span>·</span>
              <span>Key: {product.audioMeta.musicalKey || 'D Minor'}</span>
              <span>·</span>
              <span>{product.audioMeta.sampleRate || '24-bit/96kHz'}</span>
            </div>
          )}

          {/* Animated Waveform Visualizer */}
          <div className="flex items-center justify-center gap-1 h-12 my-6 w-full max-w-xs px-2">
            {[35, 60, 40, 85, 55, 90, 75, 45, 80, 95, 70, 50, 65, 85, 40, 60, 90, 45].map((height, i) => (
              <span
                key={i}
                className="w-1.5 bg-amber-400 rounded-full transition-all duration-150"
                style={{
                  height: isPlaying ? `${Math.max(15, ((height * ((currentTime % 2) + 0.5)) % 100))}%` : '15%',
                  opacity: (i / 18) * 100 <= progressPercent ? 1 : 0.35,
                }}
              />
            ))}
          </div>

          {/* Progress Bar */}
          <div className="w-full max-w-xs">
            <div className="w-full bg-neutral-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-amber-400 h-full transition-all duration-100"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <div className="flex justify-between text-[11px] text-neutral-400 font-mono mt-1.5">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Play/Pause Control */}
          <div className="mt-6 flex items-center justify-center gap-4">
            <button
              onClick={togglePlayback}
              className="w-14 h-14 rounded-full bg-amber-400 hover:bg-amber-300 text-neutral-950 flex items-center justify-center shadow-lg transition-transform hover:scale-105 active:scale-95 cursor-pointer"
              aria-label={isPlaying ? 'Pause preview' : 'Play preview'}
            >
              {isPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current ml-0.5" />}
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-neutral-950 border-t border-neutral-800 flex items-center justify-between">
          <div>
            <div className="text-xs text-neutral-400">Full Audio Package</div>
            <div className="text-sm font-bold text-white tabular-nums">${product.price.toFixed(2)}</div>
          </div>
          <button
            onClick={() => {
              addToCart(product);
              handlePause();
              onClose();
            }}
            className="flex items-center gap-2 px-4 py-2 bg-white hover:bg-neutral-100 text-neutral-950 rounded-xl text-xs font-semibold shadow transition-colors cursor-pointer"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};
