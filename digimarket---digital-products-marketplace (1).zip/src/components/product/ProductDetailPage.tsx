import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Product, LicenseType } from '../../types';
import {
  Star,
  Download,
  Heart,
  ShoppingBag,
  ShieldCheck,
  Check,
  Play,
  BookOpen,
  Eye,
  FileCode,
  Share2,
  Sparkles,
  ArrowRight,
  Send,
  Lock,
} from 'lucide-react';
import { AudioPreviewModal } from './AudioPreviewModal';
import { EbookPreviewModal } from './EbookPreviewModal';
import { ImagePreviewModal } from './ImagePreviewModal';
import { ProductCard } from '../marketplace/ProductCard';

export const ProductDetailPage: React.FC = () => {
  const {
    selectedProduct,
    products,
    sellers,
    addToCart,
    toggleWishlist,
    isInWishlist,
    reviews,
    addReview,
    navigate,
    showToast,
  } = useApp();

  const product = selectedProduct || products[0];
  const [selectedLicense, setSelectedLicense] = useState<LicenseType>('commercial');
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  // Modals state
  const [isAudioModalOpen, setIsAudioModalOpen] = useState(false);
  const [isEbookModalOpen, setIsEbookModalOpen] = useState(false);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);

  // Review state
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);

  const wishlisted = isInWishlist(product.id);
  const seller = sellers.find((s) => s.id === product.sellerId) || sellers[0];
  const productReviews = reviews.filter((r) => r.productId === product.id && r.status === 'approved');

  // License pricing multiplier
  let licenseMultiplier = 1;
  if (selectedLicense === 'personal') licenseMultiplier = 0.8;
  if (selectedLicense === 'extended') licenseMultiplier = 2.5;

  const currentPrice = Number((product.price * licenseMultiplier).toFixed(2));

  // Related products
  const relatedProducts = products
    .filter((p) => p.id !== product.id && (p.category === product.category || p.sellerId === product.sellerId))
    .slice(0, 3);

  const handleBuyNow = () => {
    addToCart(product, selectedLicense);
    navigate('checkout');
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    setIsSubmittingReview(true);
    setTimeout(() => {
      addReview(product.id, newRating, newComment.trim());
      setNewComment('');
      setIsSubmittingReview(false);
    }, 400);
  };

  const handleShare = () => {
    navigator.clipboard?.writeText?.(window.location.href);
    showToast('success', 'Link Copied', 'Product link copied to clipboard.');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
      {/* Breadcrumb Navigation */}
      <nav aria-label="Breadcrumb" className="mb-6 flex items-center gap-2 text-xs text-neutral-500">
        <button onClick={() => navigate('home')} className="hover:text-neutral-900 dark:hover:text-white cursor-pointer">
          Home
        </button>
        <span aria-hidden="true">/</span>
        <button
          onClick={() => navigate('marketplace', { category: product.category })}
          className="hover:text-neutral-900 dark:hover:text-white cursor-pointer"
        >
          {product.category}
        </button>
        <span aria-hidden="true">/</span>
        <span className="text-neutral-800 dark:text-neutral-200 truncate max-w-xs">{product.title}</span>
      </nav>

      {/* Main PDP Grid (Sticky left visual, sticky right purchase panel) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
        {/* Left Column: Visual Gallery & Interactive Preview (7 cols) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          <div className="relative aspect-[4/3] w-full rounded-2xl overflow-hidden bg-neutral-100 dark:bg-neutral-800 border border-neutral-200/80 dark:border-neutral-800 shadow-sm">
            <img
              src={product.previewImages[activeImageIndex] || product.thumbnail}
              alt={product.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />

            {/* Quick interactive media triggers */}
            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                {product.category === 'Music' || product.category === 'Audio' ? (
                  <button
                    onClick={() => setIsAudioModalOpen(true)}
                    className="flex items-center gap-2 px-3 py-2 bg-neutral-950/80 hover:bg-neutral-950 text-white rounded-xl text-xs font-semibold backdrop-blur-md shadow-lg transition-transform hover:scale-102 cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 fill-current text-amber-400" /> Listen to Audio Preview
                  </button>
                ) : product.category === 'eBooks' ? (
                  <button
                    onClick={() => setIsEbookModalOpen(true)}
                    className="flex items-center gap-2 px-3 py-2 bg-neutral-950/80 hover:bg-neutral-950 text-white rounded-xl text-xs font-semibold backdrop-blur-md shadow-lg transition-transform hover:scale-102 cursor-pointer"
                  >
                    <BookOpen className="w-3.5 h-3.5 text-amber-400" /> Read Sample Chapters
                  </button>
                ) : (
                  <button
                    onClick={() => setIsImageModalOpen(true)}
                    className="flex items-center gap-2 px-3 py-2 bg-neutral-950/80 hover:bg-neutral-950 text-white rounded-xl text-xs font-semibold backdrop-blur-md shadow-lg transition-transform hover:scale-102 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5 text-amber-400" /> Zoom High-Res Preview
                  </button>
                )}
              </div>
              <button
                onClick={handleShare}
                className="p-2 bg-neutral-950/80 hover:bg-neutral-950 text-white rounded-xl backdrop-blur-md shadow-lg transition-colors cursor-pointer"
                title="Share link"
              >
                <Share2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Thumbnail Strip */}
          {product.previewImages.length > 1 && (
            <div className="flex items-center gap-3 overflow-x-auto pb-2">
              {product.previewImages.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIndex(idx)}
                  className={`w-20 h-16 rounded-xl overflow-hidden border-2 transition-all shrink-0 cursor-pointer ${
                    activeImageIndex === idx
                      ? 'border-neutral-900 dark:border-white shadow-xs'
                      : 'border-transparent opacity-60 hover:opacity-100'
                  }`}
                >
                  <img
                    src={img}
                    alt=""
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}

          {/* Technical Specifications by Category */}
          {(product.ebookMeta || product.audioMeta || product.videoMeta || product.imageMeta || product.templateMeta) && (
            <div className="p-4 bg-neutral-100/60 dark:bg-neutral-800/40 rounded-xl border border-neutral-200/80 dark:border-neutral-800">
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-900 dark:text-white mb-2">
                Technical Specifications
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                {product.ebookMeta?.pageCount && (
                  <div>
                    <span className="text-neutral-500">Pages:</span> <span className="font-semibold text-neutral-900 dark:text-white">{product.ebookMeta.pageCount}</span>
                  </div>
                )}
                {product.ebookMeta?.isbn && (
                  <div>
                    <span className="text-neutral-500">ISBN:</span> <span className="font-mono text-neutral-900 dark:text-white">{product.ebookMeta.isbn}</span>
                  </div>
                )}
                {product.audioMeta?.bpm && (
                  <div>
                    <span className="text-neutral-500">Tempo:</span> <span className="font-semibold text-neutral-900 dark:text-white">{product.audioMeta.bpm} BPM</span>
                  </div>
                )}
                {product.audioMeta?.musicalKey && (
                  <div>
                    <span className="text-neutral-500">Key:</span> <span className="font-semibold text-neutral-900 dark:text-white">{product.audioMeta.musicalKey}</span>
                  </div>
                )}
                {product.videoMeta?.resolution && (
                  <div>
                    <span className="text-neutral-500">Resolution:</span> <span className="font-semibold text-neutral-900 dark:text-white">{product.videoMeta.resolution}</span>
                  </div>
                )}
                {product.imageMeta?.dimensions && (
                  <div>
                    <span className="text-neutral-500">Dimensions:</span> <span className="font-semibold text-neutral-900 dark:text-white">{product.imageMeta.dimensions}</span>
                  </div>
                )}
                {product.imageMeta?.colorSpace && (
                  <div>
                    <span className="text-neutral-500">Color Space:</span> <span className="font-semibold text-neutral-900 dark:text-white">{product.imageMeta.colorSpace}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Description & Features */}
          <div className="mt-4 space-y-6 pt-6 border-t border-neutral-200 dark:border-neutral-800">
            <div>
              <h2 className="text-base font-bold text-neutral-950 dark:text-white mb-2">
                Overview & Description
              </h2>
              <p className="text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed">
                {product.description}
              </p>
            </div>

            {/* Key Features */}
            <div>
              <h3 className="text-sm font-semibold text-neutral-950 dark:text-white mb-3">
                Key Deliverables & Specifications
              </h3>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-neutral-600 dark:text-neutral-300">
                {product.features.map((feat, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* What's Included */}
            <div className="p-4 bg-neutral-100/70 dark:bg-neutral-800/40 rounded-xl border border-neutral-200/80 dark:border-neutral-800">
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-900 dark:text-white mb-2 flex items-center gap-1.5">
                <FileCode className="w-4 h-4 text-amber-500" /> Package Archive Contents
              </h3>
              <ul className="space-y-1.5 text-xs text-neutral-600 dark:text-neutral-400">
                {product.whatsIncluded.map((item, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-neutral-400" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              {product.systemRequirements && (
                <div className="mt-3 pt-3 border-t border-neutral-200 dark:border-neutral-700/60 text-[11px] text-neutral-500">
                  <strong>Requirements:</strong> {product.systemRequirements}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Contiguous Purchase Module (5 cols) */}
        <div className="lg:col-span-5 lg:sticky lg:top-24 flex flex-col gap-6 bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 shadow-sm">
          {/* Unboxed Metadata Line */}
          <div className="flex items-center gap-2 text-xs text-neutral-500 dark:text-neutral-400">
            <span className="font-semibold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider text-[11px]">
              {product.category}
            </span>
            <span aria-hidden="true">·</span>
            <span>{product.subcategory}</span>
            <span aria-hidden="true">·</span>
            <span>{product.fileSize}</span>
          </div>

          <div>
            <h1 className="text-xl sm:text-2xl font-bold font-display text-neutral-950 dark:text-white tracking-tight leading-snug">
              {product.title}
            </h1>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1.5">
              {product.tagline}
            </p>
          </div>

          {/* Ratings & Downloads */}
          <div className="flex items-center justify-between py-2 border-y border-neutral-100 dark:border-neutral-800 text-xs">
            <div className="flex items-center gap-1.5">
              <div className="flex text-amber-500">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-3.5 h-3.5 ${
                      i < Math.floor(product.rating)
                        ? 'fill-amber-400 text-amber-400'
                        : 'text-neutral-300 dark:text-neutral-600'
                    }`}
                  />
                ))}
              </div>
              <span className="font-bold text-neutral-900 dark:text-white tabular-nums">
                {product.rating.toFixed(1)}
              </span>
              <span className="text-neutral-400">({product.reviewCount} verified reviews)</span>
            </div>
            <div className="flex items-center gap-1 text-neutral-500">
              <Download className="w-3.5 h-3.5" />
              <span className="tabular-nums">{product.salesCount} sales</span>
            </div>
          </div>

          {/* License Selector Segmented Control */}
          <div>
            <div className="flex items-center justify-between text-xs mb-2">
              <label className="font-semibold text-neutral-800 dark:text-neutral-200">
                Choose Commercial License
              </label>
              <button
                onClick={() => navigate('legal')}
                className="text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 text-[11px] underline cursor-pointer"
              >
                License terms
              </button>
            </div>
            <div className="grid grid-cols-3 gap-1.5 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-xl text-xs">
              <button
                type="button"
                onClick={() => setSelectedLicense('personal')}
                className={`py-2 px-2 rounded-lg font-medium transition-all cursor-pointer ${
                  selectedLicense === 'personal'
                    ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-xs font-semibold'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
                }`}
              >
                <div>Personal</div>
                <div className="text-[10px] opacity-75 font-mono">1 Project</div>
              </button>
              <button
                type="button"
                onClick={() => setSelectedLicense('commercial')}
                className={`py-2 px-2 rounded-lg font-medium transition-all cursor-pointer ${
                  selectedLicense === 'commercial'
                    ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-xs font-semibold'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
                }`}
              >
                <div>Commercial</div>
                <div className="text-[10px] opacity-75 font-mono">Unlimited</div>
              </button>
              <button
                type="button"
                onClick={() => setSelectedLicense('extended')}
                className={`py-2 px-2 rounded-lg font-medium transition-all cursor-pointer ${
                  selectedLicense === 'extended'
                    ? 'bg-white dark:bg-neutral-900 text-neutral-900 dark:text-white shadow-xs font-semibold'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
                }`}
              >
                <div>Extended</div>
                <div className="text-[10px] opacity-75 font-mono">Resale / App</div>
              </button>
            </div>
          </div>

          {/* Pricing Row */}
          <div className="flex items-baseline justify-between pt-2">
            <div>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-extrabold text-neutral-950 dark:text-white tabular-nums tracking-tight">
                  ${currentPrice.toFixed(2)}
                </span>
                {product.originalPrice && (
                  <span className="text-sm text-neutral-400 line-through tabular-nums">
                    ${(product.originalPrice * licenseMultiplier).toFixed(2)}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1 mt-0.5">
                <ShieldCheck className="w-3.5 h-3.5" /> Instant verified download upon payment
              </p>
            </div>
          </div>

          {/* Primary Action Buttons */}
          <div className="space-y-2.5">
            <button
              onClick={handleBuyNow}
              className="w-full py-3 px-4 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 rounded-xl text-sm font-bold shadow-md transition-all hover:shadow-lg cursor-pointer flex items-center justify-center gap-2"
            >
              Buy Now <ArrowRight className="w-4 h-4" />
            </button>
            <div className="flex gap-2">
              <button
                onClick={() => addToCart(product, selectedLicense)}
                className="flex-1 py-2.5 px-4 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-900 dark:text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <ShoppingBag className="w-3.5 h-3.5" /> Add to Cart
              </button>
              <button
                onClick={() => toggleWishlist(product.id)}
                className="p-2.5 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-200 rounded-xl transition-colors cursor-pointer"
                aria-label="Save to wishlist"
              >
                <Heart className={`w-4 h-4 ${wishlisted ? 'fill-rose-500 text-rose-500' : ''}`} />
              </button>
            </div>
          </div>

          {/* Seller Snapshot Mini Card */}
          <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img
                src={seller.avatar}
                alt={seller.name}
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-full object-cover"
              />
              <div>
                <button
                  onClick={() => navigate('seller-storefront', { sellerId: seller.id })}
                  className="text-xs font-semibold text-neutral-900 dark:text-white hover:underline text-left block cursor-pointer"
                >
                  {seller.storeName}
                </button>
                <div className="text-[11px] text-neutral-500">
                  {seller.country} · {seller.salesCount} sales
                </div>
              </div>
            </div>
            <button
              onClick={() => navigate('seller-storefront', { sellerId: seller.id })}
              className="text-xs font-medium text-neutral-700 dark:text-neutral-300 hover:text-neutral-950 dark:hover:text-white underline cursor-pointer"
            >
              Visit Store
            </button>
          </div>
        </div>
      </div>

      {/* Customer Reviews Section */}
      <section className="mt-16 pt-12 border-t border-neutral-200 dark:border-neutral-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h2 className="text-xl font-bold font-display text-neutral-950 dark:text-white">
              Verified Customer Reviews
            </h2>
            <p className="text-xs text-neutral-500 mt-1">
              Real feedback from customers who purchased and downloaded this package.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold text-neutral-950 dark:text-white tabular-nums">
              {product.rating.toFixed(1)}
            </span>
            <div className="flex text-amber-500">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-4 h-4 ${
                    i < Math.floor(product.rating)
                      ? 'fill-amber-400 text-amber-400'
                      : 'text-neutral-300 dark:text-neutral-600'
                  }`}
                />
              ))}
            </div>
            <span className="text-xs text-neutral-400">({productReviews.length} reviews)</span>
          </div>
        </div>

        {/* Reviews List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {productReviews.map((rev) => (
            <div
              key={rev.id}
              className="p-4 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-full bg-neutral-200 dark:bg-neutral-700 flex items-center justify-center font-bold text-xs">
                    {rev.userName[0]}
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-neutral-900 dark:text-white flex items-center gap-1.5">
                      {rev.userName}
                      {rev.verifiedPurchase && (
                        <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-normal">
                          Verified Buyer
                        </span>
                      )}
                    </h4>
                    <span className="text-[10px] text-neutral-400">{rev.date}</span>
                  </div>
                </div>
                <div className="flex text-amber-400">
                  {[...Array(rev.rating)].map((_, i) => (
                    <Star key={i} className="w-3 h-3 fill-current" />
                  ))}
                </div>
              </div>
              <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                {rev.comment}
              </p>
            </div>
          ))}
        </div>

        {/* Leave a Review Form */}
        <div className="mt-8 p-6 bg-neutral-50 dark:bg-neutral-900/50 rounded-2xl border border-neutral-200 dark:border-neutral-800 max-w-xl">
          <h3 className="text-sm font-bold text-neutral-900 dark:text-white mb-2">
            Leave a Customer Review
          </h3>
          <p className="text-xs text-neutral-500 mb-4">
            Share your experience with this verified digital deliverable.
          </p>
          <form onSubmit={handleReviewSubmit} className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-xs text-neutral-600 dark:text-neutral-400">Your Rating:</span>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    type="button"
                    key={star}
                    onClick={() => setNewRating(star)}
                    className="p-0.5 text-amber-400 hover:scale-110 transition-transform cursor-pointer"
                  >
                    <Star
                      className={`w-4 h-4 ${
                        star <= newRating ? 'fill-amber-400' : 'text-neutral-300 dark:text-neutral-600'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>
            <textarea
              rows={3}
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="What did you think of the digital files, presentation, or utility?"
              className="w-full p-3 text-xs bg-white dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:ring-1 focus:ring-neutral-400"
              required
            />
            <button
              type="submit"
              disabled={isSubmittingReview || !newComment.trim()}
              className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 rounded-xl text-xs font-semibold transition-colors disabled:opacity-50 flex items-center gap-1.5 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" /> Submit Review
            </button>
          </form>
        </div>
      </section>

      {/* Related Products Section */}
      {relatedProducts.length > 0 && (
        <section className="mt-16 pt-12 border-t border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold font-display text-neutral-950 dark:text-white">
              Related Digital Products
            </h2>
            <button
              onClick={() => navigate('marketplace', { category: product.category })}
              className="text-xs font-medium text-neutral-600 dark:text-neutral-400 hover:text-neutral-950 dark:hover:text-white flex items-center gap-1 cursor-pointer"
            >
              View more {product.category} <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {relatedProducts.map((relProd) => (
              <ProductCard key={relProd.id} product={relProd} />
            ))}
          </div>
        </section>
      )}

      {/* Media Preview Modals */}
      {isAudioModalOpen && (
        <AudioPreviewModal product={product} onClose={() => setIsAudioModalOpen(false)} />
      )}
      {isEbookModalOpen && (
        <EbookPreviewModal product={product} onClose={() => setIsEbookModalOpen(false)} />
      )}
      {isImageModalOpen && (
        <ImagePreviewModal product={product} onClose={() => setIsImageModalOpen(false)} />
      )}
    </div>
  );
};
