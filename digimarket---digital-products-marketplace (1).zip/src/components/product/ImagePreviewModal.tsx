import React, { useState } from 'react';
import { Product } from '../../types';
import { useApp } from '../../context/AppContext';
import { X, ZoomIn, ZoomOut, ShoppingBag, ShieldCheck } from 'lucide-react';

interface ImagePreviewModalProps {
  product: Product;
  onClose: () => void;
}

export const ImagePreviewModal: React.FC<ImagePreviewModalProps> = ({ product, onClose }) => {
  const { addToCart } = useApp();
  const [isZoomed, setIsZoomed] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-neutral-900 text-white rounded-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-neutral-800 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-neutral-800">
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Watermarked Proof Preview · Master Resolution: {product.imageMeta?.dimensions || '8192 x 5464 px'} (16-bit)</span>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Image Preview Canvas with Watermark */}
        <div
          onClick={() => setIsZoomed((z) => !z)}
          className={`relative flex-1 overflow-auto p-4 flex items-center justify-center bg-black/60 cursor-${
            isZoomed ? 'zoom-out' : 'zoom-in'
          }`}
        >
          <div className={`relative transition-all duration-300 ${isZoomed ? 'scale-150' : 'max-h-[60vh]'}`}>
            <img
              src={product.thumbnail}
              alt={product.title}
              className="max-h-[60vh] max-w-full rounded-lg object-contain shadow-2xl select-none pointer-events-none"
            />
            {/* Subtle Diagonal Watermark Lines & Label */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
              <div className="text-white/20 text-4xl sm:text-6xl font-black uppercase rotate-[-25deg] tracking-widest text-center border-4 border-white/10 px-8 py-4 rounded-xl">
                DIGIMARKET PROOF
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-neutral-950 border-t border-neutral-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-xs text-neutral-400">
            <button
              onClick={() => setIsZoomed((z) => !z)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg transition-colors cursor-pointer"
            >
              {isZoomed ? <ZoomOut className="w-3.5 h-3.5" /> : <ZoomIn className="w-3.5 h-3.5" />}
              <span>{isZoomed ? 'Reset Zoom' : '100% Crop Zoom'}</span>
            </button>
            <span className="hidden sm:inline">Uncompressed TIFF & JPG included with verified purchase</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm font-bold text-white tabular-nums">${product.price.toFixed(2)}</span>
            <button
              onClick={() => {
                addToCart(product);
                onClose();
              }}
              className="flex items-center gap-2 px-4 py-2 bg-white hover:bg-neutral-100 text-neutral-950 rounded-xl text-xs font-semibold shadow transition-colors cursor-pointer"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              Download Master Files
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
