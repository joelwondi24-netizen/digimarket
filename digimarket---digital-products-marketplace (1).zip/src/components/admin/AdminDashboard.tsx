import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShieldCheck,
  DollarSign,
  Users,
  ShoppingBag,
  Download,
  Percent,
  CheckCircle,
  XCircle,
  Trash2,
  Tag,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Sliders,
  Upload,
  UserPlus,
  KeyRound,
  FileCheck,
  RefreshCw,
  Eye,
  BookOpen,
  Music,
  Video,
  Image,
  Layout,
  Palette,
  Check,
} from 'lucide-react';
import { Coupon, ProductCategory, LicenseType, AdminStaff } from '../../types';
import { AdminUploadProductModal } from './AdminUploadProductModal';
import { AdminRegisterStaffModal } from './AdminRegisterStaffModal';

type AdminTab =
  | 'overview'
  | 'upload-post'
  | 'admins'
  | 'products'
  | 'orders'
  | 'coupons'
  | 'reviews'
  | 'commission';

export const AdminDashboard: React.FC = () => {
  const {
    products,
    sellers,
    orders,
    downloadTokens,
    reviews,
    coupons,
    commissionRate,
    adminStaffList,
    currentAdminStaff,
    adminAuditLogs,
    switchAdminStaff,
    updateAdminStaffStatus,
    setCommissionRate,
    approveProduct,
    rejectProduct,
    deleteProduct,
    refundOrder,
    renewDownloadToken,
    moderateReview,
    addCoupon,
    toggleCouponStatus,
    setIsAdminUploadModalOpen,
    setIsAdminRegisterModalOpen,
    adminUploadProduct,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<AdminTab>('overview');

  // Inline Quick Post Form in Admin Upload Tab
  const [inlineCategory, setInlineCategory] = useState<ProductCategory>('eBooks');
  const [inlineTitle, setInlineTitle] = useState('');
  const [inlineTagline, setInlineTagline] = useState('');
  const [inlinePrice, setInlinePrice] = useState('24.99');
  const [inlineFormat, setInlineFormat] = useState('PDF + EPUB (Master Release)');
  const [inlineSize, setInlineSize] = useState('52 MB');
  const [inlineSellerId, setInlineSellerId] = useState(sellers[0]?.id || 'seller-1');

  // New coupon form state
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponDiscount, setNewCouponDiscount] = useState('15');
  const [newCouponDesc, setNewCouponDesc] = useState('');

  // Refund modal/prompt state
  const [refundOrderId, setRefundOrderId] = useState<string | null>(null);
  const [refundReason, setRefundReason] = useState('Customer request / duplicate order');

  // Analytics totals
  const grossSales = orders.reduce((sum, o) => sum + (o.paymentStatus === 'paid' ? o.total : 0), 0);
  const platformRevenue = grossSales * (commissionRate / 100);
  const verifiedTokensCount = downloadTokens.filter((t) => t.paymentVerificationStatus === 'verified' && !t.isRevoked).length;

  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode.trim()) return;
    const newC: Coupon = {
      code: newCouponCode.trim().toUpperCase(),
      discountPercent: parseInt(newCouponDiscount, 10) || 10,
      description: newCouponDesc.trim() || `${newCouponDiscount}% promotional discount`,
      expiresAt: '2026-12-31',
      isActive: true,
    };
    addCoupon(newC);
    setNewCouponCode('');
    setNewCouponDesc('');
  };

  const handleExecuteRefund = () => {
    if (!refundOrderId) return;
    refundOrder(refundOrderId, refundReason);
    setRefundOrderId(null);
  };

  const handleQuickInlinePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inlineTitle.trim()) return;

    adminUploadProduct({
      title: inlineTitle.trim(),
      tagline: inlineTagline.trim() || `Verified digital ${inlineCategory} package.`,
      category: inlineCategory,
      price: parseFloat(inlinePrice) || 19.99,
      fileFormat: inlineFormat,
      fileSize: inlineSize,
      sellerId: inlineSellerId,
      status: 'published',
      isFeatured: true,
    });

    setInlineTitle('');
    setInlineTagline('');
    showToast('success', 'Product Published!', `${inlineTitle} is now live in the marketplace catalog.`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-8 border-b border-neutral-200/80 dark:border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold font-display text-neutral-950 dark:text-white">
              Marketplace Administrator Operations
            </h1>
            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">
              Admin Mode (Level {currentAdminStaff?.securityLevel || 5})
            </span>
          </div>
          <p className="text-xs text-neutral-500 mt-1">
            Product uploads & posts, staff registration, verified payment token management & platform rules
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsAdminUploadModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-xl text-xs font-bold transition-all shadow cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5" /> Upload & Post Product
          </button>
          <button
            onClick={() => setIsAdminRegisterModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 rounded-xl text-xs font-bold transition-all shadow cursor-pointer"
          >
            <UserPlus className="w-3.5 h-3.5" /> Register Administrator
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto py-4 border-b border-neutral-200/80 dark:border-neutral-800 text-xs font-semibold">
        {[
          { id: 'overview', label: 'Platform KPIs' },
          { id: 'upload-post', label: 'Upload & Post Hub' },
          { id: 'admins', label: `Admin Registration & Staff (${adminStaffList.length})` },
          { id: 'products', label: `Catalog Moderation (${products.length})` },
          { id: 'orders', label: `Orders & Verified Tokens (${orders.length})` },
          { id: 'coupons', label: `Discounts & Coupons (${coupons.length})` },
          { id: 'reviews', label: `Review Moderation (${reviews.length})` },
          { id: 'commission', label: `Commission Rate (${commissionRate}%)` },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as AdminTab)}
            className={`px-3.5 py-2 rounded-xl transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow-xs'
                : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* TAB 1: OVERVIEW METRICS */}
      {activeTab === 'overview' && (
        <div className="pt-8 space-y-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-5 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
              <span className="text-xs text-neutral-500">Gross Processed Volume</span>
              <div className="text-2xl font-bold font-display text-neutral-900 dark:text-white mt-2 tabular-nums">
                ${grossSales.toFixed(2)}
              </div>
              <p className="text-[11px] text-neutral-400 mt-1">From verified orders</p>
            </div>
            <div className="p-5 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
              <span className="text-xs text-neutral-500">Marketplace Fee ({commissionRate}%)</span>
              <div className="text-2xl font-bold font-display text-emerald-600 dark:text-emerald-400 mt-2 tabular-nums">
                ${platformRevenue.toFixed(2)}
              </div>
              <p className="text-[11px] text-neutral-400 mt-1">Net platform cut</p>
            </div>
            <div className="p-5 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
              <span className="text-xs text-neutral-500">Registered Administrators</span>
              <div className="text-2xl font-bold font-display text-neutral-900 dark:text-white mt-2 tabular-nums">
                {adminStaffList.length}
              </div>
              <p className="text-[11px] text-neutral-400 mt-1">Active staff credentials</p>
            </div>
            <div className="p-5 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
              <span className="text-xs text-neutral-500">Verified Download Tokens</span>
              <div className="text-2xl font-bold font-display text-blue-600 dark:text-blue-400 mt-2 tabular-nums">
                {verifiedTokensCount}
              </div>
              <p className="text-[11px] text-neutral-400 mt-1">Active cryptographic deliverables</p>
            </div>
          </div>

          {/* Quick audit list */}
          <div className="p-6 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
            <h3 className="text-sm font-bold text-neutral-900 dark:text-white mb-3 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              Platform Integrity & Delivery Checklist
            </h3>
            <div className="space-y-2 text-xs text-neutral-600 dark:text-neutral-300">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>eBooks, Images, Music, Videos, Templates & Graphics upload handlers active in Admin</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Admin registration panel provisions role-based security clearances and credentials</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Cryptographic tokens issued only after verified payment clearance (Stripe / PayPal / Apple Pay)</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Revocation protocol immediately invalidates download tokens when orders are refunded</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: DEDICATED PRODUCTS UPLOAD & POST HUB */}
      {activeTab === 'upload-post' && (
        <div className="pt-8 space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 bg-gradient-to-r from-neutral-900 to-neutral-800 text-white rounded-3xl border border-neutral-800 shadow-md">
            <div>
              <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold mb-1">
                <Sparkles className="w-4 h-4" />
                <span>Admin Products Publishing Hub</span>
              </div>
              <h2 className="text-xl font-bold font-display text-white">
                Upload & Post Digital Deliverables
              </h2>
              <p className="text-xs text-neutral-300 mt-1 max-w-xl">
                Upload eBooks, high-resolution photography, uncompressed audio stems, 4K video sequences, UI templates, vector graphics, and other digital packages.
              </p>
            </div>
            <button
              onClick={() => setIsAdminUploadModalOpen(true)}
              className="px-5 py-3 bg-amber-400 hover:bg-amber-300 text-neutral-950 rounded-xl text-xs font-bold transition-all shadow flex items-center gap-2 cursor-pointer shrink-0"
            >
              <Upload className="w-4 h-4" /> Open Full Asset Uploader
            </button>
          </div>

          {/* Quick Upload Form Inside Admin Tab */}
          <div className="bg-white dark:bg-neutral-900 p-6 sm:p-8 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 shadow-sm space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <Upload className="w-4 h-4 text-amber-500" />
                Express Product Post Form
              </h3>
              <span className="text-xs text-neutral-400">Instantly publishes to live catalog</span>
            </div>

            <form onSubmit={handleQuickInlinePost} className="space-y-4 text-xs">
              {/* Category selector row */}
              <div>
                <label className="block font-medium mb-1.5 text-neutral-700 dark:text-neutral-300">
                  Select Product Category Format:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2">
                  {[
                    { name: 'eBooks', icon: BookOpen },
                    { name: 'Images', icon: Image },
                    { name: 'Music', icon: Music },
                    { name: 'Videos', icon: Video },
                    { name: 'Templates', icon: Layout },
                    { name: 'Graphics', icon: Palette },
                  ].map((cat) => {
                    const Icon = cat.icon;
                    const isSelected = inlineCategory === cat.name;
                    return (
                      <button
                        key={cat.name}
                        type="button"
                        onClick={() => {
                          setInlineCategory(cat.name as ProductCategory);
                          if (cat.name === 'eBooks') {
                            setInlineFormat('PDF + EPUB (Interactive Reader)');
                            setInlineSize('64 MB');
                          } else if (cat.name === 'Music') {
                            setInlineFormat('WAV (24-bit/96kHz) + MP3 (320kbps)');
                            setInlineSize('1.2 GB');
                          } else if (cat.name === 'Images') {
                            setInlineFormat('8K TIFF (16-bit uncompressed) + JPG');
                            setInlineSize('480 MB');
                          } else if (cat.name === 'Videos') {
                            setInlineFormat('MOGRT + DRP + 4K ProRes 422');
                            setInlineSize('2.8 GB');
                          } else {
                            setInlineFormat('FIG (Figma File) + JSON Tokens');
                            setInlineSize('95 MB');
                          }
                        }}
                        className={`p-2.5 rounded-xl border text-left flex items-center gap-2 transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 border-neutral-900 font-bold shadow-xs'
                            : 'bg-neutral-50 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700 hover:border-neutral-400'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">{cat.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-medium mb-1">Product Title</label>
                  <input
                    type="text"
                    required
                    value={inlineTitle}
                    onChange={(e) => setInlineTitle(e.target.value)}
                    placeholder="e.g. Zurich Brutalism: 8K Travertine Texture Pack"
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-medium mb-1">Tagline</label>
                  <input
                    type="text"
                    value={inlineTagline}
                    onChange={(e) => setInlineTagline(e.target.value)}
                    placeholder="e.g. 50 uncompressed medium format architectural stone captures."
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block font-medium mb-1">Price ($ USD)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={inlinePrice}
                    onChange={(e) => setInlinePrice(e.target.value)}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium mb-1">Format Specification</label>
                  <input
                    type="text"
                    value={inlineFormat}
                    onChange={(e) => setInlineFormat(e.target.value)}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700"
                  />
                </div>
                <div>
                  <label className="block font-medium mb-1">File Archive Size</label>
                  <input
                    type="text"
                    value={inlineSize}
                    onChange={(e) => setInlineSize(e.target.value)}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700"
                  />
                </div>
                <div>
                  <label className="block font-medium mb-1">Assign to Creator Store</label>
                  <select
                    value={inlineSellerId}
                    onChange={(e) => setInlineSellerId(e.target.value)}
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 cursor-pointer"
                  >
                    {sellers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.storeName} ({s.name})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  disabled={!inlineTitle.trim()}
                  className="px-6 py-3 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 rounded-xl font-bold transition-all shadow flex items-center gap-2 cursor-pointer disabled:opacity-40"
                >
                  <Upload className="w-3.5 h-3.5" /> Post {inlineCategory} Deliverable
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TAB 3: ADMIN REGISTRATION & STAFF MANAGEMENT PANEL */}
      {activeTab === 'admins' && (
        <div className="pt-8 space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-base font-bold text-neutral-900 dark:text-white">
                Administrative Staff Roster & Registration Panel ({adminStaffList.length})
              </h2>
              <p className="text-xs text-neutral-500 mt-0.5">
                Register new administrators, grant security levels, and manage role-based operational permissions.
              </p>
            </div>
            <button
              onClick={() => setIsAdminRegisterModalOpen(true)}
              className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 rounded-xl text-xs font-bold transition-all shadow flex items-center gap-1.5 cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5" /> Register New Administrator
            </button>
          </div>

          {/* Admin Staff Table */}
          <div className="bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-50 dark:bg-neutral-800/60 text-neutral-500 uppercase text-[10px] tracking-wider border-b border-neutral-200 dark:border-neutral-800">
                  <tr>
                    <th className="px-4 py-3">Administrator</th>
                    <th className="px-4 py-3">Function / Role</th>
                    <th className="px-4 py-3">Security Level</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Enrolled</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
                  {adminStaffList.map((admin) => {
                    const isCurrent = currentAdminStaff?.id === admin.id;
                    return (
                      <tr key={admin.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/40">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <img
                              src={admin.avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80'}
                              alt=""
                              referrerPolicy="no-referrer"
                              className="w-9 h-9 rounded-full object-cover border border-neutral-200 dark:border-neutral-700 shrink-0"
                            />
                            <div>
                              <div className="font-semibold text-neutral-900 dark:text-white flex items-center gap-1.5">
                                <span>{admin.name}</span>
                                {isCurrent && (
                                  <span className="px-1.5 py-0.2 rounded text-[10px] bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-bold">
                                    Current
                                  </span>
                                )}
                              </div>
                              <span className="text-[11px] text-neutral-400 font-mono">{admin.email}</span>
                            </div>
                          </div>
                        </td>

                        <td className="px-4 py-3">
                          <span className="capitalize font-medium text-neutral-800 dark:text-neutral-200">
                            {admin.role.replace('_', ' ')}
                          </span>
                        </td>

                        <td className="px-4 py-3">
                          <span className="font-mono text-xs font-semibold text-purple-600 dark:text-purple-400">
                            Level {admin.securityLevel}
                          </span>
                        </td>

                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                              admin.status === 'active'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : 'bg-neutral-200 text-neutral-700'
                            }`}
                          >
                            {admin.status}
                          </span>
                        </td>

                        <td className="px-4 py-3 text-neutral-400 font-mono text-[11px]">
                          {admin.joinedDate}
                        </td>

                        <td className="px-4 py-3 text-right">
                          <div className="flex items-center justify-end gap-2">
                            {!isCurrent && (
                              <button
                                onClick={() => switchAdminStaff(admin.id)}
                                className="px-2.5 py-1 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 rounded-lg text-[11px] font-medium transition-colors cursor-pointer"
                              >
                                Operate As
                              </button>
                            )}
                            <button
                              onClick={() =>
                                updateAdminStaffStatus(
                                  admin.id,
                                  admin.status === 'active' ? 'suspended' : 'active'
                                )
                              }
                              className="px-2 py-1 text-neutral-500 hover:text-neutral-900 dark:hover:text-white text-[11px] cursor-pointer"
                            >
                              {admin.status === 'active' ? 'Suspend' : 'Activate'}
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Security Audit Trail */}
          <div className="bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
              <h3 className="text-sm font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-purple-500" />
                Administrative Security Audit Trail ({adminAuditLogs.length} events)
              </h3>
              <span className="text-[11px] text-neutral-400 font-mono">Immutable Log Ledger</span>
            </div>

            <div className="divide-y divide-neutral-100 dark:divide-neutral-800 max-h-80 overflow-y-auto pr-1 text-xs">
              {adminAuditLogs.map((log) => (
                <div key={log.id} className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-neutral-900 dark:text-white">
                        {log.adminName}
                      </span>
                      <span className="text-neutral-400">·</span>
                      <span className="font-mono text-purple-600 dark:text-purple-400 font-medium">
                        [{log.action}]
                      </span>
                    </div>
                    <p className="text-neutral-600 dark:text-neutral-400">
                      {log.details}
                    </p>
                  </div>
                  <div className="text-left sm:text-right font-mono text-[11px] text-neutral-400 shrink-0">
                    <div>{log.timestamp}</div>
                    <div className="text-[10px] text-neutral-500">{log.ipAddress}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: PRODUCTS MODERATION */}
      {activeTab === 'products' && (
        <div className="pt-8 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-neutral-900 dark:text-white">
              Catalog Items ({products.length})
            </h2>
            <button
              onClick={() => setIsAdminUploadModalOpen(true)}
              className="text-xs font-semibold text-neutral-900 dark:text-white hover:underline cursor-pointer"
            >
              + Upload New Product
            </button>
          </div>

          <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-50 dark:bg-neutral-800/60 text-neutral-500 uppercase text-[10px] tracking-wider">
                  <tr>
                    <th className="px-4 py-3">Product</th>
                    <th className="px-4 py-3">Category</th>
                    <th className="px-4 py-3">Seller</th>
                    <th className="px-4 py-3">Price</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Moderation Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
                  {products.map((p) => (
                    <tr key={p.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/40">
                      <td className="px-4 py-3 font-semibold text-neutral-900 dark:text-white">
                        {p.title}
                      </td>
                      <td className="px-4 py-3 text-neutral-600 dark:text-neutral-400">{p.category}</td>
                      <td className="px-4 py-3 text-neutral-600 dark:text-neutral-400">{p.sellerName}</td>
                      <td className="px-4 py-3 font-mono font-bold tabular-nums">${p.price.toFixed(2)}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                            p.status === 'published'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {p.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {p.status !== 'published' && (
                            <button
                              onClick={() => approveProduct(p.id)}
                              className="px-2 py-1 bg-emerald-600 text-white rounded text-[11px] font-semibold cursor-pointer"
                            >
                              Approve
                            </button>
                          )}
                          {p.status === 'published' && (
                            <button
                              onClick={() => rejectProduct(p.id)}
                              className="px-2 py-1 bg-neutral-200 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 rounded text-[11px] cursor-pointer"
                            >
                              Reject
                            </button>
                          )}
                          <button
                            onClick={() => deleteProduct(p.id)}
                            className="p-1 text-neutral-400 hover:text-rose-500 cursor-pointer"
                            title="Remove"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: ORDERS & VERIFIED DOWNLOAD TOKENS */}
      {activeTab === 'orders' && (
        <div className="pt-8 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-neutral-900 dark:text-white">
                Orders & Cryptographic Deliverables ({orders.length})
              </h2>
              <p className="text-xs text-neutral-500">
                Payment verification ledger and active download token revocation
              </p>
            </div>
          </div>

          {orders.length === 0 ? (
            <div className="p-8 text-center bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 text-xs text-neutral-500">
              No orders placed yet in this session. Checkout in the store to generate verified tokens.
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((o) => (
                <div
                  key={o.id}
                  className="p-5 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 flex flex-col justify-between gap-4 text-xs"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-neutral-100 dark:border-neutral-800">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-neutral-900 dark:text-white text-sm">
                          {o.orderNumber}
                        </span>
                        <span className="text-neutral-400">{o.createdAt.split('T')[0]}</span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                            o.paymentStatus === 'paid'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {o.paymentStatus === 'paid' ? 'Payment Verified' : o.paymentStatus}
                        </span>
                      </div>
                      <p className="text-neutral-500 mt-1">
                        Buyer: {o.customerName} ({o.customerEmail}) · Method: {o.paymentMethod.toUpperCase()}
                      </p>
                    </div>

                    <div className="text-left sm:text-right">
                      <div className="font-bold text-neutral-900 dark:text-white tabular-nums text-sm">
                        ${o.total.toFixed(2)}
                      </div>
                      {o.paymentVerificationDetails && (
                        <span className="font-mono text-[10px] text-emerald-600 dark:text-emerald-400">
                          {o.paymentVerificationDetails.securityStandard}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Associated download tokens */}
                  <div className="space-y-2">
                    <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider block">
                      Cryptographic Download Tokens:
                    </span>
                    {o.downloadTokens.map((tok) => (
                      <div
                        key={tok.id}
                        className="p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800/40 border border-neutral-200/60 dark:border-neutral-700/60 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                      >
                        <div className="font-mono text-[11px]">
                          <span className="font-semibold text-neutral-800 dark:text-neutral-200">
                            {tok.productTitle}
                          </span>{' '}
                          · Attempts: <strong className="text-neutral-900 dark:text-white">{tok.downloadsRemaining} / {tok.maxDownloads}</strong>{' '}
                          · Status: {tok.isRevoked ? <span className="text-rose-600 font-bold">REVOKED</span> : <span className="text-emerald-600 font-bold">ACTIVE</span>}
                        </div>
                        {!tok.isRevoked && (
                          <button
                            onClick={() => renewDownloadToken(tok.id)}
                            className="px-2.5 py-1 bg-neutral-200 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200 rounded-lg text-[10px] font-semibold flex items-center gap-1 cursor-pointer self-start sm:self-auto"
                          >
                            <RefreshCw className="w-3 h-3" /> Re-issue Token
                          </button>
                        )}
                      </div>
                    ))}
                  </div>

                  {o.paymentStatus === 'paid' && (
                    <div className="pt-2 flex justify-end">
                      <button
                        onClick={() => setRefundOrderId(o.id)}
                        className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" /> Issue Refund & Revoke Access
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Refund Dialog Modal */}
          {refundOrderId && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
              <div className="bg-white dark:bg-neutral-900 p-6 rounded-2xl max-w-md w-full border border-neutral-200 dark:border-neutral-800 shadow-xl space-y-4 text-xs">
                <h3 className="text-base font-bold text-neutral-900 dark:text-white">
                  Confirm Refund & Access Revocation
                </h3>
                <p className="text-neutral-600 dark:text-neutral-400">
                  Refunding this order will immediately invalidate all associated digital download tokens in the cryptographic vault.
                </p>
                <div>
                  <label className="block font-medium mb-1">Reason for Refund</label>
                  <input
                    type="text"
                    value={refundReason}
                    onChange={(e) => setRefundReason(e.target.value)}
                    className="w-full p-2 bg-neutral-50 dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                  />
                </div>
                <div className="flex gap-2 pt-2">
                  <button
                    onClick={() => setRefundOrderId(null)}
                    className="flex-1 py-2 bg-neutral-100 dark:bg-neutral-800 rounded-lg font-semibold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleExecuteRefund}
                    className="flex-1 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold cursor-pointer"
                  >
                    Confirm Refund
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 6: COUPONS */}
      {activeTab === 'coupons' && (
        <div className="pt-8 space-y-6">
          <div className="p-6 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
            <h3 className="text-sm font-bold text-neutral-900 dark:text-white mb-3 flex items-center gap-2">
              <Tag className="w-4 h-4 text-amber-500" /> Create Promotional Coupon
            </h3>
            <form onSubmit={handleCreateCoupon} className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="block font-medium mb-1">Coupon Code</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. FLASH30"
                  value={newCouponCode}
                  onChange={(e) => setNewCouponCode(e.target.value.toUpperCase())}
                  className="w-full p-2 bg-neutral-50 dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700 font-mono uppercase"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">Discount %</label>
                <input
                  type="number"
                  min="5"
                  max="90"
                  required
                  value={newCouponDiscount}
                  onChange={(e) => setNewCouponDiscount(e.target.value)}
                  className="w-full p-2 bg-neutral-50 dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">Description</label>
                <input
                  type="text"
                  placeholder="e.g. Summer drop discount"
                  value={newCouponDesc}
                  onChange={(e) => setNewCouponDesc(e.target.value)}
                  className="w-full p-2 bg-neutral-50 dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                />
              </div>
              <div className="flex items-end">
                <button
                  type="submit"
                  className="w-full py-2 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 rounded-lg font-bold cursor-pointer"
                >
                  Create Code
                </button>
              </div>
            </form>
          </div>

          <div className="space-y-3">
            {coupons.map((c) => (
              <div
                key={c.code}
                className="p-4 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-neutral-900 dark:text-white text-sm">
                      {c.code}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        c.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-neutral-200 text-neutral-600'
                      }`}
                    >
                      {c.isActive ? 'Active' : 'Disabled'}
                    </span>
                  </div>
                  <p className="text-neutral-500 mt-0.5">{c.description}</p>
                </div>
                <button
                  onClick={() => toggleCouponStatus(c.code)}
                  className="px-3 py-1 bg-neutral-100 dark:bg-neutral-800 rounded-lg text-neutral-700 dark:text-neutral-300 hover:bg-neutral-200 cursor-pointer"
                >
                  {c.isActive ? 'Disable' : 'Enable'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 7: REVIEW MODERATION */}
      {activeTab === 'reviews' && (
        <div className="pt-8 space-y-3 text-xs">
          <h2 className="text-base font-bold text-neutral-900 dark:text-white mb-2">
            Submitted Product Reviews ({reviews.length})
          </h2>
          {reviews.map((rev) => (
            <div
              key={rev.id}
              className="p-4 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800 flex items-center justify-between"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-neutral-900 dark:text-white">{rev.userName}</span>
                  <span className="text-neutral-400">· {rev.rating} ★</span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] uppercase font-bold ${
                      rev.status === 'approved' ? 'text-emerald-600 bg-emerald-50' : 'text-rose-600 bg-rose-50'
                    }`}
                  >
                    {rev.status}
                  </span>
                </div>
                <p className="text-neutral-600 dark:text-neutral-300 mt-1">{rev.comment}</p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => moderateReview(rev.id, 'approved')}
                  className="px-2 py-1 bg-emerald-100 text-emerald-800 rounded text-[11px] font-semibold cursor-pointer"
                >
                  Approve
                </button>
                <button
                  onClick={() => moderateReview(rev.id, 'rejected')}
                  className="px-2 py-1 bg-rose-100 text-rose-800 rounded text-[11px] font-semibold cursor-pointer"
                >
                  Flag / Hide
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 8: COMMISSION CONFIGURATION */}
      {activeTab === 'commission' && (
        <div className="pt-8 max-w-lg space-y-6">
          <div className="p-6 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 space-y-4">
            <h3 className="text-base font-bold text-neutral-900 dark:text-white flex items-center gap-2">
              <Percent className="w-5 h-5 text-amber-500" /> Platform Commission Rule
            </h3>
            <p className="text-xs text-neutral-500 leading-relaxed">
              Adjust the marketplace take rate on verified digital product purchases. Creators receive{' '}
              <strong className="text-neutral-900 dark:text-white">{100 - commissionRate}%</strong> and the marketplace retains{' '}
              <strong className="text-neutral-900 dark:text-white">{commissionRate}%</strong>.
            </p>
            <div className="pt-2">
              <div className="flex justify-between text-xs font-semibold mb-2">
                <span>Platform Take Rate</span>
                <span className="font-mono text-base font-bold text-neutral-900 dark:text-white tabular-nums">
                  {commissionRate}%
                </span>
              </div>
              <input
                type="range"
                min="5"
                max="35"
                step="1"
                value={commissionRate}
                onChange={(e) => setCommissionRate(parseInt(e.target.value, 10))}
                className="w-full accent-neutral-900 dark:accent-white cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-neutral-400 mt-1">
                <span>5% (Low fee)</span>
                <span>20% (Standard default)</span>
                <span>35% (Enterprise tier)</span>
              </div>
            </div>
            <div className="p-3 bg-neutral-50 dark:bg-neutral-800 rounded-xl text-xs space-y-1">
              <div className="flex justify-between">
                <span>Example: $100.00 Digital Purchase</span>
              </div>
              <div className="flex justify-between text-neutral-500 text-[11px]">
                <span>Creator Net Pay</span>
                <span className="font-bold text-emerald-600">${(100 * (1 - commissionRate / 100)).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-neutral-500 text-[11px]">
                <span>Marketplace Platform Share</span>
                <span className="font-bold text-neutral-700 dark:text-neutral-300">
                  ${(100 * (commissionRate / 100)).toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Global Modals for Admin */}
      <AdminUploadProductModal />
      <AdminRegisterStaffModal />
    </div>
  );
};
