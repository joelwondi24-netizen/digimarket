import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Upload,
  BookOpen,
  Music,
  Video,
  Image,
  Layout,
  Palette,
  Sparkles,
  FileCheck,
  CheckCircle2,
  Eye,
  Sliders,
  Play,
  Volume2,
  Lock,
} from 'lucide-react';
import { ProductCategory, LicenseType, Product } from '../../types';
import { CATEGORIES_CONFIG } from '../../data/mockData';
import { previewSynth } from '../../utils/audioSynth';

export const AdminUploadProductModal: React.FC = () => {
  const {
    isAdminUploadModalOpen,
    setIsAdminUploadModalOpen,
    adminUploadProduct,
    sellers,
    showToast,
  } = useApp();

  const [category, setCategory] = useState<ProductCategory>('eBooks');
  const [selectedSellerId, setSelectedSellerId] = useState<string>(sellers[0]?.id || 'seller-1');

  // Core product details
  const [title, setTitle] = useState('');
  const [tagline, setTagline] = useState('');
  const [description, setDescription] = useState('');
  const [subcategory, setSubcategory] = useState('Business Strategy');
  const [price, setPrice] = useState('24.99');
  const [originalPrice, setOriginalPrice] = useState('39.99');
  const [fileFormat, setFileFormat] = useState('PDF + EPUB (Interactive)');
  const [fileSize, setFileSize] = useState('48.2 MB');
  const [license, setLicense] = useState<LicenseType>('commercial');
  const [features, setFeatures] = useState('Editorial typesetting, Vector architecture diagrams, Commercial rights license');
  const [whatsIncluded, setWhatsIncluded] = useState('High-Res PDF, ePub 3.0 file, Setup Guide, License certificate');
  const [systemRequirements, setSystemRequirements] = useState('Compatible with any modern reader or viewer.');
  const [status, setStatus] = useState<'published' | 'draft'>('published');
  const [isFeatured, setIsFeatured] = useState(true);

  // Category-specific states
  // 1. eBooks
  const [pageCount, setPageCount] = useState('180');
  const [isbn, setIsbn] = useState('978-1-84021-992-0');
  const [sampleChapterTitle, setSampleChapterTitle] = useState('Chapter 1: Foundational Architecture');
  const [sampleContent, setSampleContent] = useState('Every resilient digital system begins with strict domain boundaries and intentional clarity...');

  // 2. Images & Photography
  const [dimensions, setDimensions] = useState('8192 x 5464 px');
  const [megapixels, setMegapixels] = useState('45');
  const [colorSpace, setColorSpace] = useState('Adobe RGB (1998) / 16-bit TIFF');
  const [rawIncluded, setRawIncluded] = useState(true);

  // 3. Music & Audio
  const [trackDuration, setTrackDuration] = useState('04:12');
  const [bpm, setBpm] = useState('84');
  const [musicalKey, setMusicalKey] = useState('D Minor');
  const [sampleRate, setSampleRate] = useState('24-bit / 96kHz Lossless Broadcast WAV');
  const [stemsIncluded, setStemsIncluded] = useState(true);
  const [instrumentsUsed, setInstrumentsUsed] = useState('Moog Synth, Prophet-6, Eurorack Modular');

  // 4. Videos & Motion
  const [videoResolution, setVideoResolution] = useState('4K UHD (3840 x 2160)');
  const [frameRate, setFrameRate] = useState('24 fps');
  const [softwareCompatibility, setSoftwareCompatibility] = useState('Premiere Pro CC, DaVinci Resolve, Final Cut');
  const [codecs, setCodecs] = useState('Apple ProRes 422 / QuickTime Alpha');

  // 5. Templates & Graphics
  const [supportedSoftware, setSupportedSoftware] = useState('Figma, Sketch, Illustrator, Tailwind Tokens');
  const [layerCount, setLayerCount] = useState('350+ Auto-Layout Layers');

  // Upload simulation
  const [simulatedFile, setSimulatedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  if (!isAdminUploadModalOpen) return null;

  // Set smart defaults when category changes
  const handleCategoryChange = (cat: ProductCategory) => {
    setCategory(cat);
    if (cat === 'eBooks') {
      setFileFormat('PDF + EPUB (Interactive Reader)');
      setFileSize('64 MB');
      setSubcategory('Guides & Blueprints');
    } else if (cat === 'Music' || cat === 'Audio') {
      setFileFormat('WAV (24-bit/96kHz) + MP3 (320kbps)');
      setFileSize('1.2 GB');
      setSubcategory('Cinematic & Scores');
    } else if (cat === 'Images' || cat === 'Wallpapers') {
      setFileFormat('8K TIFF (16-bit uncompressed) + JPG');
      setFileSize('480 MB');
      setSubcategory('Editorial & Architecture');
    } else if (cat === 'Videos') {
      setFileFormat('MOGRT + DRP + 4K ProRes 422');
      setFileSize('2.8 GB');
      setSubcategory('Motion Graphics Templates');
    } else if (cat === 'Templates' || cat === 'Graphics') {
      setFileFormat('FIG (Figma File) + JSON Tokens');
      setFileSize('95 MB');
      setSubcategory('UI Kits & Systems');
    } else if (cat === '3D Assets') {
      setFileFormat('BLEND + FBX + OBJ + 8K PBR Textures');
      setFileSize('1.9 GB');
      setSubcategory('Procedural Shaders');
    } else {
      setFileFormat('ZIP Package (Source Assets)');
      setFileSize('120 MB');
      setSubcategory('Digital Resources');
    }
  };

  const handleFileDrop = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSimulatedFile(file);
      setFileSize(`${(file.size / (1024 * 1024)).toFixed(1)} MB`);
      const ext = file.name.split('.').pop()?.toUpperCase() || 'ZIP';
      setFileFormat(`${ext} Master Package`);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setIsUploading(true);
    setUploadProgress(20);

    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);

          adminUploadProduct({
            title: title.trim(),
            sellerId: selectedSellerId,
            tagline: tagline.trim() || `Curated master ${category} package with verified commercial rights.`,
            description: description.trim() || `Production-grade ${category} deliverable crafted for professional creators, businesses, and developers.`,
            category,
            subcategory,
            price: parseFloat(price) || 29.99,
            originalPrice: originalPrice ? parseFloat(originalPrice) : undefined,
            fileFormat,
            fileSize,
            license,
            status,
            isFeatured,
            features: features.split(',').map((f) => f.trim()),
            whatsIncluded: whatsIncluded.split(',').map((w) => w.trim()),
            systemRequirements,
            thumbnail:
              category === 'eBooks'
                ? '/src/assets/images/ebook_business_guide_1791198418260.jpg'
                : category === 'Music' || category === 'Audio'
                ? '/src/assets/images/music_audio_stems_1791198430026.jpg'
                : category === '3D Assets'
                ? '/src/assets/images/sculpture_3d_pack_1791198439460.jpg'
                : category === 'Videos'
                ? '/src/assets/images/video_motion_templates_1791198448503.jpg'
                : '/src/assets/images/hero_digital_assets_1791198407854.jpg',
            previewImages: [
              category === 'eBooks'
                ? '/src/assets/images/ebook_business_guide_1791198418260.jpg'
                : category === 'Music' || category === 'Audio'
                ? '/src/assets/images/music_audio_stems_1791198430026.jpg'
                : category === '3D Assets'
                ? '/src/assets/images/sculpture_3d_pack_1791198439460.jpg'
                : category === 'Videos'
                ? '/src/assets/images/video_motion_templates_1791198448503.jpg'
                : '/src/assets/images/hero_digital_assets_1791198407854.jpg',
            ],
            sampleContent: category === 'eBooks' ? sampleContent : undefined,
            ebookMeta:
              category === 'eBooks'
                ? {
                    pageCount: parseInt(pageCount, 10) || 200,
                    isbn,
                    sampleChapterTitle,
                    sampleChapterText: sampleContent,
                    readingFormat: fileFormat,
                  }
                : undefined,
            audioMeta:
              category === 'Music' || category === 'Audio'
                ? {
                    trackDuration,
                    bpm: parseInt(bpm, 10) || 84,
                    musicalKey,
                    sampleRate,
                    stemsIncluded,
                    instrumentsUsed: instrumentsUsed.split(',').map((i) => i.trim()),
                  }
                : undefined,
            videoMeta:
              category === 'Videos'
                ? {
                    resolution: videoResolution,
                    frameRate,
                    softwareCompatibility: softwareCompatibility.split(',').map((s) => s.trim()),
                    codecs,
                  }
                : undefined,
            imageMeta:
              category === 'Images' || category === 'Wallpapers'
                ? {
                    dimensions,
                    megapixels: parseInt(megapixels, 10) || 45,
                    colorSpace,
                    rawIncluded,
                  }
                : undefined,
            templateMeta:
              category === 'Templates' || category === 'Graphics'
                ? {
                    supportedSoftware: supportedSoftware.split(',').map((s) => s.trim()),
                    layerCount: parseInt(layerCount, 10) || 100,
                  }
                : undefined,
          });

          return 100;
        }
        return prev + 25;
      });
    }, 180);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
      <div className="bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 rounded-3xl max-w-4xl w-full max-h-[94vh] flex flex-col overflow-hidden border border-neutral-200 dark:border-neutral-800 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold font-display">
                Admin Digital Product Upload & Post Center
              </h2>
              <p className="text-xs text-neutral-400 mt-0.5">
                Post verified eBooks, images, music, videos, templates, graphics, and other assets to the marketplace
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsAdminUploadModalOpen(false)}
            className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Selector Tabs */}
        <div className="px-6 py-3 bg-neutral-50 dark:bg-neutral-800/60 border-b border-neutral-200 dark:border-neutral-800 overflow-x-auto flex items-center gap-2">
          {[
            { id: 'eBooks', label: 'eBooks & Guides', icon: BookOpen },
            { id: 'Images', label: 'Images & Photos', icon: Image },
            { id: 'Music', label: 'Music & Audio', icon: Music },
            { id: 'Videos', label: 'Videos & Motion', icon: Video },
            { id: 'Templates', label: 'Templates & UI', icon: Layout },
            { id: 'Graphics', label: 'Graphics & Vectors', icon: Palette },
            { id: '3D Assets', label: '3D Assets & Models', icon: Sparkles },
            { id: 'Presets', label: 'Presets & Other', icon: Sliders },
          ].map((catTab) => {
            const Icon = catTab.icon;
            const isSelected = category === catTab.id;
            return (
              <button
                key={catTab.id}
                type="button"
                onClick={() => handleCategoryChange(catTab.id as ProductCategory)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow-sm'
                    : 'bg-white dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-200 dark:hover:bg-neutral-700 border border-neutral-200 dark:border-neutral-700'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{catTab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          {/* Section 1: General Product Information */}
          <div className="space-y-4">
            <h3 className="font-bold text-neutral-900 dark:text-white uppercase tracking-wider text-[11px] pb-1 border-b border-neutral-100 dark:border-neutral-800">
              1. General Deliverable Details
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                  Assign to Creator / Studio Storefront
                </label>
                <select
                  value={selectedSellerId}
                  onChange={(e) => setSelectedSellerId(e.target.value)}
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl"
                >
                  {sellers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.storeName} ({s.name} - {s.country})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                  Subcategory
                </label>
                <input
                  type="text"
                  value={subcategory}
                  onChange={(e) => setSubcategory(e.target.value)}
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl"
                />
              </div>
            </div>

            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Product Title *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Cinematic Modular Audio Stems Vol. 2"
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-400 font-medium"
              />
            </div>

            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Short Subtitle / Tagline
              </label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                placeholder="e.g. 24 uncompressed 24-bit/96kHz analog synth cues and textures."
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-400"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                  Marketplace Price ($ USD) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl font-mono"
                />
              </div>
              <div>
                <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                  MSRP Original Price ($)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={originalPrice}
                  onChange={(e) => setOriginalPrice(e.target.value)}
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl font-mono"
                />
              </div>
              <div>
                <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                  Publishing Status
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl"
                >
                  <option value="published">Published (Live)</option>
                  <option value="draft">Draft (Review)</option>
                </select>
              </div>
              <div>
                <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                  Feature in Hero / Drops
                </label>
                <select
                  value={isFeatured ? 'true' : 'false'}
                  onChange={(e) => setIsFeatured(e.target.value === 'true')}
                  className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl"
                >
                  <option value="true">Yes (Featured Badge)</option>
                  <option value="false">Standard Catalog</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Detailed Product Description
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Exhaustive specifications, workflow benefits, and included components..."
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none"
              />
            </div>
          </div>

          {/* Section 2: Category-Specific Tailored Fields */}
          <div className="space-y-4 pt-2">
            <h3 className="font-bold text-neutral-900 dark:text-white uppercase tracking-wider text-[11px] pb-1 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
              <span>2. Specific {category} Deliverable Metadata</span>
              <span className="text-amber-500 font-normal">Category Specialized Config</span>
            </h3>

            {/* eBooks Specialization */}
            {category === 'eBooks' && (
              <div className="space-y-3 p-4 bg-neutral-50 dark:bg-neutral-800/40 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-medium mb-1">Total Page Count</label>
                    <input
                      type="number"
                      value={pageCount}
                      onChange={(e) => setPageCount(e.target.value)}
                      placeholder="e.g. 240"
                      className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">Digital ISBN / Catalog Identifier</label>
                    <input
                      type="text"
                      value={isbn}
                      onChange={(e) => setIsbn(e.target.value)}
                      placeholder="e.g. 978-1-954829-01-2"
                      className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700 font-mono"
                    />
                  </div>
                </div>
                <div>
                  <label className="block font-medium mb-1">Sample Chapter Title (Reader Preview)</label>
                  <input
                    type="text"
                    value={sampleChapterTitle}
                    onChange={(e) => setSampleChapterTitle(e.target.value)}
                    placeholder="Chapter 1: The Foundational Invariants"
                    className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                  />
                </div>
                <div>
                  <label className="block font-medium mb-1">Sample Excerpt Reading Preview (Watermarked in Modal)</label>
                  <textarea
                    rows={3}
                    value={sampleContent}
                    onChange={(e) => setSampleContent(e.target.value)}
                    placeholder="Paste excerpt text that potential buyers can browse in the reading modal..."
                    className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700 font-serif"
                  />
                </div>
              </div>
            )}

            {/* Images Specialization */}
            {(category === 'Images' || category === 'Wallpapers') && (
              <div className="space-y-3 p-4 bg-neutral-50 dark:bg-neutral-800/40 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-medium mb-1">Dimensions (Pixels)</label>
                    <input
                      type="text"
                      value={dimensions}
                      onChange={(e) => setDimensions(e.target.value)}
                      placeholder="e.g. 8192 x 5464 px"
                      className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">Effective Megapixels</label>
                    <input
                      type="number"
                      value={megapixels}
                      onChange={(e) => setMegapixels(e.target.value)}
                      placeholder="e.g. 45"
                      className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">Color Profile / Bit Depth</label>
                    <input
                      type="text"
                      value={colorSpace}
                      onChange={(e) => setColorSpace(e.target.value)}
                      placeholder="e.g. Adobe RGB 1998 (16-bit)"
                      className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                    />
                  </div>
                </div>
                <label className="flex items-center gap-2 cursor-pointer pt-1">
                  <input
                    type="checkbox"
                    checked={rawIncluded}
                    onChange={(e) => setRawIncluded(e.target.checked)}
                    className="accent-neutral-900"
                  />
                  <span>Include uncompressed RAW / DNG source negatives in deliverable package</span>
                </label>
              </div>
            )}

            {/* Music & Audio Specialization */}
            {(category === 'Music' || category === 'Audio') && (
              <div className="space-y-3 p-4 bg-neutral-50 dark:bg-neutral-800/40 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block font-medium mb-1">Track Duration</label>
                    <input
                      type="text"
                      value={trackDuration}
                      onChange={(e) => setTrackDuration(e.target.value)}
                      placeholder="e.g. 03:45"
                      className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">BPM (Beats/Min)</label>
                    <input
                      type="number"
                      value={bpm}
                      onChange={(e) => setBpm(e.target.value)}
                      placeholder="e.g. 84"
                      className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">Musical Key</label>
                    <input
                      type="text"
                      value={musicalKey}
                      onChange={(e) => setMusicalKey(e.target.value)}
                      placeholder="e.g. D Minor / F Maj"
                      className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">Master Audio Spec</label>
                    <input
                      type="text"
                      value={sampleRate}
                      onChange={(e) => setSampleRate(e.target.value)}
                      placeholder="24-bit / 96kHz Lossless"
                      className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-medium mb-1">Instruments & Synthesizers Used</label>
                  <input
                    type="text"
                    value={instrumentsUsed}
                    onChange={(e) => setInstrumentsUsed(e.target.value)}
                    placeholder="e.g. Moog Grandmother, Sequential Prophet-6, Eurorack Stems"
                    className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                  />
                </div>

                {/* Synth audio test trigger */}
                <div className="flex items-center justify-between pt-1">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={stemsIncluded}
                      onChange={(e) => setStemsIncluded(e.target.checked)}
                      className="accent-neutral-900"
                    />
                    <span>Include isolated bass, melodic, and foley stems in archive</span>
                  </label>

                  <button
                    type="button"
                    onClick={() => {
                      previewSynth.play();
                      showToast('info', 'Synth Audio Playing', 'Testing 30s WebAudio synthesizers loop.');
                    }}
                    className="px-3 py-1 bg-amber-400 hover:bg-amber-300 text-neutral-950 rounded-lg font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5" /> Test Audio Synth
                  </button>
                </div>
              </div>
            )}

            {/* Videos Specialization */}
            {category === 'Videos' && (
              <div className="space-y-3 p-4 bg-neutral-50 dark:bg-neutral-800/40 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-medium mb-1">Video Resolution</label>
                    <input
                      type="text"
                      value={videoResolution}
                      onChange={(e) => setVideoResolution(e.target.value)}
                      placeholder="4K UHD (3840 x 2160)"
                      className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">Frame Rate</label>
                    <input
                      type="text"
                      value={frameRate}
                      onChange={(e) => setFrameRate(e.target.value)}
                      placeholder="23.976 fps & 24.0 fps"
                      className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                    />
                  </div>
                </div>
                <div>
                  <label className="block font-medium mb-1">Supported Editing Suites</label>
                  <input
                    type="text"
                    value={softwareCompatibility}
                    onChange={(e) => setSoftwareCompatibility(e.target.value)}
                    placeholder="Adobe Premiere Pro, DaVinci Resolve, Final Cut Pro"
                    className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                  />
                </div>
                <div>
                  <label className="block font-medium mb-1">Master Codecs / Alpha Overlays</label>
                  <input
                    type="text"
                    value={codecs}
                    onChange={(e) => setCodecs(e.target.value)}
                    placeholder="Apple ProRes 422 QuickTime with Alpha"
                    className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                  />
                </div>
              </div>
            )}

            {/* Templates, Graphics, 3D Assets Specialization */}
            {(category === 'Templates' || category === 'Graphics' || category === '3D Assets' || category === 'Software') && (
              <div className="space-y-3 p-4 bg-neutral-50 dark:bg-neutral-800/40 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-medium mb-1">Supported Systems & Software</label>
                    <input
                      type="text"
                      value={supportedSoftware}
                      onChange={(e) => setSupportedSoftware(e.target.value)}
                      placeholder="Figma 5.0, Blender 4.2, Notion, Tailwind CSS"
                      className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                    />
                  </div>
                  <div>
                    <label className="block font-medium mb-1">Layer / Component Complexity</label>
                    <input
                      type="text"
                      value={layerCount}
                      onChange={(e) => setLayerCount(e.target.value)}
                      placeholder="500+ Components / 40 Screens"
                      className="w-full p-2 bg-white dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Section 3: File Vault Attachment Simulator */}
          <div className="space-y-3 pt-2">
            <h3 className="font-bold text-neutral-900 dark:text-white uppercase tracking-wider text-[11px] pb-1 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
              <span>3. Cryptographic Asset Deliverable Storage</span>
              <span className="text-emerald-500 font-normal">Encrypted Vault Bucket</span>
            </h3>

            <div className="border-2 border-dashed border-neutral-300 dark:border-neutral-700 rounded-2xl p-6 text-center hover:border-neutral-500 transition-colors">
              <input
                type="file"
                id="admin-digital-file-input"
                onChange={handleFileDrop}
                className="hidden"
              />
              <label
                htmlFor="admin-digital-file-input"
                className="cursor-pointer flex flex-col items-center justify-center"
              >
                {simulatedFile ? (
                  <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-medium">
                    <FileCheck className="w-6 h-6" />
                    <span>{simulatedFile.name} ({(simulatedFile.size / (1024 * 1024)).toFixed(2)} MB)</span>
                  </div>
                ) : (
                  <>
                    <Upload className="w-8 h-8 text-neutral-400 mb-2" />
                    <p className="font-semibold text-neutral-900 dark:text-white">
                      Click to attach master file archive or drag & drop files
                    </p>
                    <p className="text-[11px] text-neutral-500 mt-1">
                      ZIP, WAV, TAR.GZ, PDF, BLEND up to 10GB · SHA-256 Checksum calculated automatically
                    </p>
                  </>
                )}
              </label>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-medium mb-1">Format Specification Label</label>
                <input
                  type="text"
                  value={fileFormat}
                  onChange={(e) => setFileFormat(e.target.value)}
                  className="w-full p-2 bg-neutral-50 dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                />
              </div>
              <div>
                <label className="block font-medium mb-1">Archive Size</label>
                <input
                  type="text"
                  value={fileSize}
                  onChange={(e) => setFileSize(e.target.value)}
                  className="w-full p-2 bg-neutral-50 dark:bg-neutral-800 rounded-lg border border-neutral-200 dark:border-neutral-700"
                />
              </div>
            </div>
          </div>

          {/* Upload progress */}
          {isUploading && (
            <div className="pt-2">
              <div className="flex justify-between text-[11px] text-neutral-500 mb-1">
                <span>Encrypting and publishing product to DigiMarket catalog...</span>
                <span>{uploadProgress}%</span>
              </div>
              <div className="w-full bg-neutral-100 dark:bg-neutral-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-500 h-full transition-all duration-200"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Action Footer */}
          <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between gap-3">
            <div className="text-[11px] text-neutral-400">
              Published directly under Admin Authority with instant token delivery.
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setIsAdminUploadModalOpen(false)}
                className="px-4 py-2.5 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-300 rounded-xl font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isUploading || !title.trim()}
                className="px-6 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 rounded-xl font-bold transition-all disabled:opacity-50 cursor-pointer shadow-md"
              >
                {isUploading ? 'Publishing...' : 'Upload & Post Product'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
