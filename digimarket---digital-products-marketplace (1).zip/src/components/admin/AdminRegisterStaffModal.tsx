import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, UserPlus, Shield, KeyRound, Check, AlertCircle } from 'lucide-react';
import { AdminPermissions, AdminStaff } from '../../types';

export const AdminRegisterStaffModal: React.FC = () => {
  const {
    isAdminRegisterModalOpen,
    setIsAdminRegisterModalOpen,
    registerAdminStaff,
    showToast,
  } = useApp();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<AdminStaff['role']>('product_manager');
  const [securityLevel, setSecurityLevel] = useState<AdminStaff['securityLevel']>(4);
  const [passphrase, setPassphrase] = useState('');
  const [passphraseHint, setPassphraseHint] = useState('');

  // Permissions state
  const [permissions, setPermissions] = useState<AdminPermissions>({
    canUploadProducts: true,
    canApproveProducts: true,
    canIssueRefundsAndRevokeTokens: false,
    canManageCommission: false,
    canRegisterAdmins: false,
    canViewSecurityAuditLogs: true,
  });

  if (!isAdminRegisterModalOpen) return null;

  // Preset permissions according to role
  const handleRoleChange = (newRole: AdminStaff['role']) => {
    setRole(newRole);
    if (newRole === 'super_admin') {
      setSecurityLevel(5);
      setPermissions({
        canUploadProducts: true,
        canApproveProducts: true,
        canIssueRefundsAndRevokeTokens: true,
        canManageCommission: true,
        canRegisterAdmins: true,
        canViewSecurityAuditLogs: true,
      });
    } else if (newRole === 'product_manager') {
      setSecurityLevel(4);
      setPermissions({
        canUploadProducts: true,
        canApproveProducts: true,
        canIssueRefundsAndRevokeTokens: false,
        canManageCommission: false,
        canRegisterAdmins: false,
        canViewSecurityAuditLogs: true,
      });
    } else if (newRole === 'financial_officer') {
      setSecurityLevel(4);
      setPermissions({
        canUploadProducts: false,
        canApproveProducts: false,
        canIssueRefundsAndRevokeTokens: true,
        canManageCommission: true,
        canRegisterAdmins: false,
        canViewSecurityAuditLogs: true,
      });
    } else if (newRole === 'moderator') {
      setSecurityLevel(3);
      setPermissions({
        canUploadProducts: false,
        canApproveProducts: true,
        canIssueRefundsAndRevokeTokens: false,
        canManageCommission: false,
        canRegisterAdmins: false,
        canViewSecurityAuditLogs: false,
      });
    } else {
      setSecurityLevel(2);
      setPermissions({
        canUploadProducts: true,
        canApproveProducts: false,
        canIssueRefundsAndRevokeTokens: false,
        canManageCommission: false,
        canRegisterAdmins: false,
        canViewSecurityAuditLogs: false,
      });
    }
  };

  const handleTogglePermission = (key: keyof AdminPermissions) => {
    setPermissions((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;

    registerAdminStaff({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      role,
      securityLevel,
      status: 'active',
      permissions,
      securityPassphraseHint: passphraseHint.trim() || `Key Digest #${Math.floor(1000 + Math.random() * 9000)}`,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 rounded-3xl max-w-xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-neutral-200 dark:border-neutral-800 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold font-display">
                Register New Administrator
              </h2>
              <p className="text-xs text-neutral-400 mt-0.5">
                Grant role-based credentials and operational permissions
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsAdminRegisterModalOpen(false)}
            className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Full Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Katherine Shaw"
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-400"
              />
            </div>
            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Staff Email Address *
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. katherine@digimarket.io"
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-400"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Administrative Function / Role
              </label>
              <select
                value={role}
                onChange={(e) => handleRoleChange(e.target.value as AdminStaff['role'])}
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl cursor-pointer"
              >
                <option value="super_admin">Super Administrator (Full Root)</option>
                <option value="product_manager">Catalog & Product Moderator</option>
                <option value="financial_officer">Financial & Payout Officer</option>
                <option value="moderator">Customer Dispute Specialist</option>
                <option value="content_editor">Content & Publication Editor</option>
              </select>
            </div>
            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Security Clearance Level
              </label>
              <select
                value={securityLevel}
                onChange={(e) => setSecurityLevel(parseInt(e.target.value, 10) as AdminStaff['securityLevel'])}
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl cursor-pointer"
              >
                <option value="5">Level 5 (Super Root Key)</option>
                <option value="4">Level 4 (Executive Operations)</option>
                <option value="3">Level 3 (Content Management)</option>
                <option value="2">Level 2 (Editorial Review)</option>
                <option value="1">Level 1 (Auditor / Read Only)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
              Hardware Key or Passphrase Hint
            </label>
            <input
              type="text"
              value={passphraseHint}
              onChange={(e) => setPassphraseHint(e.target.value)}
              placeholder="e.g. YubiKey #04 / Auth App Slot 12"
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none"
            />
          </div>

          {/* Granular Permissions Matrix */}
          <div className="pt-2">
            <h4 className="font-bold text-neutral-900 dark:text-white uppercase tracking-wider text-[11px] mb-2">
              Granular Operational Permissions
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-neutral-50 dark:bg-neutral-800/40 p-4 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={permissions.canUploadProducts}
                  onChange={() => handleTogglePermission('canUploadProducts')}
                  className="accent-neutral-900"
                />
                <span>Upload & Post Digital Deliverables</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={permissions.canApproveProducts}
                  onChange={() => handleTogglePermission('canApproveProducts')}
                  className="accent-neutral-900"
                />
                <span>Approve / Reject Creator Submissions</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={permissions.canIssueRefundsAndRevokeTokens}
                  onChange={() => handleTogglePermission('canIssueRefundsAndRevokeTokens')}
                  className="accent-neutral-900"
                />
                <span>Execute Refunds & Revoke Tokens</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={permissions.canManageCommission}
                  onChange={() => handleTogglePermission('canManageCommission')}
                  className="accent-neutral-900"
                />
                <span>Modify Platform Commission Rate</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={permissions.canRegisterAdmins}
                  onChange={() => handleTogglePermission('canRegisterAdmins')}
                  className="accent-neutral-900"
                />
                <span>Register Additional Admin Staff</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={permissions.canViewSecurityAuditLogs}
                  onChange={() => handleTogglePermission('canViewSecurityAuditLogs')}
                  className="accent-neutral-900"
                />
                <span>Access Security Audit Trail</span>
              </label>
            </div>
          </div>

          <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-xl border border-blue-200 dark:border-blue-900/50 flex items-start gap-2.5 text-[11px] text-blue-800 dark:text-blue-300">
            <KeyRound className="w-4 h-4 shrink-0 mt-0.5 text-blue-500" />
            <span>
              All administrative actions performed by this administrator will be logged in the immutable Security Audit Trail with IP and timestamp verification.
            </span>
          </div>

          {/* Action buttons */}
          <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 flex gap-3">
            <button
              type="button"
              onClick={() => setIsAdminRegisterModalOpen(false)}
              className="flex-1 py-2.5 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 rounded-xl font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!name.trim() || !email.trim()}
              className="flex-1 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 rounded-xl font-bold transition-all disabled:opacity-50 cursor-pointer shadow-md"
            >
              Provision Administrator
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
