import React, { useState } from 'react';
import { ChevronDown, ChevronUp, HelpCircle, ShieldCheck } from 'lucide-react';

export const FaqPage: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'How does payment verification and secure digital download work?',
      a: 'When you purchase any product on DigiMarket, our backend immediately runs a 3D-Secure clearance check through our PCI-DSS Level 1 gateway. Once verified, a unique cryptographic download token with SHA-256 verification hash is generated. You can download your source files instantly on the order confirmation screen, via the email receipt dispatched to you, in your Customer Account under "My Downloads", or by entering your order reference in the "Verify & Download" tool.',
    },
    {
      q: 'Where can I find and re-download my purchased products?',
      a: 'All purchased files remain permanently accessible in your Customer Dashboard under "My Downloads". Each token allows up to 5 initial high-speed download attempts, with access keys renewable through our automated system should you switch workstations.',
    },
    {
      q: 'Can I download purchased products again if my computer crashes?',
      a: 'Yes. Simply sign into your DigiMarket account, head to the "My Downloads" section, and click "Download Files Now" next to your purchased asset to retrieve the package.',
    },
    {
      q: 'What file formats are supported on DigiMarket?',
      a: 'DigiMarket supports all standard creative formats including lossless 24-bit/96kHz audio (WAV, FLAC, MP3), high-resolution imagery (TIFF, RAW, PNG, JPG), 3D scenes (BLEND, FBX, OBJ), video templates (MOGRT, DRP, ProRes 422), documents & publications (PDF, EPUB, DOCX), design kits (FIG, PSD, AI), and master ZIP bundles.',
    },
    {
      q: 'How do administrator uploads and posts work?',
      a: 'Authorized administrators can upload and post deliverables directly through the Admin Operations Hub. The uploader features customized sections tailored for eBooks (page count, ISBN, sample excerpts), music (BPM, key, stems, live synth preview), videos (resolution, frame rate, NLE compatibility), and design templates, publishing them directly or on behalf of creator storefronts.',
    },
    {
      q: 'How does admin registration and permissions management work?',
      a: 'Super Administrators can register new admin staff directly from the Admin Registration Panel. Each staff member is assigned a specific functional role (Super Admin, Product Manager, Financial Officer, Dispute Specialist, Content Editor) with granular operational permissions and hardware passphrase keys.',
    },
    {
      q: 'What is your refund policy for digital products?',
      a: 'Due to the instant delivery of digital deliverables and irrevocable licensing keys, refunds are evaluated on a case-by-case basis within 14 days of purchase. If a file is genuinely defective or significantly misrepresents its published specifications, our administrative operations team will verify the issue, execute a full refund, and immediately revoke the associated download token.',
    },
    {
      q: 'How do creator and seller payouts work?',
      a: 'Sellers receive 80% of net transaction revenue. DigiMarket processes payouts via Stripe Connect direct deposit, PayPal, or international wire transfer. Payout requests can be dispatched at any time once pending verified earnings exceed $50.',
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
      <div className="text-center mb-12">
        <span className="text-xs font-semibold uppercase tracking-wider text-amber-600 dark:text-amber-400">
          Knowledge Base & Help
        </span>
        <h1 className="text-3xl font-bold font-display text-neutral-950 dark:text-white mt-1">
          Frequently Asked Questions
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 mt-2 max-w-lg mx-auto">
          Everything you need to know about purchasing, payment verification, instant file delivery, commercial licensing, and creator sales.
        </p>
      </div>

      <div className="space-y-3">
        {faqs.map((faq, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div
              key={idx}
              className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 overflow-hidden transition-all shadow-xs"
            >
              <button
                onClick={() => setOpenIndex(isOpen ? null : idx)}
                className="w-full p-5 text-left flex items-center justify-between gap-4 font-bold text-xs sm:text-sm text-neutral-900 dark:text-white hover:text-amber-600 dark:hover:text-amber-400 transition-colors cursor-pointer"
              >
                <span className="flex items-center gap-2.5">
                  <HelpCircle className="w-4 h-4 text-amber-500 shrink-0" />
                  {faq.q}
                </span>
                {isOpen ? (
                  <ChevronUp className="w-4 h-4 text-neutral-400 shrink-0" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-neutral-400 shrink-0" />
                )}
              </button>

              {isOpen && (
                <div className="px-5 pb-5 pt-1 text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed border-t border-neutral-100 dark:border-neutral-800/60">
                  {faq.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
