import React, { useState } from 'react';
import { Shield, FileText, AlertTriangle, Scale, CheckCircle2, KeyRound } from 'lucide-react';
import { useApp } from '../../context/AppContext';

type LegalSection = 'terms' | 'privacy' | 'refund' | 'dmca' | 'seller-agreement';

export const LegalPage: React.FC = () => {
  const [activeSection, setActiveSection] = useState<LegalSection>('terms');
  const { showToast } = useApp();

  // DMCA report state
  const [infringingUrl, setInfringingUrl] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [statement, setStatement] = useState('');
  const [isDMCASent, setIsDMCASent] = useState(false);

  const handleDMCASubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!infringingUrl.trim() || !ownerName.trim()) return;
    setIsDMCASent(true);
    showToast('success', 'DMCA Notice Lodged', 'Takedown inquiry logged for administrative review.');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
      <div className="mb-10">
        <span className="text-xs font-semibold uppercase tracking-wider text-amber-600 dark:text-amber-400">
          Trust, Safety & Governance
        </span>
        <h1 className="text-3xl font-bold font-display text-neutral-950 dark:text-white mt-1">
          Marketplace Legal & Policy Center
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 mt-1">
          Review our binding licensing policies, DMCA copyright takedown mechanisms, and seller warranties.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        {/* Navigation Tabs (3 cols) */}
        <div className="md:col-span-3 space-y-1 text-xs">
          {[
            { id: 'terms', label: 'Terms of Service', icon: FileText },
            { id: 'privacy', label: 'Privacy Policy', icon: Shield },
            { id: 'refund', label: 'Digital Refund & Revocation', icon: Scale },
            { id: 'dmca', label: 'DMCA & Copyright Takedown', icon: AlertTriangle },
            { id: 'seller-agreement', label: 'Seller Agreement (80/20)', icon: FileText },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSection(tab.id as LegalSection)}
                className={`w-full flex items-center gap-2 px-3.5 py-2.5 rounded-xl font-semibold transition-colors cursor-pointer text-left ${
                  activeSection === tab.id
                    ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content Box (9 cols) */}
        <div className="md:col-span-9 bg-white dark:bg-neutral-900 p-6 sm:p-10 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 text-neutral-700 dark:text-neutral-300 text-xs sm:text-sm leading-relaxed space-y-6">
          {activeSection === 'terms' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold text-neutral-950 dark:text-white">
                1. DigiMarket Platform Terms of Service
              </h2>
              <p>
                Welcome to DigiMarket. By accessing our website, purchasing digital goods, or registering as a merchant creator, you agree to be bound by these Terms of Service.
              </p>
              <h3 className="text-sm font-bold text-neutral-900 dark:text-white pt-2">
                Digital Delivery & License Grant
              </h3>
              <p>
                All items hosted on DigiMarket are delivered electronically via encrypted token URLs once payment is verified. Upon completed clearance, DigiMarket grants the purchaser a perpetual, worldwide, non-exclusive license to use the acquired files in accordance with the chosen license tier (Personal, Commercial, or Extended).
              </p>
              <p>
                Purchasers may not resell, sub-license, redistribute, or publish the source files as standalone stock items on any secondary exchange.
              </p>
            </div>
          )}

          {activeSection === 'privacy' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold text-neutral-950 dark:text-white">
                2. Privacy & Data Protection Policy
              </h2>
              <p>
                DigiMarket is built on strict data minimization principles. We do not store raw credit card numbers on our servers; all payment transactions are tokenized through accredited PCI-DSS compliant providers (Stripe and PayPal).
              </p>
              <p>
                Customer emails are utilized strictly for order confirmation, payment clearance verification, secure digital deliverable fulfillment, and optional creator drop dispatches. We do not sell user data to advertising brokers.
              </p>
            </div>
          )}

          {activeSection === 'refund' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold text-neutral-950 dark:text-white">
                3. Digital Product Refund & Token Revocation Policy
              </h2>
              <p>
                Due to the immediate access granted to downloadable source codes, uncompressed audio stems, and vector publications, digital sales are typically non-refundable once downloaded.
              </p>
              <p>
                However, if an asset is technically corrupted, missing advertised components, or materially incompatible with published specifications, customers may request a refund within 14 days of purchase.
              </p>
              <p className="font-semibold text-rose-600 dark:text-rose-400">
                Notice: When an administrative refund is executed, all download tokens and commercial licenses associated with the order are immediately revoked in our database and access keys are invalidated.
              </p>
            </div>
          )}

          {activeSection === 'dmca' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-lg font-bold text-neutral-950 dark:text-white">
                  4. DMCA & Copyright Complaint Workflow
                </h2>
                <p className="mt-2">
                  DigiMarket strictly respects intellectual property rights. If you believe your copyrighted sound recording, artwork, typeface, or publication has been uploaded without authorization, submit this takedown notice.
                </p>
              </div>

              {isDMCASent ? (
                <div className="p-5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl flex items-center gap-3 text-emerald-800 dark:text-emerald-300">
                  <CheckCircle2 className="w-5 h-5 shrink-0" />
                  <span>Your DMCA complaint notice has been recorded. Our legal audit team will review the product URL within 24 hours.</span>
                </div>
              ) : (
                <form onSubmit={handleDMCASubmit} className="space-y-4 bg-neutral-50 dark:bg-neutral-800/40 p-6 rounded-2xl border border-neutral-200 dark:border-neutral-800 text-xs">
                  <h3 className="font-bold text-neutral-900 dark:text-white">
                    Submit Copyright Takedown Notice
                  </h3>
                  <div>
                    <label className="block font-medium mb-1">Product Title or Link</label>
                    <input
                      type="text"
                      required
                      value={infringingUrl}
                      onChange={(e) => setInfringingUrl(e.target.value)}
                      placeholder="e.g. Modern Business eBook or specific product URL"
                      className="w-full p-2.5 bg-white dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-medium mb-1">Copyright Holder Name</label>
                      <input
                        type="text"
                        required
                        value={ownerName}
                        onChange={(e) => setOwnerName(e.target.value)}
                        placeholder="Owner or Author Name"
                        className="w-full p-2.5 bg-white dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700"
                      />
                    </div>
                    <div>
                      <label className="block font-medium mb-1">Contact Email</label>
                      <input
                        type="email"
                        required
                        value={contactEmail}
                        onChange={(e) => setContactEmail(e.target.value)}
                        placeholder="legal@rights-owner.com"
                        className="w-full p-2.5 bg-white dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block font-medium mb-1">Statement of Good Faith</label>
                    <textarea
                      rows={2}
                      value={statement}
                      onChange={(e) => setStatement(e.target.value)}
                      placeholder="I have a good faith belief that use of the material in the manner complained of is not authorized by the copyright owner..."
                      className="w-full p-2.5 bg-white dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold cursor-pointer transition-colors"
                  >
                    File Takedown Notice
                  </button>
                </form>
              )}
            </div>
          )}

          {activeSection === 'seller-agreement' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold text-neutral-950 dark:text-white">
                5. Creator & Seller Marketplace Agreement
              </h2>
              <p>
                Sellers retain 100% intellectual property ownership of their source files. By publishing on DigiMarket, sellers authorize the marketplace to process payments, encrypt deliverables, and distribute licenses to paying purchasers.
              </p>
              <h3 className="text-sm font-bold text-neutral-900 dark:text-white pt-2">
                Revenue Split & Payout Rules
              </h3>
              <p>
                DigiMarket applies a transparent 80/20 revenue model: 80% of verified net revenue is credited to the seller's balance immediately upon checkout confirmation. Payouts are executed without mandatory escrow delays once the threshold of $50 is met.
              </p>
              <p>
                Sellers warrant and represent that all files uploaded are original works created by them or their contracted studio with clear chain-of-title.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
