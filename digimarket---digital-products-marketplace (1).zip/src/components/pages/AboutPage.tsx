import React from 'react';
import { useApp } from '../../context/AppContext';
import { ShieldCheck, Download, Zap, Users, KeyRound, Lock } from 'lucide-react';

export const AboutPage: React.FC = () => {
  const { navigate, setIsBecomeSellerModalOpen } = useApp();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
      {/* Hero Header */}
      <div className="max-w-3xl mb-16">
        <span className="text-xs font-semibold uppercase tracking-wider text-amber-600 dark:text-amber-400">
          Our Purpose & Integrity
        </span>
        <h1 className="text-3xl sm:text-5xl font-bold font-display text-neutral-950 dark:text-white mt-2 leading-tight">
          DigiMarket connects creators with customers through verified digital deliverables.
        </h1>
        <p className="mt-6 text-base text-neutral-600 dark:text-neutral-300 leading-relaxed">
          Founded on the principle of creator sovereignty and verified intellectual property distribution, DigiMarket provides an uncompromising digital platform where sound designers, authors, 3D artists, and software developers sell directly with 80% revenue retention and zero bandwidth penalties.
        </p>
      </div>

      {/* 4 Core Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
        <div className="p-6 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
          <Download className="w-6 h-6 text-amber-500 mb-3" />
          <h3 className="text-sm font-bold text-neutral-900 dark:text-white">Instant Fulfillment</h3>
          <p className="text-xs text-neutral-500 mt-2 leading-relaxed">
            Eliminating physical shipping friction. Receive cryptographic delivery tokens with high-bandwidth CDN mirrors in seconds upon payment clearance.
          </p>
        </div>

        <div className="p-6 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
          <ShieldCheck className="w-6 h-6 text-emerald-500 mb-3" />
          <h3 className="text-sm font-bold text-neutral-900 dark:text-white">Commercial Rights</h3>
          <p className="text-xs text-neutral-500 mt-2 leading-relaxed">
            Transparent licensing tiers guarantee copyright safety for corporate pitch decks, commercial broadcasts, and client web applications.
          </p>
        </div>

        <div className="p-6 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
          <Zap className="w-6 h-6 text-blue-500 mb-3" />
          <h3 className="text-sm font-bold text-neutral-900 dark:text-white">Creator-First 80%</h3>
          <p className="text-xs text-neutral-500 mt-2 leading-relaxed">
            80% of net transaction revenue flows directly into creator accounts without mandatory holding periods or processing penalties.
          </p>
        </div>

        <div className="p-6 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
          <Lock className="w-6 h-6 text-purple-500 mb-3" />
          <h3 className="text-sm font-bold text-neutral-900 dark:text-white">Verified Security</h3>
          <p className="text-xs text-neutral-500 mt-2 leading-relaxed">
            Every deliverable file is inspected for integrity and distributed with SHA-256 tamper-evident tokens and automated payment verification.
          </p>
        </div>
      </div>

      {/* Creator CTA */}
      <div className="p-8 sm:p-12 bg-neutral-900 text-white rounded-3xl border border-neutral-800 flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold font-display text-white">
            Ready to sell your digital craft?
          </h2>
          <p className="text-xs sm:text-sm text-neutral-300 mt-1 max-w-lg">
            Join thousands of independent studios selling master audio, 3D assets, publications, and UI components worldwide.
          </p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => setIsBecomeSellerModalOpen(true)}
            className="px-6 py-3 bg-white text-neutral-950 hover:bg-neutral-100 rounded-xl text-xs font-bold transition-all shadow cursor-pointer whitespace-nowrap"
          >
            Open Storefront
          </button>
          <button
            onClick={() => navigate('marketplace')}
            className="px-6 py-3 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-semibold transition-all cursor-pointer whitespace-nowrap"
          >
            Browse Products
          </button>
        </div>
      </div>
    </div>
  );
};
