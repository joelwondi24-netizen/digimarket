import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Mail, MessageSquare, ShieldCheck, Send, CheckCircle2 } from 'lucide-react';

export const ContactPage: React.FC = () => {
  const { showToast } = useApp();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('Customer Support');
  const [message, setMessage] = useState('');
  const [honeypot, setHoneypot] = useState(''); // Anti-spam trap
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (honeypot) return; // Silent discard bot spam
    if (!name.trim() || !email.trim() || !message.trim()) return;

    setIsSubmitted(true);
    showToast('success', 'Inquiry Received', 'Our support operations team will reply within 4 business hours.');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Left Column: Direct Inquiries info */}
        <div className="lg:col-span-5 space-y-6">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-600 dark:text-amber-400">
              Support & Inquiries
            </span>
            <h1 className="text-3xl font-bold font-display text-neutral-950 dark:text-white mt-1">
              Connect with DigiMarket
            </h1>
            <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-400 mt-2 leading-relaxed">
              Have questions regarding digital product licensing, payment verification, or order access tokens? Our operations team is ready to assist.
            </p>
          </div>

          <div className="space-y-4 pt-4">
            <div className="p-4 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
              <h3 className="text-xs font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <Mail className="w-4 h-4 text-amber-500" /> Customer Support
              </h3>
              <p className="text-xs text-neutral-500 mt-1">support@digimarket.io</p>
              <p className="text-[11px] text-neutral-400 mt-0.5">Response window: &lt; 4 hours</p>
            </div>

            <div className="p-4 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
              <h3 className="text-xs font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-emerald-500" /> Creator & Seller Partnerships
              </h3>
              <p className="text-xs text-neutral-500 mt-1">creators@digimarket.io</p>
              <p className="text-[11px] text-neutral-400 mt-0.5">Studio onboarding & payouts</p>
            </div>

            <div className="p-4 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800">
              <h3 className="text-xs font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-500" /> Copyright & Legal Audits
              </h3>
              <p className="text-xs text-neutral-500 mt-1">legal@digimarket.io</p>
              <p className="text-[11px] text-neutral-400 mt-0.5">DMCA notices and license compliance</p>
            </div>
          </div>
        </div>

        {/* Right Column: Contact Form */}
        <div className="lg:col-span-7 bg-white dark:bg-neutral-900 p-8 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 shadow-sm">
          {isSubmitted ? (
            <div className="py-12 text-center space-y-3">
              <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-neutral-900 dark:text-white">
                Message Dispatched
              </h3>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto">
                Thank you, {name}. A ticket has been created and our support engineers have been notified.
              </p>
              <button
                onClick={() => setIsSubmitted(false)}
                className="mt-4 px-4 py-2 bg-neutral-900 text-white rounded-xl text-xs font-semibold cursor-pointer"
              >
                Send Another Inquiry
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              {/* Anti-spam honeypot */}
              <input
                type="text"
                name="website_url_check"
                value={honeypot}
                onChange={(e) => setHoneypot(e.target.value)}
                className="hidden"
                tabIndex={-1}
                autoComplete="off"
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                    Your Name
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Alex Rivera"
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700"
                  />
                </div>
                <div>
                  <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                    Your Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="alex@example.com"
                    className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                  Topic / Subject
                </label>
                <select
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 cursor-pointer"
                >
                  <option value="Customer Support">Download Link / Purchase Verification Support</option>
                  <option value="Seller Application">Creator Onboarding & Payouts</option>
                  <option value="Commercial Licensing">Custom Enterprise Licensing Extension</option>
                  <option value="Copyright Report">DMCA Notice / Intellectual Property Report</option>
                  <option value="Other">General Question</option>
                </select>
              </div>

              <div>
                <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                  Your Message
                </label>
                <textarea
                  rows={4}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Provide order reference numbers, requested license extensions, or studio details..."
                  className="w-full p-2.5 bg-neutral-50 dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 rounded-xl text-xs font-bold transition-all shadow flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" /> Submit Inquiry
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
