import React from 'react';
import { Star } from 'lucide-react';

export const Testimonials: React.FC = () => {
  const testimonials = [
    {
      name: 'Maya Lin',
      role: 'Creative Director',
      company: 'Studio Aethel Zurich',
      content:
        'We replaced three fragmented stock subscriptions with DigiMarket. The uncompressed audio stems and 8K travertine textures cut our production turnaround on the Zurich Pavilion launch by 40% with zero licensing ambiguity.',
      rating: 5,
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80',
    },
    {
      name: 'Julian Vance',
      role: 'Lead Sound Designer',
      company: 'Kinetic Motion Works',
      content:
        'Instant delivery with verified cryptographic tokens is revolutionary. Within two minutes of checking out, our team had the 24-bit/96kHz WAV files loaded directly into our DaVinci Resolve timelines.',
      rating: 5,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    },
    {
      name: 'Amara Okafor',
      role: 'Product Lead',
      company: 'Vanguard Ventures London',
      content:
        'The Modern Business & Product Engineering Blueprint gave us battle-tested financial models and Notion systems that saved us approximately four weeks of structuring prior to our Series A deck completion.',
      rating: 5,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    },
  ];

  return (
    <section className="py-14 border-b border-neutral-200/80 dark:border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-xl mx-auto mb-12">
          <span className="text-xs font-semibold uppercase tracking-wider text-amber-600 dark:text-amber-400">
            Customer Testimonials
          </span>
          <h2 className="text-2xl font-bold font-display text-neutral-950 dark:text-white mt-1">
            Trusted by Creators & Studios Worldwide
          </h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Real feedback from commercial filmmakers, founders, and digital design teams.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t, idx) => (
            <div
              key={idx}
              className="p-6 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 flex flex-col justify-between"
            >
              <div>
                <div className="flex text-amber-400 mb-3">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-current" />
                  ))}
                </div>
                <p className="text-xs sm:text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed italic">
                  "{t.content}"
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-neutral-100 dark:border-neutral-800 flex items-center gap-3">
                <img
                  src={t.avatar}
                  alt={t.name}
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <h4 className="text-xs font-bold text-neutral-900 dark:text-white">{t.name}</h4>
                  <p className="text-[11px] text-neutral-500 dark:text-neutral-400">
                    {t.role} · {t.company}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
