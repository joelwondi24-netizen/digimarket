import React, { useState } from 'react';
import { Hero } from './Hero';
import { CategoryGrid } from './CategoryGrid';
import { FeaturedSection } from './FeaturedSection';
import { PromoBanner } from './PromoBanner';
import { CreatorSpotlight } from './CreatorSpotlight';
import { Testimonials } from './Testimonials';
import { useApp } from '../../context/AppContext';
import { Send, CheckCircle2, HelpCircle, ArrowRight, ShieldCheck } from 'lucide-react';

export const HomePage: React.FC = () => {
  const { navigate, showToast } = useApp();
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail && newsletterEmail.includes('@')) {
      setIsSubscribed(true);
      showToast('success', 'Subscribed!', 'You will receive monthly curated digital drops & coupon codes.');
      setNewsletterEmail('');
    }
  };

  const quickFaqs = [
    {
      q: 'How does verified digital download delivery work?',
      a: 'Immediately after checkout clearance, our backend generates a unique cryptographic download token with verified source file mirrors. You can also re-download any purchased package anytime from your Customer Dashboard or through the Verify & Download tool.',
    },
    {
      q: 'Can I use downloaded items for commercial client deliverables?',
      a: 'Yes! All digital products on DigiMarket come with a standard commercial license allowing unlimited commercial projects, client deliverables, streaming videos, and web applications without recurring royalties.',
    },
    {
      q: 'How are payments verified before downloads are issued?',
      a: 'All transactions are authenticated through PCI-DSS Level 1 payment providers (Stripe, PayPal, Apple Pay) with 3D-Secure verification. Upon verified clearance, secure expiring tokens with download caps and SHA-256 integrity digests are generated.',
    },
  ];

  return (
    <div>
      {/* 1. Hero */}
      <Hero />

      {/* 2. Categories Grid */}
      <CategoryGrid />

      {/* 3. Featured & Bestsellers Products */}
      <FeaturedSection />

      {/* 4. Promotional Banner */}
      <PromoBanner />

      {/* 5. Creator Spotlight */}
      <CreatorSpotlight />

      {/* 6. Testimonials */}
      <Testimonials />

      {/* 7. Quick FAQ & Newsletter */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            {/* Quick FAQs (7 cols) */}
            <div className="lg:col-span-7">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                    Questions & Answers
                  </span>
                  <h3 className="text-xl font-bold font-display text-neutral-950 dark:text-white mt-1">
                    Frequently Asked Questions
                  </h3>
                </div>
                <button
                  onClick={() => navigate('faq')}
                  className="text-xs font-semibold text-neutral-900 dark:text-white hover:underline flex items-center gap-1 cursor-pointer"
                >
                  All FAQs <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="space-y-4">
                {quickFaqs.map((faq, i) => (
                  <div
                    key={i}
                    className="p-5 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800"
                  >
                    <h4 className="text-xs sm:text-sm font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                      <HelpCircle className="w-4 h-4 text-amber-500 shrink-0" />
                      {faq.q}
                    </h4>
                    <p className="text-xs text-neutral-600 dark:text-neutral-300 mt-2 leading-relaxed">
                      {faq.a}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Newsletter Subscription (5 cols) */}
            <div className="lg:col-span-5 p-6 sm:p-8 bg-neutral-900 text-white rounded-3xl border border-neutral-800 shadow-xl">
              <div className="flex items-center gap-2 text-xs text-emerald-400 font-semibold mb-2">
                <ShieldCheck className="w-4 h-4" />
                <span>Verified Creator Network</span>
              </div>
              <h3 className="text-lg font-bold font-display text-white">
                Join the Creator Dispatch
              </h3>
              <p className="text-xs text-neutral-300 mt-1.5 leading-relaxed">
                Receive weekly curated digital freebies, new 3D shader releases, audio stems, and private 20% discount codes.
              </p>

              {isSubscribed ? (
                <div className="mt-6 p-4 bg-emerald-950/50 border border-emerald-800/80 rounded-xl flex items-center gap-3 text-emerald-300 text-xs">
                  <CheckCircle2 className="w-5 h-5 shrink-0" />
                  <span>You are subscribed! Check your inbox for your welcome coupon code.</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="mt-6 space-y-3">
                  <input
                    type="email"
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    placeholder="Enter your email address..."
                    required
                    className="w-full px-4 py-3 text-xs bg-neutral-800 border border-neutral-700 rounded-xl text-white placeholder-neutral-400 focus:outline-none focus:ring-1 focus:ring-neutral-400"
                  />
                  <button
                    type="submit"
                    className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-neutral-950 rounded-xl text-xs font-bold transition-colors shadow flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" /> Subscribe to Dispatch
                  </button>
                  <p className="text-[10px] text-neutral-400 text-center">
                    No spam ever. Unsubscribe with a single click at any time.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
