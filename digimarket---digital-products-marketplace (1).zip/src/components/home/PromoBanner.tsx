import React from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowRight, Tag } from 'lucide-react';

export const PromoBanner: React.FC = () => {
  const { navigate } = useApp();

  return (
    <section className="py-12 border-b border-neutral-200/80 dark:border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-neutral-900 text-white p-8 sm:p-12 md:p-16 border border-neutral-800 shadow-xl">
          {/* Subtle geometric backdrop */}
          <div className="absolute right-0 top-0 bottom-0 w-1/2 opacity-20 pointer-events-none hidden md:block">
            <img
              src="/src/assets/images/sculpture_3d_pack_1791198439460.jpg"
              alt=""
              className="w-full h-full object-cover object-center"
            />
          </div>

          <div className="relative z-10 max-w-xl">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400 mb-3">
              <Tag className="w-3.5 h-3.5" />
              <span>Limited Creative Season Offer</span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-bold font-display tracking-tight text-white leading-tight">
              Upgrade Your Creative Stack
            </h2>

            <p className="mt-3 text-sm sm:text-base text-neutral-300 leading-relaxed">
              Save up to 40% on verified digital packages. Apply creator coupon codes at checkout for instant discounts on master asset bundles, lossless stems, and editorial publications.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                onClick={() => navigate('marketplace')}
                className="px-6 py-3.5 bg-white text-neutral-950 hover:bg-neutral-100 rounded-xl text-sm font-bold shadow transition-colors flex items-center gap-2 cursor-pointer"
              >
                <span>Shop Bundles</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <div className="text-xs text-neutral-400">
                Active Code:{' '}
                <span className="font-mono font-bold text-amber-300 bg-neutral-800 px-2 py-1 rounded">
                  DIGI20
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
