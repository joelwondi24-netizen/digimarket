import React from 'react';
import { useApp } from '../../context/AppContext';
import { Star, CheckCircle, ArrowRight, Sparkles } from 'lucide-react';

export const CreatorSpotlight: React.FC = () => {
  const { sellers, navigate, setIsBecomeSellerModalOpen, showToast } = useApp();

  const handleFollow = (e: React.MouseEvent, storeName: string) => {
    e.stopPropagation();
    showToast('success', 'Followed Creator', `You are now following ${storeName}.`);
  };

  return (
    <section className="py-14 border-b border-neutral-200/80 dark:border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-600 dark:text-amber-400">
              Community & Studios
            </span>
            <h2 className="text-2xl font-bold font-display text-neutral-950 dark:text-white mt-1">
              Featured Creators & Studios
            </h2>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
              Directly supporting independent sound composers, authors, 3D artists, and design engineers.
            </p>
          </div>
          <button
            onClick={() => setIsBecomeSellerModalOpen(true)}
            className="text-xs font-semibold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1.5 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Open Your Store</span>
          </button>
        </div>

        {/* 4 Creator Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {sellers.map((seller) => (
            <div
              key={seller.id}
              onClick={() => navigate('seller-storefront', { sellerId: seller.id })}
              className="group p-5 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 hover:-translate-y-1 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-3 mb-3">
                  <img
                    src={seller.avatar}
                    alt={seller.name}
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-full object-cover border border-neutral-200 dark:border-neutral-700"
                  />
                  <div>
                    <h3 className="text-sm font-bold text-neutral-900 dark:text-white flex items-center gap-1 group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">
                      {seller.storeName}
                      <CheckCircle className="w-3.5 h-3.5 text-blue-500 fill-current inline shrink-0" />
                    </h3>
                    <p className="text-[11px] text-neutral-400">
                      {seller.country} · {seller.joinedDate.split('-')[0]}
                    </p>
                  </div>
                </div>
                <p className="text-xs text-neutral-600 dark:text-neutral-300 line-clamp-3 leading-relaxed">
                  {seller.bio}
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
                <div className="flex items-center gap-1 text-xs">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span className="font-bold text-neutral-900 dark:text-white tabular-nums">
                    {seller.rating.toFixed(2)}
                  </span>
                  <span className="text-neutral-400">({seller.salesCount})</span>
                </div>
                <button
                  onClick={(e) => handleFollow(e, seller.storeName)}
                  className="px-2.5 py-1 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 text-neutral-800 dark:text-neutral-200 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                >
                  Follow
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
