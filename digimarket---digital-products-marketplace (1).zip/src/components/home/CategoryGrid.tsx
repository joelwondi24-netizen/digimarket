import React from 'react';
import { useApp } from '../../context/AppContext';
import { CATEGORIES_CONFIG } from '../../data/mockData';
import {
  BookOpen,
  Image,
  Music,
  Video,
  Palette,
  Layout,
  FileText,
  Presentation,
  Type,
  Sparkles,
  Monitor,
  Sliders,
  Volume2,
  GraduationCap,
  Terminal,
  Box,
  Briefcase,
  Bookmark,
  ArrowRight,
} from 'lucide-react';
import { ProductCategory } from '../../types';

// Map icon string to Lucide component
const ICON_MAP: Record<string, React.FC<{ className?: string }>> = {
  BookOpen,
  Image,
  Music,
  Video,
  Palette,
  Layout,
  FileText,
  Presentation,
  Type,
  Sparkles,
  Monitor,
  Sliders,
  Volume2,
  GraduationCap,
  Terminal,
  Box,
  Briefcase,
  Bookmark,
};

export const CategoryGrid: React.FC = () => {
  const { navigate } = useApp();

  const handleSelectCategory = (categoryName: ProductCategory) => {
    navigate('marketplace', { category: categoryName });
  };

  return (
    <section className="py-14 border-b border-neutral-200/80 dark:border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-600 dark:text-amber-400">
              Taxonomy & Formats
            </span>
            <h2 className="text-2xl font-bold font-display text-neutral-950 dark:text-white mt-1">
              Explore by Category
            </h2>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
              Curated downloadable packages for audio, video, development, and publishing.
            </p>
          </div>
          <button
            onClick={() => navigate('marketplace')}
            className="text-xs font-semibold text-neutral-900 dark:text-white hover:text-amber-600 dark:hover:text-amber-400 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <span>All 18 Categories</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 6-Column Responsive Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
          {CATEGORIES_CONFIG.map((cat) => {
            const IconComponent = ICON_MAP[cat.icon] || Sparkles;
            return (
              <button
                key={cat.name}
                onClick={() => handleSelectCategory(cat.name)}
                className="group flex flex-col items-start p-4 rounded-xl bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800 hover:border-neutral-400 dark:hover:border-neutral-700 hover:-translate-y-0.5 hover:shadow-xs transition-all text-left cursor-pointer"
              >
                <div className="p-2.5 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 group-hover:bg-neutral-950 group-hover:text-white dark:group-hover:bg-white dark:group-hover:text-neutral-950 transition-colors mb-3">
                  <IconComponent className="w-4 h-4" />
                </div>
                <h3 className="text-xs font-bold text-neutral-900 dark:text-white group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors truncate w-full">
                  {cat.name}
                </h3>
                <span className="text-[11px] text-neutral-400 mt-0.5 tabular-nums">
                  {cat.count} assets
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
