import React from 'react';
import { useApp } from '../../context/AppContext';
import { ArrowRight, Sparkles, Download, ShieldCheck, Zap } from 'lucide-react';

export const Hero: React.FC = () => {
  const { navigate, setIsBecomeSellerModalOpen } = useApp();

  return (
    <section className="relative overflow-hidden pt-10 pb-16 md:pt-16 md:pb-24 border-b border-neutral-200/80 dark:border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Column: Editorial Headline & Value (7 cols) */}
          <div className="lg:col-span-7 flex flex-col items-start">
            {/* Subtle Brand Tag */}
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-600 dark:text-amber-400 mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Verified Creator Marketplace</span>
            </div>

            <h1
              className="text-3xl sm:text-5xl lg:text-6xl font-bold font-display tracking-tight text-neutral-950 dark:text-white leading-[1.08]"
              style={{ textWrap: 'balance' }}
            >
              Premium Digital Products for Modern Creators
            </h1>

            <p className="mt-5 text-sm sm:text-base text-neutral-600 dark:text-neutral-300 leading-relaxed max-w-2xl">
              Discover, license, and instantly download verified eBooks, lossless audio stems, 4K motion templates, 3D meshes, fonts, and creative resources with cryptographic proof of purchase.
            </p>

            {/* Primary Action Buttons */}
            <div className="mt-8 flex flex-wrap items-center gap-3 w-full sm:w-auto">
              <button
                onClick={() => navigate('marketplace')}
                className="w-full sm:w-auto px-6 py-3.5 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 rounded-xl text-sm font-bold shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Explore Products</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => navigate('verify-download')}
                className="w-full sm:w-auto px-6 py-3.5 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-900 dark:text-white rounded-xl text-sm font-semibold transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>Verify & Download</span>
              </button>
            </div>

            {/* Claim-to-Proof Adjacency Row */}
            <div className="mt-10 pt-8 border-t border-neutral-200/80 dark:border-neutral-800 grid grid-cols-3 gap-6 w-full text-xs text-neutral-500 dark:text-neutral-400">
              <div>
                <div className="flex items-center gap-1.5 font-bold text-neutral-900 dark:text-white text-base font-display">
                  <Download className="w-4 h-4 text-amber-500" />
                  <span>Instant</span>
                </div>
                <p className="text-[11px] mt-0.5">Secure expiring tokens</p>
              </div>
              <div>
                <div className="flex items-center gap-1.5 font-bold text-neutral-900 dark:text-white text-base font-display">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  <span>100%</span>
                </div>
                <p className="text-[11px] mt-0.5">Commercial sync rights</p>
              </div>
              <div>
                <div className="flex items-center gap-1.5 font-bold text-neutral-900 dark:text-white text-base font-display">
                  <Zap className="w-4 h-4 text-blue-500" />
                  <span>80%</span>
                </div>
                <p className="text-[11px] mt-0.5">Direct creator payout</p>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Showcase Visual (5 cols) */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-neutral-200/80 dark:border-neutral-800 bg-neutral-900 group">
              <img
                src="/src/assets/images/hero_digital_assets_1791198407854.jpg"
                alt="DigiMarket Creative Workstation"
                referrerPolicy="no-referrer"
                className="w-full aspect-[4/3] object-cover transition-transform duration-700 group-hover:scale-103"
              />
              {/* Measured Scrim for contrast overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent flex flex-col justify-end p-6 text-white">
                <div className="text-[11px] font-medium tracking-wide text-amber-400 uppercase">
                  Featured Master Package
                </div>
                <h3 className="text-lg font-bold mt-1 text-white">
                  The Complete Creator Asset Architecture
                </h3>
                <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/15 text-xs">
                  <span className="text-neutral-300">Modular Stems · 3D Meshes · Editorial Book</span>
                  <button
                    onClick={() => navigate('marketplace')}
                    className="font-semibold text-white hover:text-amber-400 flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    View Bundle <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
