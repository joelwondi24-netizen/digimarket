import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../marketplace/ProductCard';
import { ArrowRight } from 'lucide-react';
import { Product } from '../../types';
import { AudioPreviewModal } from '../product/AudioPreviewModal';
import { EbookPreviewModal } from '../product/EbookPreviewModal';
import { ImagePreviewModal } from '../product/ImagePreviewModal';

export const FeaturedSection: React.FC = () => {
  const { products, navigate } = useApp();
  const [activeTab, setActiveTab] = useState<'featured' | 'bestsellers' | 'new'>('featured');
  const [previewProduct, setPreviewProduct] = useState<Product | null>(null);

  const displayProducts = products
    .filter((p) => {
      if (activeTab === 'featured') return p.isFeatured;
      if (activeTab === 'bestsellers') return p.isBestseller;
      if (activeTab === 'new') return p.isNew;
      return true;
    })
    .slice(0, 4);

  return (
    <section className="py-14 border-b border-neutral-200/80 dark:border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-600 dark:text-amber-400">
              Curated Releases
            </span>
            <h2 className="text-2xl font-bold font-display text-neutral-950 dark:text-white mt-1">
              Top Rated Digital Drops
            </h2>
          </div>

          {/* Interactive Filter Tabs (Segmented Control) */}
          <div className="flex items-center gap-1 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-xl">
            <button
              onClick={() => setActiveTab('featured')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                activeTab === 'featured'
                  ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-white shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
              }`}
            >
              Featured
            </button>
            <button
              onClick={() => setActiveTab('bestsellers')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                activeTab === 'bestsellers'
                  ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-white shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
              }`}
            >
              Bestsellers
            </button>
            <button
              onClick={() => setActiveTab('new')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                activeTab === 'new'
                  ? 'bg-white dark:bg-neutral-900 text-neutral-950 dark:text-white shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900'
              }`}
            >
              New Releases
            </button>
          </div>
        </div>

        {/* 4 Column Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {displayProducts.map((prod) => (
            <ProductCard
              key={prod.id}
              product={prod}
              onQuickView={(p) => setPreviewProduct(p)}
            />
          ))}
        </div>

        <div className="mt-10 text-center">
          <button
            onClick={() => navigate('marketplace')}
            className="inline-flex items-center gap-2 text-xs font-bold text-neutral-900 dark:text-white hover:text-amber-600 dark:hover:text-amber-400 transition-colors cursor-pointer"
          >
            <span>Explore All {products.length} Products</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Preview Modals */}
      {previewProduct && (previewProduct.category === 'Music' || previewProduct.category === 'Audio') && (
        <AudioPreviewModal product={previewProduct} onClose={() => setPreviewProduct(null)} />
      )}
      {previewProduct && previewProduct.category === 'eBooks' && (
        <EbookPreviewModal product={previewProduct} onClose={() => setPreviewProduct(null)} />
      )}
      {previewProduct && previewProduct.category !== 'Music' && previewProduct.category !== 'Audio' && previewProduct.category !== 'eBooks' && (
        <ImagePreviewModal product={previewProduct} onClose={() => setPreviewProduct(null)} />
      )}
    </section>
  );
};
