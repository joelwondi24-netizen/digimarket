import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Sparkles, DollarSign } from 'lucide-react';
import { Seller } from '../../types';

export const BecomeSellerModal: React.FC = () => {
  const { isBecomeSellerModalOpen, setIsBecomeSellerModalOpen, becomeSeller } = useApp();
  const [storeName, setStoreName] = useState('');
  const [bio, setBio] = useState('');
  const [country, setCountry] = useState('United States');
  const [payoutMethod, setPayoutMethod] = useState<Seller['payoutMethod']>('stripe_connect');
  const [payoutAccount, setPayoutAccount] = useState('');
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  if (!isBecomeSellerModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!storeName.trim() || !agreedToTerms) return;

    becomeSeller({
      storeName: storeName.trim(),
      bio: bio.trim() || 'Independent creative producer.',
      country,
      payoutMethod,
      payoutAccount: payoutAccount.trim() || 'stripe_connected_acc',
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 rounded-3xl max-w-lg w-full overflow-hidden border border-neutral-200 dark:border-neutral-800 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-500" />
            <h2 className="text-base font-bold">Become a DigiMarket Creator</h2>
          </div>
          <button
            onClick={() => setIsBecomeSellerModalOpen(false)}
            className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {/* 80/20 Banner */}
          <div className="p-4 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900/60 flex items-start gap-3 text-amber-900 dark:text-amber-200">
            <DollarSign className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold">80% Creator Revenue Share</h4>
              <p className="text-[11px] mt-0.5 opacity-90 leading-relaxed">
                You receive 80% of every sale. DigiMarket handles encrypted delivery, global card verification, and verified download token issuance.
              </p>
            </div>
          </div>

          <div>
            <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
              Studio / Storefront Name
            </label>
            <input
              type="text"
              required
              value={storeName}
              onChange={(e) => setStoreName(e.target.value)}
              placeholder="e.g. Chromaform Labs, Nordic Frame Studio"
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-400"
            />
          </div>

          <div>
            <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
              Creator Bio & Discipline
            </label>
            <textarea
              rows={2}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell buyers about your audio stems, eBooks, 3D meshes, or code..."
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-400"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Country
              </label>
              <select
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl cursor-pointer"
              >
                <option value="United States">United States</option>
                <option value="United Kingdom">United Kingdom</option>
                <option value="Switzerland">Switzerland</option>
                <option value="Germany">Germany</option>
                <option value="Japan">Japan</option>
                <option value="Canada">Canada</option>
                <option value="Australia">Australia</option>
                <option value="Sweden">Sweden</option>
              </select>
            </div>
            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Payout Preference
              </label>
              <select
                value={payoutMethod}
                onChange={(e) => setPayoutMethod(e.target.value as Seller['payoutMethod'])}
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl cursor-pointer"
              >
                <option value="stripe_connect">Stripe Connect</option>
                <option value="paypal">PayPal</option>
                <option value="bank_wire">Direct Wire Transfer</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
              Payout Account (Email or IBAN)
            </label>
            <input
              type="text"
              value={payoutAccount}
              onChange={(e) => setPayoutAccount(e.target.value)}
              placeholder="e.g. payouts@yourstudio.com or IBAN"
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none"
            />
          </div>

          <div className="pt-2">
            <label className="flex items-start gap-2 cursor-pointer">
              <input
                type="checkbox"
                required
                checked={agreedToTerms}
                onChange={(e) => setAgreedToTerms(e.target.checked)}
                className="mt-0.5 accent-neutral-900"
              />
              <span className="text-[11px] text-neutral-600 dark:text-neutral-400">
                I certify that all digital deliverables I upload are original works created by me or my studio with verified commercial publishing rights under the DigiMarket Seller Agreement.
              </span>
            </label>
          </div>

          <div className="pt-4 flex gap-3">
            <button
              type="button"
              onClick={() => setIsBecomeSellerModalOpen(false)}
              className="flex-1 py-2.5 bg-neutral-100 dark:bg-neutral-800 rounded-xl font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!agreedToTerms || !storeName.trim()}
              className="flex-1 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 rounded-xl font-bold transition-all disabled:opacity-50 cursor-pointer"
            >
              Launch Storefront
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
