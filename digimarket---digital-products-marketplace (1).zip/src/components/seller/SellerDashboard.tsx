import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  DollarSign,
  TrendingUp,
  Download,
  Upload,
  Star,
  Trash2,
  Eye,
} from 'lucide-react';

export const SellerDashboard: React.FC = () => {
  const {
    currentUser,
    sellers,
    products,
    setIsUploadModalOpen,
    requestSellerPayout,
    deleteProduct,
    navigate,
  } = useApp();

  const seller = sellers.find((s) => s.id === currentUser?.sellerId) || sellers[0];
  const sellerProducts = products.filter((p) => p.sellerId === seller.id);
  const totalDownloads = sellerProducts.reduce((sum, p) => sum + p.downloadCount, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-8 border-b border-neutral-200/80 dark:border-neutral-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold font-display text-neutral-950 dark:text-white">
              {seller.storeName} · Creator Studio
            </h1>
            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
              Verified Creator
            </span>
          </div>
          <p className="text-xs text-neutral-500 mt-1">
            80% creator net share · Real-time digital download delivery analytics
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('seller-storefront', { sellerId: seller.id })}
            className="px-4 py-2 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-200 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Eye className="w-3.5 h-3.5" /> View Public Storefront
          </button>
          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 rounded-xl text-xs font-bold transition-all shadow flex items-center gap-1.5 cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5" /> Upload Digital Asset
          </button>
        </div>
      </div>

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-8">
        {/* Stat 1: Gross Sales */}
        <div className="p-6 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs">
            <span>Gross Platform Sales</span>
            <DollarSign className="w-4 h-4 text-neutral-400" />
          </div>
          <div className="text-2xl font-bold font-display text-neutral-900 dark:text-white mt-2 tabular-nums">
            ${seller.grossRevenue.toFixed(2)}
          </div>
          <p className="text-[11px] text-neutral-400 mt-1">
            Across {seller.salesCount} customer purchases
          </p>
        </div>

        {/* Stat 2: Net Creator Earnings (80%) */}
        <div className="p-6 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs">
            <span>Creator Net Share (80%)</span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold font-display text-emerald-600 dark:text-emerald-400 mt-2 tabular-nums">
            ${seller.netEarnings.toFixed(2)}
          </div>
          <p className="text-[11px] text-neutral-400 mt-1">
            Directly earned income
          </p>
        </div>

        {/* Stat 3: Pending Payouts & Action */}
        <div className="p-6 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-neutral-500 text-xs">
              <span>Pending Available Payout</span>
              <span className="font-mono text-[10px] text-amber-500 font-bold uppercase">Ready</span>
            </div>
            <div className="text-2xl font-bold font-display text-neutral-900 dark:text-white mt-2 tabular-nums">
              ${seller.pendingPayouts.toFixed(2)}
            </div>
          </div>
          <button
            onClick={() => requestSellerPayout(seller.id)}
            disabled={seller.pendingPayouts <= 0}
            className="mt-3 w-full py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 rounded-lg text-xs font-semibold disabled:opacity-40 transition-colors cursor-pointer"
          >
            Request Payout Now
          </button>
        </div>

        {/* Stat 4: Downloads & Catalog count */}
        <div className="p-6 bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs">
            <span>Downloads & Rating</span>
            <Download className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold font-display text-neutral-900 dark:text-white mt-2 tabular-nums">
            {totalDownloads}
          </div>
          <div className="flex items-center gap-1 text-[11px] text-amber-500 mt-1">
            <Star className="w-3.5 h-3.5 fill-current" />
            <span className="font-semibold">{seller.rating.toFixed(2)} Store Rating</span>
          </div>
        </div>
      </div>

      {/* Product Catalog Management Table */}
      <section className="mt-12">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-bold text-neutral-900 dark:text-white">
            Your Digital Catalog ({sellerProducts.length} items)
          </h2>
          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="text-xs font-semibold text-neutral-900 dark:text-white hover:underline cursor-pointer"
          >
            + Add New Product
          </button>
        </div>

        <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200/80 dark:border-neutral-800 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-neutral-50 dark:bg-neutral-800/60 border-b border-neutral-200 dark:border-neutral-800 text-neutral-500 font-semibold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="px-4 py-3">Product</th>
                  <th className="px-4 py-3">Category</th>
                  <th className="px-4 py-3">Price</th>
                  <th className="px-4 py-3">Sales</th>
                  <th className="px-4 py-3">Downloads</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100 dark:divide-neutral-800">
                {sellerProducts.map((p) => (
                  <tr key={p.id} className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/40">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <img
                          src={p.thumbnail}
                          alt=""
                          referrerPolicy="no-referrer"
                          className="w-10 h-10 rounded-lg object-cover bg-neutral-200 shrink-0"
                        />
                        <div className="min-w-0">
                          <p className="font-semibold text-neutral-900 dark:text-white truncate max-w-xs">
                            {p.title}
                          </p>
                          <p className="text-[11px] text-neutral-400 font-mono">
                            {p.fileFormat} · {p.fileSize}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-neutral-600 dark:text-neutral-300">
                      {p.category}
                    </td>
                    <td className="px-4 py-3 font-semibold text-neutral-900 dark:text-white tabular-nums">
                      ${p.price.toFixed(2)}
                    </td>
                    <td className="px-4 py-3 tabular-nums text-neutral-600 dark:text-neutral-300">
                      {p.salesCount}
                    </td>
                    <td className="px-4 py-3 tabular-nums text-neutral-600 dark:text-neutral-300">
                      {p.downloadCount}
                    </td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 capitalize">
                        {p.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => navigate('product-details', { productId: p.id })}
                          className="p-1 text-neutral-500 hover:text-neutral-900 dark:hover:text-white cursor-pointer"
                          title="View"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteProduct(p.id)}
                          className="p-1 text-neutral-400 hover:text-rose-500 cursor-pointer"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
};
