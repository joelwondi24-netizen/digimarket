import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from '../marketplace/ProductCard';
import { Star, CheckCircle, Share2, ArrowLeft } from 'lucide-react';

export const SellerStorefront: React.FC = () => {
  const { selectedSeller, sellers, products, navigate, showToast } = useApp();
  const seller = selectedSeller || sellers[0];
  const [isFollowing, setIsFollowing] = useState(false);

  const sellerProducts = products.filter((p) => p.sellerId === seller.id && p.status === 'published');

  const handleFollowToggle = () => {
    setIsFollowing((f) => !f);
    showToast(
      'success',
      isFollowing ? 'Unfollowed Creator' : 'Following Creator',
      `You will receive drop alerts from ${seller.storeName}.`
    );
  };

  const handleShare = () => {
    navigator.clipboard?.writeText?.(window.location.href);
    showToast('success', 'Storefront Link Copied');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
      {/* Back button */}
      <button
        onClick={() => navigate('marketplace')}
        className="mb-6 flex items-center gap-1.5 text-xs text-neutral-500 hover:text-neutral-900 dark:hover:text-white transition-colors cursor-pointer"
      >
        <ArrowLeft className="w-3.5 h-3.5" /> Back to Marketplace
      </button>

      {/* Store Header Banner */}
      <div className="bg-white dark:bg-neutral-900 rounded-3xl border border-neutral-200/80 dark:border-neutral-800 p-6 sm:p-8 md:p-10 shadow-xs mb-10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex flex-col sm:flex-row sm:items-center gap-6">
            <img
              src={seller.avatar}
              alt={seller.name}
              referrerPolicy="no-referrer"
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-full object-cover border-4 border-neutral-100 dark:border-neutral-800 shadow-md"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-3xl font-bold font-display text-neutral-950 dark:text-white">
                  {seller.storeName}
                </h1>
                <CheckCircle className="w-5 h-5 text-blue-500 fill-current" />
              </div>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
                Founded by {seller.name} · {seller.country} · Member since {seller.joinedDate.split('-')[0]}
              </p>

              {/* Unboxed Metadata Stats */}
              <div className="flex flex-wrap items-center gap-4 text-xs text-neutral-600 dark:text-neutral-300 mt-3 pt-3 border-t border-neutral-100 dark:border-neutral-800">
                <div className="flex items-center gap-1 text-amber-500 font-bold">
                  <Star className="w-3.5 h-3.5 fill-current" />
                  <span className="text-neutral-900 dark:text-white tabular-nums">{seller.rating.toFixed(2)}</span>
                  <span className="text-neutral-400 font-normal">Rating</span>
                </div>
                <span>·</span>
                <div>
                  <strong className="text-neutral-900 dark:text-white tabular-nums">{seller.salesCount}</strong>{' '}
                  <span className="text-neutral-400">Total Sales</span>
                </div>
                <span>·</span>
                <div>
                  <strong className="text-neutral-900 dark:text-white tabular-nums">{sellerProducts.length}</strong>{' '}
                  <span className="text-neutral-400">Published Products</span>
                </div>
                <span>·</span>
                <div>
                  <strong className="text-neutral-900 dark:text-white tabular-nums">
                    {(seller.followersCount + (isFollowing ? 1 : 0)).toLocaleString()}
                  </strong>{' '}
                  <span className="text-neutral-400">Followers</span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleFollowToggle}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer ${
                isFollowing
                  ? 'bg-neutral-100 dark:bg-neutral-800 text-neutral-900 dark:text-white border border-neutral-300 dark:border-neutral-700'
                  : 'bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100'
              }`}
            >
              {isFollowing ? 'Following' : 'Follow Creator'}
            </button>
            <button
              onClick={handleShare}
              className="p-2.5 bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-300 rounded-xl transition-colors cursor-pointer"
              title="Share storefront"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Bio description */}
        <p className="mt-6 text-xs sm:text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed max-w-3xl">
          {seller.bio}
        </p>
      </div>

      {/* Products Grid */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold font-display text-neutral-950 dark:text-white">
            Available Deliverables by {seller.storeName} ({sellerProducts.length})
          </h2>
        </div>

        {sellerProducts.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 text-xs text-neutral-500">
            No published products yet from this creator.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {sellerProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
