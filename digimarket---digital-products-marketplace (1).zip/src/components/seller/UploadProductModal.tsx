import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Upload, FileCheck, CheckCircle2 } from 'lucide-react';
import { ProductCategory, LicenseType } from '../../types';
import { CATEGORIES_CONFIG } from '../../data/mockData';

export const UploadProductModal: React.FC = () => {
  const { isUploadModalOpen, setIsUploadModalOpen, uploadProduct } = useApp();
  const [title, setTitle] = useState('');
  const [tagline, setTagline] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<ProductCategory>('Templates');
  const [subcategory, setSubcategory] = useState('UI Systems');
  const [price, setPrice] = useState('24.00');
  const [originalPrice, setOriginalPrice] = useState('36.00');
  const [fileFormat, setFileFormat] = useState('ZIP (Source Assets)');
  const [fileSize, setFileSize] = useState('85 MB');
  const [license, setLicense] = useState<LicenseType>('commercial');
  const [features, setFeatures] = useState('Master high-res source files, Vector diagrams, Commercial license certificate');
  const [whatsIncluded, setWhatsIncluded] = useState('Asset Archive ZIP, Setup Guide PDF, License Token');

  // Simulated upload state
  const [simulatedFile, setSimulatedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);

  if (!isUploadModalOpen) return null;

  const handleFileDrop = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSimulatedFile(file);
      setFileSize(`${(file.size / (1024 * 1024)).toFixed(1)} MB`);
      const ext = file.name.split('.').pop()?.toUpperCase() || 'ZIP';
      setFileFormat(`${ext} Package`);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setIsUploading(true);
    setUploadProgress(15);
    const interval = setInterval(() => {
      setUploadProgress((p) => {
        if (p >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          uploadProduct({
            title: title.trim(),
            tagline: tagline.trim() || 'Premium digital download package.',
            description: description.trim() || 'Complete creative asset package with verified commercial usage rights.',
            category,
            subcategory,
            price: parseFloat(price) || 19.99,
            originalPrice: originalPrice ? parseFloat(originalPrice) : undefined,
            fileFormat,
            fileSize,
            license,
            features: features.split(',').map((f) => f.trim()),
            whatsIncluded: whatsIncluded.split(',').map((w) => w.trim()),
            status: 'published',
            thumbnail: '/src/assets/images/hero_digital_assets_1791198407854.jpg',
            previewImages: ['/src/assets/images/hero_digital_assets_1791198407854.jpg'],
          });
          return 100;
        }
        return p + 25;
      });
    }, 180);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 rounded-3xl max-w-2xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-neutral-200 dark:border-neutral-800 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-emerald-500" />
            <h2 className="text-base font-bold">Publish New Digital Deliverable</h2>
          </div>
          <button
            onClick={() => setIsUploadModalOpen(false)}
            className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
          <div>
            <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
              Product Title
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Cinematic Modular Audio Stems Vol. 2"
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-400"
            />
          </div>

          <div>
            <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
              Short Tagline
            </label>
            <input
              type="text"
              value={tagline}
              onChange={(e) => setTagline(e.target.value)}
              placeholder="e.g. 24 uncompressed 24-bit/96kHz analog synth cues and textures."
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl focus:outline-none focus:ring-1 focus:ring-neutral-400"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ProductCategory)}
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl cursor-pointer"
              >
                {CATEGORIES_CONFIG.map((c) => (
                  <option key={c.name} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Subcategory
              </label>
              <input
                type="text"
                value={subcategory}
                onChange={(e) => setSubcategory(e.target.value)}
                placeholder="e.g. Soundtracks & Score"
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Price ($ USD)
              </label>
              <input
                type="number"
                step="0.01"
                required
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl font-mono"
              />
            </div>
            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Original Price (Optional)
              </label>
              <input
                type="number"
                step="0.01"
                value={originalPrice}
                onChange={(e) => setOriginalPrice(e.target.value)}
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl font-mono"
              />
            </div>
            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Default License
              </label>
              <select
                value={license}
                onChange={(e) => setLicense(e.target.value as LicenseType)}
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl cursor-pointer"
              >
                <option value="commercial">Commercial</option>
                <option value="personal">Personal</option>
                <option value="extended">Extended</option>
              </select>
            </div>
          </div>

          {/* Master File Upload Simulator */}
          <div>
            <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
              Master Digital Deliverable (ZIP, PDF, WAV, MP4, BLEND)
            </label>
            <div className="border-2 border-dashed border-neutral-300 dark:border-neutral-700 rounded-2xl p-6 text-center hover:border-neutral-500 transition-colors">
              <input
                type="file"
                id="digital-file-input"
                onChange={handleFileDrop}
                className="hidden"
              />
              <label
                htmlFor="digital-file-input"
                className="cursor-pointer flex flex-col items-center justify-center"
              >
                {simulatedFile ? (
                  <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-medium">
                    <FileCheck className="w-6 h-6" />
                    <span>{simulatedFile.name} ({(simulatedFile.size / (1024 * 1024)).toFixed(2)} MB)</span>
                  </div>
                ) : (
                  <>
                    <Upload className="w-8 h-8 text-neutral-400 mb-2" />
                    <p className="font-semibold text-neutral-900 dark:text-white">
                      Click to browse or drag & drop files here
                    </p>
                    <p className="text-[11px] text-neutral-500 mt-1">
                      Max file size: 5GB · Encrypted storage applied automatically
                    </p>
                  </>
                )}
              </label>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                Format Label
              </label>
              <input
                type="text"
                value={fileFormat}
                onChange={(e) => setFileFormat(e.target.value)}
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
                File Size
              </label>
              <input
                type="text"
                value={fileSize}
                onChange={(e) => setFileSize(e.target.value)}
                className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
              Detailed Description
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe what customers will be able to build or achieve with these files..."
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl"
            />
          </div>

          <div>
            <label className="block font-medium mb-1 text-neutral-700 dark:text-neutral-300">
              Key Features (Comma-separated)
            </label>
            <input
              type="text"
              value={features}
              onChange={(e) => setFeatures(e.target.value)}
              className="w-full px-3 py-2 bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl"
            />
          </div>

          {/* Upload Progress Bar */}
          {isUploading && (
            <div className="pt-2">
              <div className="flex justify-between text-[11px] text-neutral-500 mb-1">
                <span>Encrypting and uploading deliverable to secure storage...</span>
                <span>{uploadProgress}%</span>
              </div>
              <div className="w-full bg-neutral-100 dark:bg-neutral-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-500 h-full transition-all duration-200"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Submit Actions */}
          <div className="pt-4 border-t border-neutral-100 dark:border-neutral-800 flex gap-3">
            <button
              type="button"
              onClick={() => setIsUploadModalOpen(false)}
              className="flex-1 py-2.5 bg-neutral-100 dark:bg-neutral-800 rounded-xl font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isUploading || !title.trim()}
              className="flex-1 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 rounded-xl font-bold transition-all disabled:opacity-50 cursor-pointer"
            >
              {isUploading ? 'Uploading...' : 'Publish to Marketplace'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
