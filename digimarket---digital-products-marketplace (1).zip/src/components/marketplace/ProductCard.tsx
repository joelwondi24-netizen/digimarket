import React from 'react';
import { Product } from '../../types';
import { useApp } from '../../context/AppContext';
import { Heart, ShoppingBag, Star, Download, Eye, Play, BookOpen } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onQuickView?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView }) => {
  const { navigate, addToCart, toggleWishlist, isInWishlist } = useApp();
  const wishlisted = isInWishlist(product.id);

  return (
    <article className="group relative flex flex-col bg-white dark:bg-neutral-900 rounded-xl overflow-hidden border border-neutral-200/80 dark:border-neutral-800 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
      {/* Thumbnail Container */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-neutral-100 dark:bg-neutral-800">
        <img
          src={product.thumbnail}
          alt={product.title}
          referrerPolicy="no-referrer"
          className="h-full w-full object-cover object-center transition-transform duration-300 group-hover:scale-102"
        />

        {/* Subtle Text Tag (Max 1 subtle tag, never badge sandwich) */}
        {product.isBestseller && (
          <span className="absolute top-2.5 left-2.5 bg-neutral-900/90 text-white text-[11px] font-medium px-2 py-0.5 rounded tracking-wide backdrop-blur-xs">
            Bestseller
          </span>
        )}
        {!product.isBestseller && product.isNew && (
          <span className="absolute top-2.5 left-2.5 bg-amber-500/90 text-neutral-950 text-[11px] font-semibold px-2 py-0.5 rounded tracking-wide backdrop-blur-xs">
            New Release
          </span>
        )}

        {/* Wishlist Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          className="absolute top-2.5 right-2.5 p-2 rounded-full bg-white/90 dark:bg-neutral-900/90 backdrop-blur-sm text-neutral-700 dark:text-neutral-200 hover:text-rose-600 transition-colors shadow-xs cursor-pointer"
          aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
        >
          <Heart
            className={`w-4 h-4 ${
              wishlisted ? 'fill-rose-500 text-rose-500' : 'stroke-[1.75]'
            }`}
          />
        </button>

        {/* Quick View Button on Hover */}
        {onQuickView && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onQuickView(product);
            }}
            className="absolute bottom-2.5 right-2.5 opacity-0 group-hover:opacity-100 transition-opacity bg-neutral-900/80 hover:bg-neutral-950 text-white p-2 rounded-lg text-xs font-medium backdrop-blur-xs flex items-center gap-1.5 cursor-pointer shadow-xs"
            aria-label="Quick preview"
          >
            {product.category === 'Music' || product.category === 'Audio' ? (
              <>
                <Play className="w-3.5 h-3.5 fill-current text-amber-400" />
                <span className="text-[11px]">Audio</span>
              </>
            ) : product.category === 'eBooks' ? (
              <>
                <BookOpen className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-[11px]">Read</span>
              </>
            ) : (
              <>
                <Eye className="w-3.5 h-3.5" />
                <span className="text-[11px]">Preview</span>
              </>
            )}
          </button>
        )}
      </div>

      {/* Card Content Area */}
      <div className="flex flex-col flex-1 p-4">
        {/* Unboxed Metadata Line (Zero-pill discipline) */}
        <div className="flex items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400 mb-1.5">
          <span className="font-medium text-neutral-700 dark:text-neutral-300">
            {product.category}
          </span>
          <span aria-hidden="true">·</span>
          <span>{product.fileFormat.split('+')[0].trim()}</span>
          <span aria-hidden="true">·</span>
          <span>{product.fileSize}</span>
        </div>

        {/* Product Title */}
        <h3
          onClick={() => navigate('product-details', { productId: product.id })}
          className="text-sm font-semibold text-neutral-950 dark:text-white line-clamp-1 hover:text-neutral-600 dark:hover:text-neutral-300 cursor-pointer transition-colors"
          title={product.title}
        >
          {product.title}
        </h3>

        {/* Creator Name */}
        <button
          onClick={() => navigate('seller-storefront', { sellerId: product.sellerId })}
          className="text-xs text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200 mt-1 text-left truncate transition-colors cursor-pointer"
        >
          By {product.sellerName}
        </button>

        {/* Ratings & Downloads */}
        <div className="flex items-center gap-1.5 mt-2 text-xs">
          <div className="flex items-center text-amber-500">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span className="ml-1 font-semibold text-neutral-900 dark:text-neutral-100 tabular-nums">
              {product.rating.toFixed(1)}
            </span>
          </div>
          <span className="text-neutral-400">({product.reviewCount})</span>
          <span aria-hidden="true" className="text-neutral-300 dark:text-neutral-700">·</span>
          <span className="text-neutral-500 dark:text-neutral-400 flex items-center gap-0.5 text-[11px]">
            <Download className="w-3 h-3 opacity-60" /> {product.downloadCount}
          </span>
        </div>

        {/* Price & Action Module */}
        <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-neutral-800/80 flex items-center justify-between gap-2">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-base font-bold text-neutral-950 dark:text-white tabular-nums">
                ${product.price.toFixed(2)}
              </span>
              {product.originalPrice && (
                <span className="text-xs text-neutral-400 line-through tabular-nums">
                  ${product.originalPrice.toFixed(2)}
                </span>
              )}
            </div>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
              Verified Download
            </span>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => addToCart(product)}
              className="p-2 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-lg transition-colors cursor-pointer"
              title="Add to cart"
              aria-label="Add to cart"
            >
              <ShoppingBag className="w-4 h-4" />
            </button>
            <button
              onClick={() => navigate('product-details', { productId: product.id })}
              className="px-2.5 py-1.5 text-xs font-semibold bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-900 dark:hover:bg-neutral-100 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              View
            </button>
          </div>
        </div>
      </div>
    </article>
  );
};
