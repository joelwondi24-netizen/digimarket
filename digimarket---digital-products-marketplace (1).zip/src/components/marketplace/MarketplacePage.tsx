import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductCard } from './ProductCard';
import { ProductCategory, Product } from '../../types';
import {
  SlidersHorizontal,
  Search,
  X,
  ArrowUpDown,
  LayoutGrid,
  List,
  Sparkles,
  Filter,
} from 'lucide-react';
import { CATEGORIES_CONFIG } from '../../data/mockData';
import { AudioPreviewModal } from '../product/AudioPreviewModal';
import { EbookPreviewModal } from '../product/EbookPreviewModal';
import { ImagePreviewModal } from '../product/ImagePreviewModal';

type SortOption = 'popular' | 'newest' | 'price-asc' | 'price-desc' | 'rating';

export const MarketplacePage: React.FC = () => {
  const {
    products,
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
    navigate,
  } = useApp();

  // Filters state
  const [selectedFormat, setSelectedFormat] = useState<string>('All');
  const [priceRange, setPriceRange] = useState<string>('all');
  const [minRating, setMinRating] = useState<number>(0);
  const [sortBy, setSortBy] = useState<SortOption>('popular');
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Preview Modal state
  const [previewProduct, setPreviewProduct] = useState<Product | null>(null);

  const fileFormats = ['All', 'PDF', 'WAV', 'MP3', 'BLEND', 'FIG', 'TIFF', 'MOGRT', 'XMP', 'ZIP'];

  const filteredProducts = useMemo(() => {
    return products
      .filter((product) => {
        // Status check
        if (product.status !== 'published') return false;

        // Category filter
        if (selectedCategory !== 'All' && product.category !== selectedCategory) {
          return false;
        }

        // Search Query (title, tags, creator, description)
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = product.title.toLowerCase().includes(q);
          const matchSeller = product.sellerName.toLowerCase().includes(q);
          const matchCategory = product.category.toLowerCase().includes(q);
          const matchTags = product.tags.some((t) => t.toLowerCase().includes(q));
          if (!matchTitle && !matchSeller && !matchCategory && !matchTags) {
            return false;
          }
        }

        // Format filter
        if (selectedFormat !== 'All') {
          if (!product.fileFormat.toUpperCase().includes(selectedFormat.toUpperCase())) {
            return false;
          }
        }

        // Price Range filter
        if (priceRange === 'under-20' && product.price >= 20) return false;
        if (priceRange === '20-35' && (product.price < 20 || product.price > 35)) return false;
        if (priceRange === 'above-35' && product.price <= 35) return false;

        // Rating filter
        if (minRating > 0 && product.rating < minRating) return false;

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'popular') return b.salesCount - a.salesCount;
        if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        if (sortBy === 'price-asc') return a.price - b.price;
        if (sortBy === 'price-desc') return b.price - a.price;
        if (sortBy === 'rating') return b.rating - a.rating;
        return 0;
      });
  }, [products, selectedCategory, searchQuery, selectedFormat, priceRange, minRating, sortBy]);

  const resetFilters = () => {
    setSelectedCategory('All');
    setSearchQuery('');
    setSelectedFormat('All');
    setPriceRange('all');
    setMinRating(0);
    setSortBy('popular');
  };

  const hasActiveFilters =
    selectedCategory !== 'All' ||
    searchQuery.trim() !== '' ||
    selectedFormat !== 'All' ||
    priceRange !== 'all' ||
    minRating > 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header bar */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-neutral-200 dark:border-neutral-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold font-display text-neutral-950 dark:text-white">
            Digital Asset Marketplace
          </h1>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            Browse verified digital deliverables: eBooks, audio stems, 4K templates, 3D meshes, and UI tools.
          </p>
        </div>

        {/* Sorting & Layout toggles */}
        <div className="flex items-center gap-3">
          {/* Mobile Filter toggle button */}
          <button
            onClick={() => setIsMobileFilterOpen((o) => !o)}
            className="md:hidden flex items-center gap-1.5 px-3 py-1.5 bg-neutral-100 dark:bg-neutral-800 rounded-lg text-xs font-medium text-neutral-700 dark:text-neutral-300 cursor-pointer"
          >
            <Filter className="w-3.5 h-3.5" /> Filters
          </button>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-neutral-500 hidden sm:inline">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="text-xs py-1.5 px-3 bg-neutral-100 dark:bg-neutral-800 border-none rounded-lg text-neutral-800 dark:text-neutral-200 focus:outline-none focus:ring-1 focus:ring-neutral-400 cursor-pointer"
            >
              <option value="popular">Most Popular</option>
              <option value="newest">New Releases</option>
              <option value="rating">Highest Rated</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
          </div>

          {/* View mode toggle */}
          <div className="hidden sm:flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 p-1 rounded-lg">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1 rounded cursor-pointer ${
                viewMode === 'grid'
                  ? 'bg-white dark:bg-neutral-900 shadow-xs text-neutral-950 dark:text-white'
                  : 'text-neutral-500'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1 rounded cursor-pointer ${
                viewMode === 'list'
                  ? 'bg-white dark:bg-neutral-900 shadow-xs text-neutral-950 dark:text-white'
                  : 'text-neutral-500'
              }`}
              title="List View"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Layout Grid (Sidebar Filters + Products Grid) */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pt-8">
        {/* Sidebar Filters */}
        <aside
          className={`md:block ${
            isMobileFilterOpen ? 'block fixed inset-0 z-50 bg-white dark:bg-neutral-900 p-6 overflow-y-auto' : 'hidden'
          } md:relative md:p-0 md:bg-transparent`}
        >
          <div className="space-y-6">
            {/* Mobile Header with Close button */}
            <div className="flex md:hidden items-center justify-between pb-4 border-b border-neutral-200 dark:border-neutral-800">
              <h3 className="font-bold text-sm">Filters</h3>
              <button
                onClick={() => setIsMobileFilterOpen(false)}
                className="p-1 text-neutral-500 hover:text-neutral-900 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Filter Reset Button */}
            {hasActiveFilters && (
              <button
                onClick={resetFilters}
                className="w-full text-xs font-medium text-amber-600 dark:text-amber-400 hover:underline flex items-center justify-center gap-1 py-1.5 bg-amber-50 dark:bg-amber-950/40 rounded-lg cursor-pointer"
              >
                <X className="w-3.5 h-3.5" /> Clear All Filters
              </button>
            )}

            {/* Categories Segmented List */}
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-900 dark:text-white mb-3">
                Category
              </h3>
              <div className="space-y-1">
                <button
                  onClick={() => setSelectedCategory('All')}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-colors flex items-center justify-between cursor-pointer ${
                    selectedCategory === 'All'
                      ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 font-semibold'
                      : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                  }`}
                >
                  <span>All Categories</span>
                  <span className="text-[10px] opacity-75">{products.length}</span>
                </button>
                {CATEGORIES_CONFIG.slice(0, 10).map((cat) => {
                  const count = products.filter((p) => p.category === cat.name).length;
                  return (
                    <button
                      key={cat.name}
                      onClick={() => setSelectedCategory(cat.name)}
                      className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-colors flex items-center justify-between cursor-pointer ${
                        selectedCategory === cat.name
                          ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 font-semibold'
                          : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                      }`}
                    >
                      <span>{cat.name}</span>
                      <span className="text-[10px] opacity-75">{count}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* File Format Filter */}
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-900 dark:text-white mb-3">
                File Format
              </h3>
              <div className="flex flex-wrap gap-1.5">
                {fileFormats.map((fmt) => (
                  <button
                    key={fmt}
                    onClick={() => setSelectedFormat(fmt)}
                    className={`px-2.5 py-1 text-xs rounded-lg transition-colors cursor-pointer ${
                      selectedFormat === fmt
                        ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 font-semibold'
                        : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-200'
                    }`}
                  >
                    {fmt}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Filter */}
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-900 dark:text-white mb-3">
                Price Budget
              </h3>
              <div className="space-y-1 text-xs">
                {[
                  { id: 'all', label: 'All Prices' },
                  { id: 'under-20', label: 'Under $20' },
                  { id: '20-35', label: '$20 to $35' },
                  { id: 'above-35', label: 'Above $35' },
                ].map((item) => (
                  <label
                    key={item.id}
                    className="flex items-center gap-2 py-1 text-neutral-600 dark:text-neutral-300 cursor-pointer"
                  >
                    <input
                      type="radio"
                      name="priceRange"
                      checked={priceRange === item.id}
                      onChange={() => setPriceRange(item.id)}
                      className="accent-neutral-900 dark:accent-white"
                    />
                    <span>{item.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Minimum Rating */}
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-900 dark:text-white mb-2">
                Minimum Rating
              </h3>
              <div className="flex gap-1.5">
                {[0, 4.5, 4.8, 4.9].map((rating) => (
                  <button
                    key={rating}
                    onClick={() => setMinRating(rating)}
                    className={`px-2.5 py-1 text-xs rounded-lg transition-colors cursor-pointer ${
                      minRating === rating
                        ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 font-semibold'
                        : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-200'
                    }`}
                  >
                    {rating === 0 ? 'Any' : `${rating}+ ★`}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </aside>

        {/* Product Grid Area */}
        <div className="md:col-span-3">
          {/* Active Filter Pills Bar */}
          <div className="flex items-center justify-between text-xs text-neutral-500 mb-4">
            <div>
              Showing <span className="font-bold text-neutral-900 dark:text-white">{filteredProducts.length}</span> digital products
            </div>
            {hasActiveFilters && (
              <button
                onClick={resetFilters}
                className="text-neutral-500 hover:text-neutral-900 dark:hover:text-white underline cursor-pointer"
              >
                Reset filters
              </button>
            )}
          </div>

          {/* Empty State */}
          {filteredProducts.length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800">
              <Sparkles className="w-8 h-8 text-neutral-400 mx-auto mb-3" />
              <h3 className="text-base font-bold text-neutral-900 dark:text-white">
                No matching digital products found
              </h3>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto mt-1 mb-6">
                Try searching for broader keywords, adjusting file formats, or resetting your category filters.
              </p>
              <button
                onClick={resetFilters}
                className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-neutral-950 rounded-xl text-xs font-semibold cursor-pointer"
              >
                View All Products
              </button>
            </div>
          ) : viewMode === 'grid' ? (
            /* Responsive 3-col Grid */
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((prod) => (
                <ProductCard
                  key={prod.id}
                  product={prod}
                  onQuickView={(p) => setPreviewProduct(p)}
                />
              ))}
            </div>
          ) : (
            /* List View */
            <div className="space-y-4">
              {filteredProducts.map((prod) => (
                <div
                  key={prod.id}
                  className="flex flex-col sm:flex-row items-center gap-4 p-4 bg-white dark:bg-neutral-900 rounded-xl border border-neutral-200/80 dark:border-neutral-800 hover:shadow-md transition-all"
                >
                  <img
                    src={prod.thumbnail}
                    alt={prod.title}
                    referrerPolicy="no-referrer"
                    className="w-full sm:w-40 aspect-[4/3] object-cover rounded-lg bg-neutral-100 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="text-xs text-neutral-500 dark:text-neutral-400 mb-1">
                      {prod.category} · {prod.fileFormat} · {prod.fileSize}
                    </div>
                    <h3
                      onClick={() => navigate('product-details', { productId: prod.id })}
                      className="text-base font-bold text-neutral-900 dark:text-white hover:underline cursor-pointer"
                    >
                      {prod.title}
                    </h3>
                    <p className="text-xs text-neutral-500 dark:text-neutral-400 line-clamp-2 mt-1">
                      {prod.tagline}
                    </p>
                    <div className="text-xs text-neutral-400 mt-2">By {prod.sellerName}</div>
                  </div>
                  <div className="flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto gap-3 pt-2 sm:pt-0 border-t sm:border-0 border-neutral-100 dark:border-neutral-800">
                    <div className="text-right">
                      <div className="text-lg font-bold text-neutral-900 dark:text-white tabular-nums">
                        ${prod.price.toFixed(2)}
                      </div>
                      <div className="text-[10px] text-emerald-600 font-medium">Instant Verified Download</div>
                    </div>
                    <button
                      onClick={() => navigate('product-details', { productId: prod.id })}
                      className="px-3 py-1.5 bg-neutral-900 text-white dark:bg-white dark:text-neutral-950 rounded-lg text-xs font-semibold cursor-pointer"
                    >
                      View Product
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Quick Preview Modals */}
      {previewProduct && (previewProduct.category === 'Music' || previewProduct.category === 'Audio') && (
        <AudioPreviewModal product={previewProduct} onClose={() => setPreviewProduct(null)} />
      )}
      {previewProduct && previewProduct.category === 'eBooks' && (
        <EbookPreviewModal product={previewProduct} onClose={() => setPreviewProduct(null)} />
      )}
      {previewProduct && previewProduct.category !== 'Music' && previewProduct.category !== 'Audio' && previewProduct.category !== 'eBooks' && (
        <ImagePreviewModal product={previewProduct} onClose={() => setPreviewProduct(null)} />
      )}
    </div>
  );
};
