import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  ProductCategory,
  Seller,
  User,
  CartItem,
  Order,
  DownloadToken,
  Coupon,
  ProductReview,
  ActivePage,
  LicenseType,
  AdminStaff,
  AdminAuditLog,
} from '../types';
import {
  INITIAL_PRODUCTS,
  INITIAL_SELLERS,
  INITIAL_COUPONS,
  INITIAL_REVIEWS,
  INITIAL_ADMINS,
  INITIAL_AUDIT_LOGS,
} from '../data/mockData';
import { triggerSecureDownload } from '../utils/downloadGenerator';

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info';
  title: string;
  message?: string;
}

interface AppContextType {
  products: Product[];
  sellers: Seller[];
  currentUser: User | null;
  adminStaffList: AdminStaff[];
  currentAdminStaff: AdminStaff | null;
  adminAuditLogs: AdminAuditLog[];
  cart: CartItem[];
  wishlist: string[];
  orders: Order[];
  downloadTokens: DownloadToken[];
  coupons: Coupon[];
  reviews: ProductReview[];
  commissionRate: number; // e.g. 20 (meaning 20%)
  activePage: ActivePage;
  selectedProduct: Product | null;
  selectedSeller: Seller | null;
  searchQuery: string;
  selectedCategory: ProductCategory | 'All';
  isCartOpen: boolean;
  isAuthModalOpen: boolean;
  isUploadModalOpen: boolean;
  isBecomeSellerModalOpen: boolean;
  isAdminUploadModalOpen: boolean;
  isAdminRegisterModalOpen: boolean;
  darkMode: boolean;
  toasts: Toast[];

  // Navigation
  navigate: (
    page: ActivePage,
    options?: { productId?: string; sellerId?: string; category?: ProductCategory | 'All' }
  ) => void;
  setSearchQuery: (query: string) => void;
  setSelectedCategory: (category: ProductCategory | 'All') => void;

  // Cart & Commerce
  addToCart: (product: Product, license?: LicenseType) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;

  // Modals & Theme
  setIsCartOpen: (open: boolean) => void;
  setIsAuthModalOpen: (open: boolean) => void;
  setIsUploadModalOpen: (open: boolean) => void;
  setIsBecomeSellerModalOpen: (open: boolean) => void;
  setIsAdminUploadModalOpen: (open: boolean) => void;
  setIsAdminRegisterModalOpen: (open: boolean) => void;
  toggleDarkMode: () => void;
  showToast: (type: 'success' | 'error' | 'info', title: string, message?: string) => void;
  removeToast: (id: string) => void;

  // Auth & Roles
  loginAs: (role: 'customer' | 'seller' | 'admin', adminId?: string) => void;
  logout: () => void;
  becomeSeller: (data: {
    storeName: string;
    bio: string;
    country: string;
    payoutMethod: Seller['payoutMethod'];
    payoutAccount: string;
  }) => void;

  // Checkout & Verified Downloads
  applyCoupon: (
    code: string,
    subtotal: number
  ) => { success: boolean; message: string; discount: number; coupon?: Coupon };
  completeCheckout: (
    customerName: string,
    customerEmail: string,
    paymentMethod: 'stripe' | 'paypal' | 'apple_pay',
    appliedCoupon?: Coupon
  ) => Order;
  downloadProduct: (token: DownloadToken) => void;
  verifyOrderDownloadLookup: (
    orderNumber: string,
    customerEmail: string
  ) => { success: boolean; message: string; tokens?: DownloadToken[]; order?: Order };

  // Reviews
  addReview: (productId: string, rating: number, comment: string) => void;

  // Seller Actions
  uploadProduct: (data: Partial<Product>) => void;
  requestSellerPayout: (sellerId: string) => void;

  // Admin Actions & Product Post Section
  adminUploadProduct: (data: Partial<Product>) => Product;
  registerAdminStaff: (data: Omit<AdminStaff, 'id' | 'joinedDate'>) => AdminStaff;
  updateAdminStaffStatus: (staffId: string, status: 'active' | 'suspended') => void;
  switchAdminStaff: (staffId: string) => void;
  approveProduct: (productId: string) => void;
  rejectProduct: (productId: string) => void;
  deleteProduct: (productId: string) => void;
  setCommissionRate: (rate: number) => void;
  addCoupon: (coupon: Coupon) => void;
  toggleCouponStatus: (code: string) => void;
  refundOrder: (orderId: string, reason: string) => void;
  renewDownloadToken: (tokenId: string) => void;
  moderateReview: (reviewId: string, status: 'approved' | 'rejected') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const DEFAULT_BUYER: User = {
  id: 'user-buyer-1',
  name: 'Alex Rivera',
  email: 'alex.rivera@example.com',
  avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
  role: 'customer',
  joinedDate: '2025-01-15',
  wishlist: ['prod-1', 'prod-3'],
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Products & Sellers
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('digimarket_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [sellers, setSellers] = useState<Seller[]>(() => {
    const saved = localStorage.getItem('digimarket_sellers');
    return saved ? JSON.parse(saved) : INITIAL_SELLERS;
  });

  // Admin Staff & Audit Logs
  const [adminStaffList, setAdminStaffList] = useState<AdminStaff[]>(() => {
    const saved = localStorage.getItem('digimarket_admins');
    return saved ? JSON.parse(saved) : INITIAL_ADMINS;
  });

  const [currentAdminStaff, setCurrentAdminStaff] = useState<AdminStaff | null>(() => {
    const saved = localStorage.getItem('digimarket_current_admin');
    return saved ? JSON.parse(saved) : INITIAL_ADMINS[0];
  });

  const [adminAuditLogs, setAdminAuditLogs] = useState<AdminAuditLog[]>(() => {
    const saved = localStorage.getItem('digimarket_audit_logs');
    return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
  });

  // Current User
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('digimarket_user');
    return saved ? JSON.parse(saved) : DEFAULT_BUYER;
  });

  // Cart & Wishlist
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('digimarket_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    const saved = localStorage.getItem('digimarket_wishlist');
    return saved ? JSON.parse(saved) : ['prod-1', 'prod-3'];
  });

  // Orders & Downloads
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('digimarket_orders');
    return saved ? JSON.parse(saved) : [];
  });

  const [downloadTokens, setDownloadTokens] = useState<DownloadToken[]>(() => {
    const saved = localStorage.getItem('digimarket_downloads');
    return saved ? JSON.parse(saved) : [];
  });

  // Reviews & Coupons & Platform settings
  const [reviews, setReviews] = useState<ProductReview[]>(() => {
    const saved = localStorage.getItem('digimarket_reviews');
    return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
  });

  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    const saved = localStorage.getItem('digimarket_coupons');
    return saved ? JSON.parse(saved) : INITIAL_COUPONS;
  });

  const [commissionRate, setCommissionRateState] = useState<number>(20); // 20% standard

  // Navigation & UI
  const [activePage, setActivePage] = useState<ActivePage>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(INITIAL_PRODUCTS[0]);
  const [selectedSeller, setSelectedSeller] = useState<Seller | null>(INITIAL_SELLERS[0]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory | 'All'>('All');

  // Modals & Drawers
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isBecomeSellerModalOpen, setIsBecomeSellerModalOpen] = useState(false);
  const [isAdminUploadModalOpen, setIsAdminUploadModalOpen] = useState(false);
  const [isAdminRegisterModalOpen, setIsAdminRegisterModalOpen] = useState(false);

  // Dark mode
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('digimarket_theme');
    return saved === 'dark';
  });

  // Toasts
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('digimarket_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('digimarket_sellers', JSON.stringify(sellers));
  }, [sellers]);

  useEffect(() => {
    localStorage.setItem('digimarket_admins', JSON.stringify(adminStaffList));
  }, [adminStaffList]);

  useEffect(() => {
    if (currentAdminStaff) {
      localStorage.setItem('digimarket_current_admin', JSON.stringify(currentAdminStaff));
    }
  }, [currentAdminStaff]);

  useEffect(() => {
    localStorage.setItem('digimarket_audit_logs', JSON.stringify(adminAuditLogs));
  }, [adminAuditLogs]);

  useEffect(() => {
    localStorage.setItem('digimarket_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('digimarket_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem('digimarket_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('digimarket_downloads', JSON.stringify(downloadTokens));
  }, [downloadTokens]);

  useEffect(() => {
    localStorage.setItem('digimarket_reviews', JSON.stringify(reviews));
  }, [reviews]);

  useEffect(() => {
    localStorage.setItem('digimarket_coupons', JSON.stringify(coupons));
  }, [coupons]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('digimarket_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('digimarket_user');
    }
  }, [currentUser]);

  // Apply dark mode class to html element
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('digimarket_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('digimarket_theme', 'light');
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode((prev) => !prev);
  };

  const showToast = (type: 'success' | 'error' | 'info', title: string, message?: string) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    setToasts((prev) => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const logAdminAction = (action: string, details: string, targetId?: string) => {
    const newLog: AdminAuditLog = {
      id: `log-${Date.now()}`,
      adminId: currentAdminStaff?.id || 'admin-system',
      adminName: currentAdminStaff?.name || 'Administrator',
      action,
      details,
      targetId,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' UTC',
      ipAddress: '127.0.0.1 (Verified TLS Session)',
    };
    setAdminAuditLogs((prev) => [newLog, ...prev]);
  };

  const navigate = (
    page: ActivePage,
    options?: { productId?: string; sellerId?: string; category?: ProductCategory | 'All' }
  ) => {
    if (options?.productId) {
      const found = products.find((p) => p.id === options.productId);
      if (found) setSelectedProduct(found);
    }
    if (options?.sellerId) {
      const found = sellers.find((s) => s.id === options.sellerId);
      if (found) setSelectedSeller(found);
    }
    if (options?.category) {
      setSelectedCategory(options.category);
    }
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const addToCart = (product: Product, license: LicenseType = 'commercial') => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        showToast('info', 'Already in Cart', `${product.title} is already in your basket.`);
        return prev;
      }
      showToast('success', 'Added to Cart', `${product.title} added to your basket.`);
      return [...prev, { product, license, price: product.price }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
    showToast('info', 'Removed', 'Item removed from your cart.');
  };

  const clearCart = () => {
    setCart([]);
  };

  const toggleWishlist = (productId: string) => {
    setWishlist((prev) => {
      if (prev.includes(productId)) {
        showToast('info', 'Removed from Wishlist');
        return prev.filter((id) => id !== productId);
      } else {
        showToast('success', 'Saved to Wishlist');
        return [...prev, productId];
      }
    });
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  const loginAs = (role: 'customer' | 'seller' | 'admin', adminId?: string) => {
    if (role === 'customer') {
      setCurrentUser(DEFAULT_BUYER);
      showToast('success', 'Signed In', 'Logged in as Customer (Alex Rivera)');
    } else if (role === 'seller') {
      setCurrentUser({
        id: 'user-seller-1',
        name: 'Elena Rostova',
        email: 'elena@aethel.studio',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
        role: 'seller',
        sellerId: 'seller-1',
        joinedDate: '2024-03-12',
        wishlist: [],
      });
      showToast('success', 'Seller Mode', 'Logged in as Creator (Elena Rostova - Aethel Studio)');
    } else {
      const staff = (adminId && adminStaffList.find((s) => s.id === adminId)) || currentAdminStaff || adminStaffList[0];
      setCurrentAdminStaff(staff);
      setCurrentUser({
        id: `user-${staff.id}`,
        name: staff.name,
        email: staff.email,
        avatar: staff.avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80',
        role: 'admin',
        adminStaffId: staff.id,
        joinedDate: staff.joinedDate,
        wishlist: [],
      });
      showToast('success', 'Admin Portal', `Logged in as ${staff.name} (${staff.role.replace('_', ' ').toUpperCase()})`);
    }
    setIsAuthModalOpen(false);
  };

  const switchAdminStaff = (staffId: string) => {
    const staff = adminStaffList.find((s) => s.id === staffId);
    if (!staff) return;
    setCurrentAdminStaff(staff);
    if (currentUser?.role === 'admin') {
      setCurrentUser({
        id: `user-${staff.id}`,
        name: staff.name,
        email: staff.email,
        avatar: staff.avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&q=80',
        role: 'admin',
        adminStaffId: staff.id,
        joinedDate: staff.joinedDate,
        wishlist: [],
      });
    }
    logAdminAction('Staff Profile Switched', `Switched active administrative session to ${staff.name} (${staff.role})`);
    showToast('info', 'Active Admin Switched', `Now operating as ${staff.name}`);
  };

  const logout = () => {
    setCurrentUser(null);
    showToast('info', 'Signed Out', 'You have been safely signed out.');
  };

  const becomeSeller = (data: {
    storeName: string;
    bio: string;
    country: string;
    payoutMethod: Seller['payoutMethod'];
    payoutAccount: string;
  }) => {
    const newSellerId = `seller-${Date.now()}`;
    const newSeller: Seller = {
      id: newSellerId,
      userId: currentUser?.id || `user-${Date.now()}`,
      name: currentUser?.name || 'New Creator',
      storeName: data.storeName,
      storeSlug: data.storeName.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      bio: data.bio,
      avatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
      country: data.country,
      rating: 5.0,
      salesCount: 0,
      followersCount: 1,
      grossRevenue: 0,
      netEarnings: 0,
      pendingPayouts: 0,
      payoutMethod: data.payoutMethod,
      payoutAccount: data.payoutAccount,
      isApproved: true,
      joinedDate: new Date().toISOString().split('T')[0],
    };

    setSellers((prev) => [newSeller, ...prev]);
    if (currentUser) {
      setCurrentUser({
        ...currentUser,
        role: 'seller',
        sellerId: newSellerId,
      });
    }
    setIsBecomeSellerModalOpen(false);
    showToast('success', 'Storefront Created!', 'Your creator storefront is now live on DigiMarket.');
    navigate('seller-dashboard', { sellerId: newSellerId });
  };

  const applyCoupon = (code: string, subtotal: number) => {
    const cleanCode = code.trim().toUpperCase();
    const coupon = coupons.find((c) => c.code.toUpperCase() === cleanCode && c.isActive);
    if (!coupon) {
      return { success: false, message: 'Invalid or expired coupon code', discount: 0 };
    }
    if (coupon.minPurchase && subtotal < coupon.minPurchase) {
      return {
        success: false,
        message: `Requires minimum purchase of $${coupon.minPurchase.toFixed(2)}`,
        discount: 0,
      };
    }
    let discount = 0;
    if (coupon.discountPercent) {
      discount = (subtotal * coupon.discountPercent) / 100;
    } else if (coupon.discountAmount) {
      discount = Math.min(coupon.discountAmount, subtotal);
    }
    return {
      success: true,
      message: `${coupon.description}`,
      discount,
      coupon,
    };
  };

  const completeCheckout = (
    customerName: string,
    customerEmail: string,
    paymentMethod: 'stripe' | 'paypal' | 'apple_pay',
    appliedCoupon?: Coupon
  ): Order => {
    const subtotal = cart.reduce((acc, item) => acc + item.price, 0);
    let discountAmount = 0;
    if (appliedCoupon) {
      if (appliedCoupon.discountPercent) {
        discountAmount = (subtotal * appliedCoupon.discountPercent) / 100;
      } else if (appliedCoupon.discountAmount) {
        discountAmount = Math.min(appliedCoupon.discountAmount, subtotal);
      }
    }
    const platformFee = 0; // Digital delivery: zero physical transit fees
    const total = Math.max(0, subtotal - discountAmount);

    const orderId = `ord-${Date.now()}`;
    const orderNumber = `DG-${Math.floor(100000 + Math.random() * 900000)}`;
    const now = new Date();
    const expiry = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // 30-day verified access window

    // Generate cryptographic verification details
    const txnHash = `0x${Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;
    const authCode = `AUTH_${paymentMethod.toUpperCase()}_${Math.floor(10000000 + Math.random() * 90000000)}`;

    // Generate verified download tokens with payment verification hash
    const createdTokens: DownloadToken[] = cart.map((item) => {
      const randomSecret = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
      const tokenString = `dg_dl_${randomSecret}`;
      const verificationHash = `sha256_${Array.from({ length: 24 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;

      return {
        id: `tok-${Date.now()}-${item.product.id}`,
        orderId,
        orderNumber,
        productId: item.product.id,
        productTitle: item.product.title,
        fileFormat: item.product.fileFormat,
        fileSize: item.product.fileSize,
        token: tokenString,
        createdAt: now.toISOString(),
        expiresAt: expiry.toISOString(),
        maxDownloads: 5,
        downloadsRemaining: 5,
        downloadHistory: [],
        isRevoked: false,
        paymentVerificationStatus: 'verified',
        verificationHash,
        paymentGateway: paymentMethod,
      };
    });

    const newOrder: Order = {
      id: orderId,
      orderNumber,
      customerId: currentUser?.id || 'guest-customer',
      customerName,
      customerEmail,
      items: cart.map((c) => ({
        productId: c.product.id,
        productTitle: c.product.title,
        productThumbnail: c.product.thumbnail,
        category: c.product.category,
        sellerId: c.product.sellerId,
        sellerName: c.product.sellerName,
        license: c.license,
        price: c.price,
        fileFormat: c.product.fileFormat,
      })),
      subtotal,
      discountAmount,
      couponCode: appliedCoupon?.code,
      platformFee,
      total,
      paymentMethod,
      paymentStatus: 'paid',
      paymentVerificationDetails: {
        verified: true,
        authCode,
        verifiedAt: now.toISOString(),
        transactionHash: txnHash,
        securityStandard: 'PCI-DSS Level 1 / TLS 256-bit',
      },
      downloadTokens: createdTokens,
      createdAt: now.toISOString(),
    };

    // Update seller revenue & sales count
    const sellerEarningsMultiplier = (100 - commissionRate) / 100;
    cart.forEach((item) => {
      const sellerId = item.product.sellerId;
      const itemRev = item.price;
      const sellerNet = itemRev * sellerEarningsMultiplier;

      setSellers((prev) =>
        prev.map((s) => {
          if (s.id === sellerId) {
            return {
              ...s,
              salesCount: s.salesCount + 1,
              grossRevenue: s.grossRevenue + itemRev,
              netEarnings: s.netEarnings + sellerNet,
              pendingPayouts: s.pendingPayouts + sellerNet,
            };
          }
          return s;
        })
      );

      // Increment product sales count
      setProducts((prev) =>
        prev.map((p) => {
          if (p.id === item.product.id) {
            return {
              ...p,
              salesCount: p.salesCount + 1,
            };
          }
          return p;
        })
      );
    });

    setOrders((prev) => [newOrder, ...prev]);
    setDownloadTokens((prev) => [...createdTokens, ...prev]);
    clearCart();

    logAdminAction('Order Completed & Verified', `Order ${orderNumber} verified ($${total.toFixed(2)}) via ${paymentMethod}. Issued ${createdTokens.length} cryptographic download tokens.`, orderId);

    showToast(
      'success',
      'Payment Verified & Cleared!',
      `Order ${orderNumber} authenticated. Download tokens issued immediately.`
    );
    return newOrder;
  };

  const downloadProduct = (token: DownloadToken) => {
    if (token.isRevoked) {
      showToast('error', 'Download Revoked', 'This download access was revoked due to a refund or policy restriction.');
      return;
    }
    if (token.paymentVerificationStatus !== 'verified') {
      showToast('error', 'Payment Unverified', 'Payment verification is still pending clearance.');
      return;
    }
    if (token.downloadsRemaining <= 0) {
      showToast('error', 'Limit Reached', 'You have used all 5 verified download attempts for this token. You can request a renewal from support.');
      return;
    }

    const targetProduct = products.find((p) => p.id === token.productId);

    // Trigger instant secure download package
    triggerSecureDownload(token, targetProduct);

    // Decrement downloads remaining & record audit
    setDownloadTokens((prev) =>
      prev.map((t) => {
        if (t.id === token.id) {
          return {
            ...t,
            downloadsRemaining: Math.max(0, t.downloadsRemaining - 1),
            downloadHistory: [
              ...t.downloadHistory,
              {
                timestamp: new Date().toISOString(),
                ip: '127.0.0.1 (Client Node)',
                userAgent: navigator.userAgent.substring(0, 40),
              },
            ],
          };
        }
        return t;
      })
    );

    // Increment product download counter
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === token.productId) {
          return { ...p, downloadCount: p.downloadCount + 1 };
        }
        return p;
      })
    );

    showToast('success', 'Secure Download Started', `Cryptographic license deliverable generated for ${token.productTitle}`);
  };

  const verifyOrderDownloadLookup = (orderNumber: string, customerEmail: string) => {
    const cleanNum = orderNumber.trim().toUpperCase();
    const cleanMail = customerEmail.trim().toLowerCase();

    const order = orders.find(
      (o) =>
        (o.orderNumber.toUpperCase() === cleanNum || o.id.toUpperCase() === cleanNum) &&
        o.customerEmail.toLowerCase() === cleanMail
    );

    if (!order) {
      return {
        success: false,
        message: 'No verified order found matching that reference number and email combination.',
      };
    }

    if (order.paymentStatus !== 'paid') {
      return {
        success: false,
        message: `Order status is currently ${order.paymentStatus}. Downloads require verified paid status.`,
      };
    }

    const tokens = downloadTokens.filter((t) => t.orderId === order.id && !t.isRevoked);

    return {
      success: true,
      message: `Verified payment for ${order.customerName}. ${tokens.length} digital packages authenticated.`,
      tokens,
      order,
    };
  };

  const addReview = (productId: string, rating: number, comment: string) => {
    const newReview: ProductReview = {
      id: `rev-${Date.now()}`,
      productId,
      userId: currentUser?.id || 'guest',
      userName: currentUser?.name || 'Verified Buyer',
      userAvatar: currentUser?.avatar,
      rating,
      comment,
      date: new Date().toISOString().split('T')[0],
      verifiedPurchase: true,
      status: 'approved',
    };

    setReviews((prev) => [newReview, ...prev]);

    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          const prodReviews = reviews.filter((r) => r.productId === productId).concat(newReview);
          const avg = prodReviews.reduce((sum, r) => sum + r.rating, 0) / prodReviews.length;
          return {
            ...p,
            rating: Number(avg.toFixed(2)),
            reviewCount: prodReviews.length,
          };
        }
        return p;
      })
    );
    showToast('success', 'Review Submitted', 'Thank you for your verified feedback!');
  };

  const uploadProduct = (data: Partial<Product>) => {
    const newId = `prod-${Date.now()}`;
    const newProduct: Product = {
      id: newId,
      title: data.title || 'Untitled Digital Product',
      slug: (data.title || 'untitled').toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      tagline: data.tagline || 'High-quality digital downloadable resource.',
      description: data.description || 'Complete digital asset package ready for commercial and personal creative use.',
      sellerId: currentUser?.sellerId || 'seller-1',
      sellerName: currentUser?.name || 'Creator',
      sellerAvatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
      sellerRating: 5.0,
      sellerVerified: true,
      category: data.category || 'Templates',
      subcategory: data.subcategory || 'General',
      price: Number(data.price) || 19.99,
      originalPrice: data.originalPrice ? Number(data.originalPrice) : undefined,
      discountPercentage:
        data.originalPrice && data.price
          ? Math.round(((Number(data.originalPrice) - Number(data.price)) / Number(data.originalPrice)) * 100)
          : undefined,
      rating: 5.0,
      reviewCount: 0,
      salesCount: 0,
      downloadCount: 0,
      fileFormat: data.fileFormat || 'ZIP Package',
      fileSize: data.fileSize || '45 MB',
      thumbnail: data.thumbnail || '/src/assets/images/hero_digital_assets_1791198407854.jpg',
      previewImages: data.previewImages && data.previewImages.length > 0 ? data.previewImages : ['/src/assets/images/hero_digital_assets_1791198407854.jpg'],
      tags: data.tags || ['Digital Download', 'Creative Asset'],
      features: data.features || ['Full editable source files', 'High-resolution assets', 'Commercial usage rights included'],
      whatsIncluded: data.whatsIncluded || ['Master asset zip archive', 'Documentation & setup guide', 'License certificate'],
      license: data.license || 'commercial',
      status: 'published',
      isFeatured: false,
      isBestseller: false,
      isNew: true,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
      ebookMeta: data.ebookMeta,
      audioMeta: data.audioMeta,
      videoMeta: data.videoMeta,
      imageMeta: data.imageMeta,
      templateMeta: data.templateMeta,
    };

    setProducts((prev) => [newProduct, ...prev]);
    setIsUploadModalOpen(false);
    showToast('success', 'Product Published!', `${newProduct.title} is now available in the marketplace.`);
  };

  const adminUploadProduct = (data: Partial<Product>): Product => {
    const newId = `prod-adm-${Date.now()}`;
    const targetSeller = sellers.find((s) => s.id === data.sellerId) || sellers[0];

    const newProduct: Product = {
      id: newId,
      title: data.title || 'Untitled Administrator Publication',
      slug: (data.title || 'untitled').toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      tagline: data.tagline || 'Curated digital deliverable posted via Admin Portal.',
      description: data.description || 'Verified production-ready digital deliverable released under DigiMarket commercial licensing.',
      sellerId: targetSeller.id,
      sellerName: targetSeller.storeName,
      sellerAvatar: targetSeller.avatar,
      sellerRating: targetSeller.rating,
      sellerVerified: true,
      category: data.category || 'eBooks',
      subcategory: data.subcategory || 'Curated Master Series',
      price: Number(data.price) || 29.99,
      originalPrice: data.originalPrice ? Number(data.originalPrice) : undefined,
      discountPercentage:
        data.originalPrice && data.price
          ? Math.round(((Number(data.originalPrice) - Number(data.price)) / Number(data.originalPrice)) * 100)
          : undefined,
      rating: 5.0,
      reviewCount: 0,
      salesCount: 0,
      downloadCount: 0,
      fileFormat: data.fileFormat || 'PDF / LOSSLESS MASTER',
      fileSize: data.fileSize || '85.4 MB',
      thumbnail: data.thumbnail || '/src/assets/images/hero_digital_assets_1791198407854.jpg',
      previewImages: data.previewImages && data.previewImages.length > 0 ? data.previewImages : ['/src/assets/images/hero_digital_assets_1791198407854.jpg'],
      audioPreviewUrl: data.category === 'Music' || data.category === 'Audio' ? 'synth_preview' : undefined,
      tags: data.tags && data.tags.length > 0 ? data.tags : [data.category || 'Digital', 'Verified Asset', 'Admin Choice'],
      features: data.features && data.features.length > 0 ? data.features : [
        'Master verified package files',
        '256-bit encrypted delivery pipeline',
        'Uncompressed studio quality standards',
        'Comprehensive commercial sync & publication rights',
      ],
      whatsIncluded: data.whatsIncluded && data.whatsIncluded.length > 0 ? data.whatsIncluded : [
        'High-speed CDN source archive download',
        'Cryptographic authenticity certificate',
        'Lifetime product version updates',
      ],
      systemRequirements: data.systemRequirements || 'Compatible with all major industry standard software and readers.',
      license: data.license || 'commercial',
      status: (data.status as any) || 'published',
      isFeatured: data.isFeatured ?? true,
      isBestseller: false,
      isNew: true,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
      ebookMeta: data.ebookMeta,
      audioMeta: data.audioMeta,
      videoMeta: data.videoMeta,
      imageMeta: data.imageMeta,
      templateMeta: data.templateMeta,
    };

    setProducts((prev) => [newProduct, ...prev]);
    setIsAdminUploadModalOpen(false);

    logAdminAction(
      'Product Uploaded & Posted via Admin',
      `Posted new ${newProduct.category}: "${newProduct.title}" ($${newProduct.price.toFixed(2)}) for store ${targetSeller.storeName}`,
      newId
    );

    showToast('success', 'Admin Product Posted!', `${newProduct.title} is now active on the marketplace.`);
    return newProduct;
  };

  const registerAdminStaff = (data: Omit<AdminStaff, 'id' | 'joinedDate'>): AdminStaff => {
    const newStaffId = `admin-${Date.now()}`;
    const newStaff: AdminStaff = {
      ...data,
      id: newStaffId,
      joinedDate: new Date().toISOString().split('T')[0],
      lastLogin: 'Never (Newly Provisioned)',
      avatar:
        data.avatar ||
        `https://images.unsplash.com/photo-${1500000000000 + Math.floor(Math.random() * 90000000)}?auto=format&fit=crop&w=200&q=80`,
    };

    setAdminStaffList((prev) => [...prev, newStaff]);
    setIsAdminRegisterModalOpen(false);

    logAdminAction(
      'Administrator Registered',
      `Registered new staff member ${newStaff.name} (${newStaff.role.replace('_', ' ').toUpperCase()}) with Security Level ${newStaff.securityLevel}`,
      newStaffId
    );

    showToast('success', 'Admin Registered!', `${newStaff.name} has been enrolled in the DigiMarket administration roster.`);
    return newStaff;
  };

  const updateAdminStaffStatus = (staffId: string, status: 'active' | 'suspended') => {
    setAdminStaffList((prev) =>
      prev.map((s) => (s.id === staffId ? { ...s, status } : s))
    );
    logAdminAction('Staff Status Changed', `Modified status of admin ${staffId} to ${status.toUpperCase()}`, staffId);
    showToast('info', 'Status Updated', `Admin account status set to ${status}.`);
  };

  const requestSellerPayout = (sellerId: string) => {
    setSellers((prev) =>
      prev.map((s) => {
        if (s.id === sellerId) {
          if (s.pendingPayouts <= 0) {
            showToast('info', 'Zero Balance', 'No pending earnings available for payout.');
            return s;
          }
          const payoutAmount = s.pendingPayouts;
          showToast('success', 'Payout Dispatched', `$${payoutAmount.toFixed(2)} sent via ${s.payoutMethod.replace('_', ' ').toUpperCase()}`);
          return {
            ...s,
            pendingPayouts: 0,
          };
        }
        return s;
      })
    );
  };

  const approveProduct = (productId: string) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, status: 'published' } : p))
    );
    logAdminAction('Product Approved', `Published pending product ID ${productId}`, productId);
    showToast('success', 'Product Approved', 'Product is now live on the marketplace.');
  };

  const rejectProduct = (productId: string) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, status: 'rejected' } : p))
    );
    logAdminAction('Product Rejected', `Set product ID ${productId} to rejected status`, productId);
    showToast('info', 'Product Rejected', 'Seller notified with guidelines feedback.');
  };

  const deleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    logAdminAction('Product Deleted', `Removed product ID ${productId} from catalog`, productId);
    showToast('info', 'Product Removed');
  };

  const setCommissionRate = (rate: number) => {
    setCommissionRateState(rate);
    logAdminAction('Commission Rate Changed', `Adjusted marketplace platform fee take rate to ${rate}%`);
    showToast('info', 'Commission Updated', `Marketplace platform commission set to ${rate}%.`);
  };

  const addCoupon = (coupon: Coupon) => {
    setCoupons((prev) => [coupon, ...prev]);
    logAdminAction('Coupon Created', `Created promo code ${coupon.code} (${coupon.discountPercent || coupon.discountAmount}% off)`);
    showToast('success', 'Coupon Created', `Code ${coupon.code} is active.`);
  };

  const toggleCouponStatus = (code: string) => {
    setCoupons((prev) =>
      prev.map((c) => (c.code === code ? { ...c, isActive: !c.isActive } : c))
    );
  };

  const refundOrder = (orderId: string, reason: string) => {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          return {
            ...o,
            paymentStatus: 'refunded',
            refundReason: reason,
          };
        }
        return o;
      })
    );

    // Cryptographically revoke all download tokens for this order immediately
    setDownloadTokens((prev) =>
      prev.map((tok) => {
        if (tok.orderId === orderId) {
          return {
            ...tok,
            isRevoked: true,
            downloadsRemaining: 0,
            paymentVerificationStatus: 'flagged',
          };
        }
        return tok;
      })
    );

    logAdminAction(
      'Order Refunded & Access Revoked',
      `Issued refund for order ${orderId} (Reason: ${reason}). Invalidated all associated cryptographic tokens.`,
      orderId
    );
    showToast('success', 'Order Refunded', `Download tokens revoked for order ${orderId}.`);
  };

  const renewDownloadToken = (tokenId: string) => {
    const newExpiry = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
    setDownloadTokens((prev) =>
      prev.map((tok) => {
        if (tok.id === tokenId) {
          return {
            ...tok,
            downloadsRemaining: 5,
            expiresAt: newExpiry,
            isRevoked: false,
          };
        }
        return tok;
      })
    );
    logAdminAction('Download Token Renewed', `Reset download count and extended 30-day window for token ${tokenId}`, tokenId);
    showToast('success', 'Token Re-issued', 'Download attempts replenished to 5 and validity extended 30 days.');
  };

  const moderateReview = (reviewId: string, status: 'approved' | 'rejected') => {
    setReviews((prev) =>
      prev.map((r) => (r.id === reviewId ? { ...r, status } : r))
    );
    logAdminAction('Review Moderated', `Review ${reviewId} marked as ${status}`, reviewId);
    showToast('info', 'Review Moderated', `Review status changed to ${status}.`);
  };

  return (
    <AppContext.Provider
      value={{
        products,
        sellers,
        currentUser,
        adminStaffList,
        currentAdminStaff,
        adminAuditLogs,
        cart,
        wishlist,
        orders,
        downloadTokens,
        coupons,
        reviews,
        commissionRate,
        activePage,
        selectedProduct,
        selectedSeller,
        searchQuery,
        selectedCategory,
        isCartOpen,
        isAuthModalOpen,
        isUploadModalOpen,
        isBecomeSellerModalOpen,
        isAdminUploadModalOpen,
        isAdminRegisterModalOpen,
        darkMode,
        toasts,
        navigate,
        setSearchQuery,
        setSelectedCategory,
        addToCart,
        removeFromCart,
        clearCart,
        toggleWishlist,
        isInWishlist,
        setIsCartOpen,
        setIsAuthModalOpen,
        setIsUploadModalOpen,
        setIsBecomeSellerModalOpen,
        setIsAdminUploadModalOpen,
        setIsAdminRegisterModalOpen,
        toggleDarkMode,
        showToast,
        removeToast,
        loginAs,
        logout,
        becomeSeller,
        applyCoupon,
        completeCheckout,
        downloadProduct,
        verifyOrderDownloadLookup,
        addReview,
        uploadProduct,
        requestSellerPayout,
        adminUploadProduct,
        registerAdminStaff,
        updateAdminStaffStatus,
        switchAdminStaff,
        approveProduct,
        rejectProduct,
        deleteProduct,
        setCommissionRate,
        addCoupon,
        toggleCouponStatus,
        refundOrder,
        renewDownloadToken,
        moderateReview,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
