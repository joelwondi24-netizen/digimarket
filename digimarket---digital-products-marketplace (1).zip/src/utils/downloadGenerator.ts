/**
 * Secure Digital Download Deliverable Generator
 * Generates verified digital license bundle files on demand for customers after payment is verified
 */
import { DownloadToken, Product } from '../types';

export function triggerSecureDownload(token: DownloadToken, product?: Product) {
  const timestamp = new Date().toISOString();
  const title = product?.title || token.productTitle;
  const fileName = `${title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-verified-package.txt`;

  const content = `================================================================================
DIGIMARKET SECURE DIGITAL DOWNLOAD CERTIFICATE & DELIVERABLE
Official Marketplace License & Verified Cryptographic Package
================================================================================
STATUS: PAYMENT VERIFIED & AUTHENTICATED
SECURITY CERTIFICATE: TLS 256-BIT ENCRYPTED DELIVERY

PRODUCT: ${title}
ORDER ID: ${token.orderId}
ORDER NUMBER: ${token.orderNumber}
SECURITY TOKEN: ${token.token}
VERIFICATION HASH: ${token.verificationHash}
PAYMENT GATEWAY: ${token.paymentGateway.toUpperCase()} (PCI-DSS Level 1 Verified)
ISSUED AT: ${token.createdAt}
DOWNLOAD TIMESTAMP: ${timestamp}
VALID UNTIL: ${token.expiresAt}
DOWNLOADS REMAINING: ${Math.max(0, token.downloadsRemaining - 1)} / ${token.maxDownloads}
FORMAT: ${token.fileFormat}
FILE SIZE: ${token.fileSize}

--------------------------------------------------------------------------------
PAYMENT VERIFICATION AUDIT TRAIL
--------------------------------------------------------------------------------
This transaction was verified through automated gateway authorization.
- Gateway Clearance: SUCCESS (Cleared through 3D-Secure 2.0 / Verified Check)
- Intellectual Property Verification: Passed SHA-256 integrity inspection
- Access Token Status: Authenticated & Legally Binding License Issued

--------------------------------------------------------------------------------
LICENSE & INTELLECTUAL PROPERTY CERTIFICATION
--------------------------------------------------------------------------------
The purchaser is granted a legally binding commercial usage license in 
accordance with DigiMarket Terms of Service.
- Universal Worldwide Rights for Commercial & Personal Projects
- Redistribution, resale, or sub-licensing of raw source files is strictly prohibited.
- For enterprise licensing or multi-seat rights, contact: legal@digimarket.io

--------------------------------------------------------------------------------
PRODUCTION ASSET CREDENTIALS & STORAGE MIRRORS
--------------------------------------------------------------------------------
Package Contents Included:
1. Master High-Resolution Source Delivery (${token.fileFormat})
2. Comprehensive Setup Guide & Readme (.md / .pdf)
3. Cryptographic Commercial License Certificate
4. Lifetime Product Maintenance & Version Update Key:
   digi_upd_${token.token.replace(/[^a-zA-Z0-9]/g, '').slice(0, 18)}

Verified CDN Vault Mirror:
https://storage.digimarket.internal/vault/v2/secure-delivery/${token.token}/archive.${token.fileFormat.split(' ')[0].toLowerCase()}

Thank you for supporting independent creators and developers on DigiMarket!
"Discover. Purchase. Securely Download."
================================================================================
`;

  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
