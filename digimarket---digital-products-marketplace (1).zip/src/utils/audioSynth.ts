/**
 * Interactive Web Audio Synthesizer for live sound previews
 * Generates rich, relaxing ambient and cinematic musical chords
 */
class AudioSynthesizer {
  private ctx: AudioContext | null = null;
  private isPlaying = false;
  private oscNodes: OscillatorNode[] = [];
  private gainNode: GainNode | null = null;
  private filterNode: BiquadFilterNode | null = null;
  private timeoutId: number | null = null;
  private onProgressCallback: ((currentTime: number, duration: number) => void) | null = null;
  private startTime = 0;
  private totalDuration = 30; // 30 second preview loop
  private animFrameId: number | null = null;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public play(onProgress?: (time: number, duration: number) => void) {
    this.stop();
    this.initContext();
    if (!this.ctx) return;

    this.isPlaying = true;
    this.onProgressCallback = onProgress || null;
    this.startTime = this.ctx.currentTime;

    // Master gain
    this.gainNode = this.ctx.createGain();
    this.gainNode.gain.setValueAtTime(0.01, this.ctx.currentTime);
    this.gainNode.gain.exponentialRampToValueAtTime(0.18, this.ctx.currentTime + 1.2);

    // Warm Lowpass filter
    this.filterNode = this.ctx.createBiquadFilter();
    this.filterNode.type = 'lowpass';
    this.filterNode.frequency.setValueAtTime(800, this.ctx.currentTime);
    this.filterNode.frequency.exponentialRampToValueAtTime(2200, this.ctx.currentTime + 6);

    this.gainNode.connect(this.filterNode);
    this.filterNode.connect(this.ctx.destination);

    // Cinematic chord notes (D minor / F maj triad: D3, F3, A3, C4, E4)
    const frequencies = [146.83, 174.61, 220.0, 261.63, 329.63];

    frequencies.forEach((freq, idx) => {
      if (!this.ctx || !this.gainNode) return;
      const osc = this.ctx.createOscillator();
      const oscGain = this.ctx.createGain();
      
      osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

      // Subtle LFO vibrato
      const lfo = this.ctx.createOscillator();
      const lfoGain = this.ctx.createGain();
      lfo.frequency.value = 0.5 + idx * 0.2;
      lfoGain.gain.value = 1.8;
      lfo.connect(osc.frequency);
      lfo.start();

      oscGain.gain.value = 0.25 / frequencies.length;
      osc.connect(oscGain);
      oscGain.connect(this.gainNode);

      osc.start();
      this.oscNodes.push(osc);
    });

    // Animate progress
    const updateProgress = () => {
      if (!this.isPlaying || !this.ctx) return;
      const elapsed = this.ctx.currentTime - this.startTime;
      if (this.onProgressCallback) {
        this.onProgressCallback(Math.min(elapsed, this.totalDuration), this.totalDuration);
      }

      if (elapsed >= this.totalDuration) {
        this.stop();
      } else {
        this.animFrameId = requestAnimationFrame(updateProgress);
      }
    };

    this.animFrameId = requestAnimationFrame(updateProgress);
  }

  public stop() {
    this.isPlaying = false;
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
      this.timeoutId = null;
    }
    this.oscNodes.forEach((node) => {
      try {
        node.stop();
        node.disconnect();
      } catch {
        // ignore
      }
    });
    this.oscNodes = [];
    if (this.gainNode) {
      try {
        this.gainNode.disconnect();
      } catch {
        // ignore
      }
      this.gainNode = null;
    }
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }
}

export const previewSynth = new AudioSynthesizer();
