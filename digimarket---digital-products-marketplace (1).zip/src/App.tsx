/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { AnnouncementBar } from './components/common/AnnouncementBar';
import { Header } from './components/common/Header';
import { Footer } from './components/common/Footer';
import { ToastContainer } from './components/common/Toast';
import { HomePage } from './components/home/HomePage';
import { MarketplacePage } from './components/marketplace/MarketplacePage';
import { ProductDetailPage } from './components/product/ProductDetailPage';
import { CartDrawer } from './components/cart/CartDrawer';
import { CheckoutPage } from './components/checkout/CheckoutPage';
import { CustomerDashboard } from './components/account/CustomerDashboard';
import { VerifyDownloadPage } from './components/account/VerifyDownloadPage';
import { SellerDashboard } from './components/seller/SellerDashboard';
import { SellerStorefront } from './components/seller/SellerStorefront';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AboutPage } from './components/pages/AboutPage';
import { ContactPage } from './components/pages/ContactPage';
import { FaqPage } from './components/pages/FaqPage';
import { LegalPage } from './components/pages/LegalPage';
import { AuthModal } from './components/auth/AuthModal';
import { BecomeSellerModal } from './components/seller/BecomeSellerModal';
import { UploadProductModal } from './components/seller/UploadProductModal';

const MainLayout: React.FC = () => {
  const { activePage } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 transition-colors">
      {/* Toast Notification Stack */}
      <ToastContainer />

      {/* Top Slim Announcement Bar */}
      <AnnouncementBar />

      {/* Top Bar (Universal Contract Compliant) */}
      <Header />

      {/* Main Routed Page Surface */}
      <main className="flex-1">
        {activePage === 'home' && <HomePage />}
        {activePage === 'marketplace' && <MarketplacePage />}
        {activePage === 'product-details' && <ProductDetailPage />}
        {activePage === 'checkout' && <CheckoutPage />}
        {activePage === 'verify-download' && <VerifyDownloadPage />}
        {(activePage === 'account' || activePage === 'downloads') && <CustomerDashboard />}
        {activePage === 'seller-dashboard' && <SellerDashboard />}
        {activePage === 'seller-storefront' && <SellerStorefront />}
        {activePage === 'admin' && <AdminDashboard />}
        {activePage === 'about' && <AboutPage />}
        {activePage === 'contact' && <ContactPage />}
        {activePage === 'faq' && <FaqPage />}
        {activePage === 'legal' && <LegalPage />}
      </main>

      {/* Global Modals & Drawers */}
      <CartDrawer />
      <AuthModal />
      <BecomeSellerModal />
      <UploadProductModal />

      {/* Large Professional Footer */}
      <Footer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
